clc;
clear;
close all;

setup_project();
config = ablation_config();

if isempty(gcp('nocreate'))
    parpool('local');
end

fprintf('Parallel ARHO component-wise ablation study\n');
fprintf('Variants: %d | Functions: %d | Runs: %d\n', ...
    numel(config.variants), numel(config.functionIds), config.nRuns);

for dIndex = 1:numel(config.dimensions)
    D = config.dimensions(dIndex);
    run_parallel_dimension(D, config);
end

fprintf('\nAll parallel ablation dimensions completed.\n');

function run_parallel_dimension(D, config)
    maxFEs = config.feBudgetMultiplier * D;
    nF = numel(config.functionIds);
    nV = numel(config.variants);
    nR = config.nRuns;

    outputFolder = fullfile(config.outputRoot, sprintf('D%d', D));
    runFolder = fullfile(outputFolder, 'runs');
    if ~exist(runFolder, 'dir'), mkdir(runFolder); end

    aggregateFile = fullfile(outputFolder, ...
        sprintf('ARHO_Ablation_D%d.mat', D));

    finalValues = nan(nF,nV,nR);
    runtimes = nan(nF,nV,nR);
    actualFEs = nan(nF,nV,nR);
    traces = cell(nF,nV,nR);

    if config.resume && exist(aggregateFile, 'file')
        previous = load(aggregateFile);
        if isfield(previous,'finalValues'), finalValues=previous.finalValues; end
        if isfield(previous,'runtimes'), runtimes=previous.runtimes; end
        if isfield(previous,'actualFEs'), actualFEs=previous.actualFEs; end
        if isfield(previous,'traces'), traces=previous.traces; end
    end

    for f = 1:nF
        fid = config.functionIds(f);
        for v = 1:nV
            variant = config.variants{v};
            pending = find(~isfinite(squeeze(finalValues(f,v,:))));
            if isempty(pending), continue; end

            blockValues = nan(nR,1);
            blockTimes = nan(nR,1);
            blockFEs = nan(nR,1);
            blockTraces = cell(nR,1);
            blockBest = cell(nR,1);
            blockOut = cell(nR,1);

            parfor p = 1:numel(pending)
                run = pending(p);
                seed = config.seeds(run);
                noiseSeed = 3000000 + D*10000 + fid*100 + run;

                rng(seed,'twister');
                problem = getBenchmarkF13(fid,D,noiseSeed);
                opts = ARHO_DefaultOptions(config.N);
                opts = ARHO_AblationOptions(opts,variant);
                opts.maxFEs = maxFEs;
                opts.scheduleByFEs = true;
                opts.verbose = false;
                opts.nTracePoints = config.nTracePoints;

                timer = tic;
                [best,trace,out] = ARHO_FE( ...
                    problem,config.N,maxFEs,opts);
                elapsed = toc(timer);

                blockValues(run) = best.fitness;
                blockTimes(run) = elapsed;
                blockFEs(run) = best.FEs;
                blockTraces{run} = trace;
                blockBest{run} = best;
                blockOut{run} = out;
            end

            for p = 1:numel(pending)
                run = pending(p);
                finalValues(f,v,run) = blockValues(run);
                runtimes(f,v,run) = blockTimes(run);
                actualFEs(f,v,run) = blockFEs(run);
                traces{f,v,run} = blockTraces{run};

                if config.saveEveryRun
                    seed = config.seeds(run);
                    noiseSeed = 3000000 + D*10000 + fid*100 + run;
                    best = blockBest{run};
                    trace = blockTraces{run};
                    out = blockOut{run};
                    elapsed = blockTimes(run);
                    runFile = fullfile(runFolder,sprintf( ...
                        'F%02d_%s_Run%02d.mat',fid,variant,run));
                    save(runFile,'D','fid','variant','run','seed', ...
                        'noiseSeed','maxFEs','best','trace','out', ...
                        'elapsed','-v7.3');
                end

                fprintf(['D%3d | F%02d | %-38s | run %02d | ', ...
                    'fitness %.12e | FEs %d | %.2fs\n'], ...
                    D,fid,variant,run,blockValues(run), ...
                    blockFEs(run),blockTimes(run));
            end

            functionIds = config.functionIds;
            variants = config.variants;
            variantLabels = config.variantLabels;
            save(aggregateFile,'D','maxFEs','config','functionIds', ...
                'variants','variantLabels','finalValues','runtimes', ...
                'actualFEs','traces','-v7.3');
        end
    end

    generate_ablation_outputs(aggregateFile);
end
