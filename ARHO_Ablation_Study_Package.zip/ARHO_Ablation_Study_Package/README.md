# ARHO Benchmark Study

MATLAB implementation and reproducibility workflow for the
**Anticipatory Raven Hotspot Optimizer (ARHO)** benchmark study.

## Optimizers

ARHO, PSO, DE/rand/1/bin, GWO, RRO, and IRRO.

## Benchmark protocol

The classical F1–F13 functions are evaluated at 30, 100, and 500
dimensions. Each optimizer uses 30 independent runs, population size 30,
seeds 1–30, and a common budget of `1000 × D` objective evaluations.

## Quick start

```matlab
verify_installation
run_smoke_test
run_medium_test
```

After validation:

```matlab
run_30D
run_100D
run_500D
```

Or run the complete study sequentially:

```matlab
run_all_dimensions
```

The 500-dimensional experiment is computationally intensive. Running one
dimension at a time is recommended.

## Resume support

Every individual run is saved separately. Rerunning a script loads
completed runs and continues the missing runs.

## Results

Generated files are written to:

```text
results/D30
results/D100
results/D500
```

Each folder contains raw results, summary statistics, validation checks,
Friedman and Iman–Davenport results, Nemenyi comparisons,
Wilcoxon–Holm results, Win/Tie/Loss tables, and individual run files.

## Structure

```text
algorithms/   Optimizer implementations
benchmarks/   F1–F13 definitions
experiments/  Configuration and experiment runner
statistics/   Statistical analyses
utilities/    Validation and trace helpers
docs/         Reproducibility notes
results/      Generated outputs
```

See `docs/RRO_IRRO_IMPLEMENTATION_NOTES.md` before reporting RRO and IRRO
results.

Please cite the associated ARHO paper when using this repository.

## Reviewer-requested component-wise ablation

The package now contains a strict ablation implementation that disables one existing manuscript component at a time and introduces no new update equation. See `docs/ABLATION_STUDY_PROTOCOL.md`.

Run `run_ablation_smoke_test.m` first, then `run_ablation_all_dimensions.m`.
