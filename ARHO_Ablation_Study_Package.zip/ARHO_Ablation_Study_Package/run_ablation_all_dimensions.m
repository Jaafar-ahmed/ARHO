clc;
clear;
close all;

setup_project();
config = ablation_config();

fprintf('ARHO component-wise ablation study\n');
fprintf('Variants: %d | Functions: %d | Runs: %d\n', ...
    numel(config.variants), numel(config.functionIds), config.nRuns);
fprintf('Dimensions: %s\n', mat2str(config.dimensions));

for dIndex = 1:numel(config.dimensions)
    D = config.dimensions(dIndex);
    run_ablation_dimension(D, config);
end

fprintf('\nAll ablation dimensions completed.\n');

function run_ablation_dimension(D, config)
    maxFEs = config.feBudgetMultiplier * D;
    nF = numel(config.functionIds);
    nV = numel(config.variants);
    nR = config.nRuns;

    outputFolder = fullfile(config.outputRoot, sprintf('D%d', D));
    runFolder = fullfile(outputFolder, 'runs');
    if ~exist(runFolder, 'dir'), mkdir(runFolder); end

    finalValues = nan(nF, nV, nR);
    runtimes = nan(nF, nV, nR);
    actualFEs = nan(nF, nV, nR);
    traces = cell(nF, nV, nR);

    aggregateFile = fullfile(outputFolder, ...
        sprintf('ARHO_Ablation_D%d.mat', D));

    if config.resume && exist(aggregateFile, 'file')
        previous = load(aggregateFile);
        if isfield(previous, 'finalValues'), finalValues = previous.finalValues; end
        if isfield(previous, 'runtimes'), runtimes = previous.runtimes; end
        if isfield(previous, 'actualFEs'), actualFEs = previous.actualFEs; end
        if isfield(previous, 'traces'), traces = previous.traces; end
    end

    for f = 1:nF
        fid = config.functionIds(f);

        for v = 1:nV
            variant = config.variants{v};

            for run = 1:nR
                if config.resume && isfinite(finalValues(f,v,run))
                    continue;
                end

                seed = config.seeds(run);
                noiseSeed = 3000000 + D*10000 + fid*100 + run;

                % Reset the same internal random seed for every variant.
                % This keeps initialization paired across the ablations.
                rng(seed, 'twister');
                problem = getBenchmarkF13(fid, D, noiseSeed);

                opts = ARHO_DefaultOptions(config.N);
                opts = ARHO_AblationOptions(opts, variant);
                opts.maxFEs = maxFEs;
                opts.scheduleByFEs = true;
                opts.verbose = false;
                opts.nTracePoints = config.nTracePoints;

                tic;
                [best, trace, out] = ARHO_FE( ...
                    problem, config.N, maxFEs, opts);
                elapsed = toc;

                finalValues(f,v,run) = best.fitness;
                runtimes(f,v,run) = elapsed;
                actualFEs(f,v,run) = best.FEs;
                traces{f,v,run} = trace;

                if config.saveEveryRun
                    runFile = fullfile(runFolder, sprintf( ...
                        'F%02d_%s_Run%02d.mat', fid, variant, run));
                    save(runFile, 'D', 'fid', 'variant', 'run', ...
                        'seed', 'noiseSeed', 'maxFEs', 'best', ...
                        'trace', 'out', 'elapsed', '-v7.3');
                end

                fprintf(['D%3d | F%02d | %-38s | run %02d | ', ...
                    'fitness %.12e | FEs %d | %.2fs\n'], ...
                    D, fid, variant, run, best.fitness, best.FEs, elapsed);

                save(aggregateFile, 'D', 'maxFEs', 'config', ...
                    'finalValues', 'runtimes', 'actualFEs', 'traces', ...
                    '-v7.3');
            end
        end
    end

    functionIds = config.functionIds;
    variants = config.variants;
    variantLabels = config.variantLabels;
    save(aggregateFile, 'D', 'maxFEs', 'config', 'functionIds', ...
        'variants', 'variantLabels', 'finalValues', 'runtimes', ...
        'actualFEs', 'traces', '-v7.3');

    generate_ablation_outputs(aggregateFile);
end
