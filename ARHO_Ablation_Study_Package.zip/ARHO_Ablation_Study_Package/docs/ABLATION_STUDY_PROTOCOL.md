# ARHO Component-Wise Ablation Study Protocol

## Purpose

This package implements the component-wise ablation requested by the reviewer. Each ablated version disables one major ARHO component while leaving all other manuscript equations, parameters, population size, random seeds, benchmark definitions, and function-evaluation budgets unchanged.

No new update equation is introduced in any ablation.

## Variants

| Code name | Manuscript label | Removed component | Existing manuscript operations omitted |
|---|---|---|---|
| `full` | Full ARHO | None | None |
| `no_hotspot_memory` | ARHO-NoHM | Persistent spatial hotspot memory | The multi-hotspot archive and its persistent updates in Eqs. (6)-(19) are disabled. The current best elite point is used only as a temporary single guide. |
| `no_probabilistic_selection` | ARHO-NoPS | Probabilistic hotspot selection | Eq. (22) and roulette-wheel sampling are omitted. The largest existing Eq. (21) weight is selected directly. |
| `no_local_verification` | ARHO-NoLV | Local verification | The local candidate and broad/local greedy comparison in Eqs. (26)-(28) are omitted. |
| `no_leader_following` | ARHO-NoLF | Sparse leader following | Eqs. (30)-(32) are omitted. |
| `no_occupancy_aware_diversification` | ARHO-NoOAD | Occupancy-aware diversification | Eqs. (33)-(34) are omitted. The occupancy penalty in Eq. (21) remains active so that only diversification is removed. |

## Experimental protocol

- Functions: F1-F13.
- Dimensions: D=30, D=100, and D=500.
- Independent runs: 30.
- Seeds: 1-30.
- Population size: 30.
- Function-evaluation budget: MaxFEs=1000D.
- The same seed is reset before every variant to preserve paired initialization.
- F7 uses the same independent objective-noise seed for the corresponding function, dimension, and run.
- Every variant is stopped by the same function-evaluation budget, even when deleting a component reduces the number of evaluations per iteration.

## Statistics

The script generates:

- raw run-level outputs;
- best, mean, median, stable sample standard deviation, worst, and 95% CI;
- function-wise ranks calculated from the displayed mean objective values;
- average ranks;
- Friedman and Iman-Davenport tests;
- Nemenyi post-hoc comparisons;
- function-level paired Wilcoxon tests between Full ARHO and each ablated variant;
- Holm-adjusted p-values;
- rank-biserial effect sizes;
- statistically defined win/tie/loss counts.

A Full-ARHO win is recorded only when the Holm-adjusted p-value is below 0.05 and the paired median of Full ARHO is smaller. A tie denotes a non-significant difference; a loss denotes a significant result favoring the ablated variant.

## Running the study

1. Open MATLAB R2023b or later.
2. Set this package as the current folder.
3. Run:

```matlab
run_ablation_smoke_test
```

4. After the smoke test passes, run:

```matlab
run_ablation_all_dimensions
```

The full study is computationally expensive. The runner saves every individual run and supports resuming after interruption.

## Suggested manuscript description (no new equations)

> A component-wise ablation study was performed to isolate the contribution of the five principal ARHO mechanisms. The complete algorithm was compared with ARHO-NoHM, ARHO-NoPS, ARHO-NoLV, ARHO-NoLF, and ARHO-NoOAD, in which spatial hotspot memory, probabilistic hotspot selection, local verification, sparse leader-following, and occupancy-aware diversification were removed one at a time, respectively. No replacement update equation was introduced. All remaining operators and parameter values were kept unchanged. Every variant was evaluated on F1-F13 at D=30, D=100, and D=500 using 30 paired seeds, a population size of 30, and the same MaxFEs=1000D budget. Function-wise ranks were calculated from the displayed mean objective values, and significance was assessed using Friedman, Iman-Davenport, Nemenyi, and paired Wilcoxon-Holm tests.

## Optional parallel execution

When the MATLAB Parallel Computing Toolbox is available, the same protocol can be executed with:

```matlab
run_ablation_parallel_all_dimensions
```

The parallel runner preserves the same paired seeds, function-evaluation budgets, output structure, and statistical analysis as the serial runner.
