clc;
clear;
close all;

setup_project();
config = ablation_config();
config.dimensions = 30;

fprintf(['This compatibility runner executes the reviewer-requested ', ...
    'ablation at D=30 only.\n']);
fprintf(['For the complete D=30/100/500 study, run ', ...
    'run_ablation_all_dimensions.m.\n\n']);

D = 30;
maxFEs = config.feBudgetMultiplier * D;
nF = numel(config.functionIds);
nV = numel(config.variants);
nR = config.nRuns;
outputFolder = fullfile(config.outputRoot, 'D30');
if ~exist(outputFolder,'dir'), mkdir(outputFolder); end

finalValues = nan(nF,nV,nR);
runtimes = nan(nF,nV,nR);
actualFEs = nan(nF,nV,nR);
traces = cell(nF,nV,nR);

for f=1:nF
    fid=config.functionIds(f);
    for v=1:nV
        for run=1:nR
            seed=config.seeds(run);
            noiseSeed=3000000+D*10000+fid*100+run;
            rng(seed,'twister');
            problem=getBenchmarkF13(fid,D,noiseSeed);
            opts=ARHO_DefaultOptions(config.N);
            opts=ARHO_AblationOptions(opts,config.variants{v});
            opts.nTracePoints=config.nTracePoints;
            tic;
            [best,trace,~]=ARHO_FE(problem,config.N,maxFEs,opts);
            runtimes(f,v,run)=toc;
            finalValues(f,v,run)=best.fitness;
            actualFEs(f,v,run)=best.FEs;
            traces{f,v,run}=trace;
            fprintf('D30 F%02d | %-38s | run %02d | %.6e\n', ...
                fid,config.variants{v},run,best.fitness);
        end
    end
end

functionIds=config.functionIds;
variants=config.variants;
variantLabels=config.variantLabels;
resultFile=fullfile(outputFolder,'ARHO_Ablation_D30.mat');
save(resultFile,'D','maxFEs','config','functionIds','variants', ...
    'variantLabels','finalValues','runtimes','actualFEs','traces','-v7.3');
generate_ablation_outputs(resultFile);
