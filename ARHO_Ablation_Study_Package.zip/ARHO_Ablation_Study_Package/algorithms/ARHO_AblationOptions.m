function opts = ARHO_AblationOptions(opts, variant)
%ARHO_ABLATIONOPTIONS Configure the reviewer-requested ARHO ablations.
%
% Each variant disables exactly one manuscript component. No new movement
% or update equation is introduced.
%
% Supported variants:
%   "full"
%   "no_hotspot_memory"                 (NoHM)
%   "no_probabilistic_selection"        (NoPS)
%   "no_local_verification"             (NoLV)
%   "no_leader_following"               (NoLF)
%   "no_occupancy_aware_diversification"(NoOAD)

    variant = lower(string(variant));

    switch variant
        case "full"
            % Complete ARHO. No component is disabled.

        case {"no_hotspot_memory", "nohm"}
            % Disable the persistent multi-hotspot memory represented by
            % Eqs. (6)-(19). The current best elite point is retained only
            % as a temporary single guide for the unchanged movement rule.
            opts.useHotspotMemory = false;

        case {"no_probabilistic_selection", "nops"}
            % Disable Eq. (22) and roulette-wheel sampling. The hotspot with
            % the largest existing Eq. (21) weight is selected directly.
            opts.useProbabilisticSelection = false;

        case {"no_local_verification", "nolv"}
            % Disable the local-verification branch in Eqs. (26)-(28).
            opts.useLocalVerification = false;

        case {"no_leader_following", "nolf"}
            % Disable sparse leader following in Eqs. (30)-(32).
            opts.useLeaderFollowing = false;

        case {"no_occupancy_aware_diversification", "nooad", ...
              "no_diversification"}
            % Disable the diversification branch in Eqs. (33)-(34). The
            % occupancy term in hotspot selection is kept unchanged so that
            % only occupancy-aware diversification is removed.
            opts.useDiversification = false;

        otherwise
            error('Unknown ARHO ablation variant: %s', variant);
    end
end
