function [index, probabilities] = ARHO_SelectHotspot(archive, opts)
%ARHO_SELECTHOTSPOT Occupancy-aware hotspot selection.
%
% Full ARHO uses Eqs. (21)-(22) followed by roulette-wheel sampling.
% The NoPS ablation disables Eq. (22) and roulette-wheel sampling while
% retaining the original Eq. (21) weights. It directly selects the hotspot
% with the largest existing weight; no new search equation is introduced.

    if isempty(archive)
        error('The hotspot archive is empty.');
    end

    scores = [archive.s];
    occupancy = [archive.n];

    if ~opts.useOccupancy
        occupancy(:) = 0;
    end

    % Numerically stable implementation of Eq. (21).
    logWeights = opts.beta .* (scores - max(scores)) ...
               - opts.kappa .* log(1 + occupancy);
    logWeights = logWeights - max(logWeights);

    weights = exp(logWeights);
    totalWeight = sum(weights);

    if ~isfinite(totalWeight) || totalWeight <= 0
        weights = ones(1, numel(archive));
        totalWeight = numel(archive);
    end

    if isfield(opts, 'useProbabilisticSelection') && ...
            ~opts.useProbabilisticSelection
        % Component removal: Eq. (22) and roulette sampling are omitted.
        [~, index] = max(weights);
        probabilities = zeros(1, numel(archive));
        probabilities(index) = 1;
        return;
    end

    % Full ARHO: Eq. (22) and roulette-wheel selection.
    probabilities = weights / totalWeight;
    cumulative = cumsum(probabilities);
    r = rand;
    index = find(r <= cumulative, 1, 'first');

    if isempty(index)
        index = numel(archive);
    end
end
