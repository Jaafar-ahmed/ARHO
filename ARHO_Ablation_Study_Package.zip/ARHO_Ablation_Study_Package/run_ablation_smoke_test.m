clc;
clear;
close all;

setup_project();
config = ablation_config();
config.dimensions = 10;
config.functionIds = [1, 8, 13];
config.nRuns = 2;
config.seeds = (1:2)';
config.feBudgetMultiplier = 50;
config.outputRoot = fullfile(fileparts(mfilename('fullpath')), ...
    'results', 'ablation_smoke_test');
config.resume = false;

D = config.dimensions(1);
maxFEs = config.feBudgetMultiplier * D;

for f = 1:numel(config.functionIds)
    fid = config.functionIds(f);
    for v = 1:numel(config.variants)
        for run = 1:config.nRuns
            rng(config.seeds(run), 'twister');
            problem = getBenchmarkF13(fid, D, 9000000+fid*100+run);
            opts = ARHO_DefaultOptions(config.N);
            opts = ARHO_AblationOptions(opts, config.variants{v});
            opts.nTracePoints = 11;
            [best,~,~] = ARHO_FE(problem, config.N, maxFEs, opts);
            assert(isfinite(best.fitness), 'Nonfinite smoke-test result.');
            assert(best.FEs <= maxFEs, 'FE budget exceeded.');
            fprintf('PASS F%02d | %-38s | run %d | %.6e\n', ...
                fid, config.variants{v}, run, best.fitness);
        end
    end
end

fprintf('Ablation smoke test passed.\n');
