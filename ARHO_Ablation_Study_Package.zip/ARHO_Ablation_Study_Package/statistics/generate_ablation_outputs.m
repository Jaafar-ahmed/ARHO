function outputs = generate_ablation_outputs(resultMatFile)
%GENERATE_ABLATION_OUTPUTS Generate all ablation tables from raw runs.
%
% Rankings and Friedman analysis are based on function-wise MEAN objective
% values, matching the Mean +/- Std table shown in the manuscript.

    data = load(resultMatFile);
    outputFolder = fileparts(resultMatFile);

    D = data.D;
    functionIds = data.functionIds;
    variants = data.variants;
    labels = data.variantLabels;
    values = data.finalValues;
    runtimes = data.runtimes;
    actualFEs = data.actualFEs;
    alpha = data.config.alpha;

    nF = numel(functionIds);
    nV = numel(variants);
    nR = size(values,3);

    % Raw results table.
    rawRows = cell(nF*nV*nR, 8);
    row = 0;
    for f = 1:nF
        for v = 1:nV
            for r = 1:nR
                row = row + 1;
                rawRows(row,:) = {D, functionIds(f), string(variants{v}), ...
                    string(labels{v}), r, values(f,v,r), ...
                    runtimes(f,v,r), actualFEs(f,v,r)};
            end
        end
    end
    rawTable = cell2table(rawRows, 'VariableNames', { ...
        'Dimension','FunctionId','Variant','VariantLabel','Run', ...
        'FinalFitness','RuntimeSeconds','ActualFEs'});
    writetable(rawTable, fullfile(outputFolder, 'AblationRawResults.csv'));

    % Descriptive summary and performance matrix based on means.
    summaryRows = cell(nF*nV, 14);
    performance = nan(nF,nV);
    row = 0;
    for f = 1:nF
        for v = 1:nV
            x = squeeze(values(f,v,:));
            x = x(isfinite(x));
            mu = mean(x);
            sd = stable_sample_std(x);
            med = median(x);
            n = numel(x);
            halfWidth = t_critical_975(max(n-1,1))*sd/sqrt(max(n,1));
            performance(f,v) = mu;

            row = row + 1;
            summaryRows(row,:) = {D, functionIds(f), ...
                string(variants{v}), string(labels{v}), n, ...
                min(x), mu, med, sd, max(x), ...
                mu-halfWidth, mu+halfWidth, ...
                mean(squeeze(runtimes(f,v,:)),'omitnan'), ...
                mean(squeeze(actualFEs(f,v,:)),'omitnan')};
        end
    end
    summaryTable = cell2table(summaryRows, 'VariableNames', { ...
        'Dimension','FunctionId','Variant','VariantLabel','ValidRuns', ...
        'Best','Mean','Median','Std','Worst','CI95Low','CI95High', ...
        'MeanRuntimeSeconds','MeanActualFEs'});
    writetable(summaryTable, fullfile(outputFolder, 'AblationSummary.csv'));

    % Mean-based ranks, Friedman, Iman-Davenport and Nemenyi.
    friedman = friedman_test(performance);
    rankMatrixTable = array2table(friedman.rankMatrix, ...
        'VariableNames', matlab.lang.makeValidName(labels));
    rankMatrixTable.FunctionId = functionIds(:);
    rankMatrixTable = movevars(rankMatrixTable, 'FunctionId', 'Before', 1);
    writetable(rankMatrixTable, ...
        fullfile(outputFolder, 'AblationFunctionLevelRanks.csv'));

    averageRankTable = table(string(variants(:)), string(labels(:)), ...
        friedman.averageRanks(:), ...
        'VariableNames', {'Variant','VariantLabel','AverageRank'});
    averageRankTable = sortrows(averageRankTable, 'AverageRank', 'ascend');
    writetable(averageRankTable, ...
        fullfile(outputFolder, 'AblationAverageRanks.csv'));

    overallTable = table(D, friedman.Q, friedman.df, ...
        friedman.pChiSquare, friedman.imanDavenportF, ...
        friedman.imanDavenportP, ...
        'VariableNames', {'Dimension','FriedmanQ','DF', ...
        'FriedmanP','ImanDavenportF','ImanDavenportP'});
    writetable(overallTable, ...
        fullfile(outputFolder, 'AblationFriedmanOverall.csv'));

    [nemenyiTable, criticalDifference] = nemenyi_posthoc( ...
        labels, friedman.averageRanks, nF, alpha);
    writetable(nemenyiTable, ...
        fullfile(outputFolder, 'AblationNemenyiPostHoc.csv'));

    fid = fopen(fullfile(outputFolder, ...
        'AblationNemenyiCriticalDifference.txt'), 'w');
    fprintf(fid, 'Dimension = %d\n', D);
    fprintf(fid, 'Alpha = %.4f\n', alpha);
    fprintf(fid, 'Critical difference = %.16g\n', criticalDifference);
    fclose(fid);

    % Full ARHO versus every removed-component variant, function by function.
    fullIndex = find(strcmpi(variants, 'full'), 1);
    rows = {};
    counter = 0;
    for v = 1:nV
        if v == fullIndex, continue; end
        for f = 1:nF
            x = squeeze(values(f,fullIndex,:));
            y = squeeze(values(f,v,:));
            test = wilcoxon_signed_rank(x,y);

            counter = counter + 1;
            rows(counter,:) = {D, functionIds(f), ...
                string(variants{v}), string(labels{v}), ...
                mean(x,'omitnan'), mean(y,'omitnan'), ...
                median(x,'omitnan'), median(y,'omitnan'), ...
                test.n, test.Wplus, test.Wminus, test.z, test.p, ...
                test.rankBiserialAdvantage};
        end
    end
    wilcoxonTable = cell2table(rows, 'VariableNames', { ...
        'Dimension','FunctionId','RemovedVariant','RemovedVariantLabel', ...
        'FullMean','VariantMean','FullMedian','VariantMedian', ...
        'N','Wplus','Wminus','Z','RawP','RankBiserialAdvantage'});

    % Holm correction across all function/variant comparisons.
    wilcoxonTable.HolmP = holm_adjust(wilcoxonTable.RawP);
    decision = strings(height(wilcoxonTable),1);
    for i = 1:height(wilcoxonTable)
        if wilcoxonTable.HolmP(i) >= alpha
            decision(i) = "Tie";
        elseif wilcoxonTable.FullMedian(i) < wilcoxonTable.VariantMedian(i)
            decision(i) = "Win";
        else
            decision(i) = "Loss";
        end
    end
    wilcoxonTable.Decision = decision;
    writetable(wilcoxonTable, ...
        fullfile(outputFolder, 'AblationWilcoxonHolmFunctionLevel.csv'));

    % Compact W/T/L table.
    removedVariants = variants;
    removedVariants(fullIndex) = [];
    removedLabels = labels;
    removedLabels(fullIndex) = [];
    wtlRows = cell(numel(removedVariants),6);
    for v = 1:numel(removedVariants)
        subset = wilcoxonTable(strcmpi( ...
            wilcoxonTable.RemovedVariant, removedVariants{v}),:);
        wtlRows(v,:) = {D, string(removedVariants{v}), ...
            string(removedLabels{v}), ...
            sum(subset.Decision=="Win"), ...
            sum(subset.Decision=="Tie"), ...
            sum(subset.Decision=="Loss")};
    end
    wtlTable = cell2table(wtlRows, 'VariableNames', { ...
        'Dimension','RemovedVariant','RemovedVariantLabel', ...
        'FullWins','Ties','FullLosses'});
    writetable(wtlTable, ...
        fullfile(outputFolder, 'AblationWinTieLoss.csv'));

    outputs.rawTable = rawTable;
    outputs.summaryTable = summaryTable;
    outputs.averageRankTable = averageRankTable;
    outputs.overallTable = overallTable;
    outputs.nemenyiTable = nemenyiTable;
    outputs.wilcoxonTable = wilcoxonTable;
    outputs.wtlTable = wtlTable;
    outputs.criticalDifference = criticalDifference;
end

function t = t_critical_975(df)
    tableValues=[ ...
        12.7062047364, 4.30265272975, 3.18244630528, 2.77644510520, ...
        2.57058183661, 2.44691184879, 2.36462425101, 2.30600413503, ...
        2.26215716285, 2.22813885196, 2.20098516008, 2.17881282966, ...
        2.16036865646, 2.14478668792, 2.13144954556, 2.11990529922, ...
        2.10981557783, 2.10092204024, 2.09302405441, 2.08596344727, ...
        2.07961384473, 2.07387306790, 2.06865761042, 2.06389856163, ...
        2.05953855275, 2.05552943864, 2.05183051648, 2.04840714180, ...
        2.04522964213, 2.04227245630];
    if df<=30
        t=tableValues(max(1,round(df)));
    elseif df<=40
        t=2.02107539031;
    elseif df<=60
        t=2.00029782106;
    elseif df<=120
        t=1.97993040505;
    else
        t=1.95996398454;
    end
end
