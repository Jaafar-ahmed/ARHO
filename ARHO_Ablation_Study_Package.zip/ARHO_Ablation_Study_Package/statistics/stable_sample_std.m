function s = stable_sample_std(x)
%STABLE_SAMPLE_STD Overflow/underflow-resistant sample standard deviation.
%
% This is algebraically equivalent to std(x,0) but evaluates the sample
% after division by max(abs(x)) and then restores the scale.

    x = x(:);
    x = x(isfinite(x));

    if numel(x) <= 1
        s = 0;
        return;
    end

    scale = max(abs(x));
    if scale == 0
        s = 0;
    else
        s = scale * std(x ./ scale, 0);
    end
end
