function result = wilcoxon_signed_rank(x,y)
%WILCOXON_SIGNED_RANK Paired two-sided Wilcoxon normal approximation.
%
% Exact zero paired differences are omitted. A global scale-dependent zero
% tolerance is intentionally not used because it can delete legitimate
% differences when a sample spans many orders of magnitude.
%
% Positive RankBiserialAdvantage means x tends to be smaller (better for
% minimization) than y.

    x=x(:);y=y(:);
    valid=isfinite(x)&isfinite(y);
    d=x(valid)-y(valid);
    d=d(d~=0);

    n=numel(d);
    if n==0
        result.n=0;
        result.Wplus=0;
        result.Wminus=0;
        result.z=0;
        result.p=1;
        result.rankBiserialAdvantage=0;
        return;
    end

    absolute=abs(d);
    ranks=tied_rank(absolute);
    Wplus=sum(ranks(d>0));
    Wminus=sum(ranks(d<0));

    mu=n*(n+1)/4;

    [~,~,group]=unique(absolute);
    counts=accumarray(group,1);
    tieCorrection=sum(counts.*(counts+1).*(2*counts+1));

    variance=n*(n+1)*(2*n+1)/24-tieCorrection/48;
    variance=max(variance,eps);

    z=(abs(Wplus-mu)-0.5)/sqrt(variance);
    z=max(z,0);
    p=erfc(z/sqrt(2));

    denominator=Wplus+Wminus;
    advantage=(Wminus-Wplus)/max(denominator,eps);

    result.n=n;
    result.Wplus=Wplus;
    result.Wminus=Wminus;
    result.z=z;
    result.p=min(1,max(0,p));
    result.rankBiserialAdvantage=advantage;
end
