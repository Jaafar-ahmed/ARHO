function summary = generate_summary( ...
    D,algorithms,functionIds,finalValues,runtimes,actualFEs)
%GENERATE_SUMMARY Best/mean/median/std/worst and approximate CI.

    nFunctions=numel(functionIds);
    nAlgorithms=numel(algorithms);
    rows=cell(nFunctions*nAlgorithms,15);
    row=0;

    for f=1:nFunctions
        for a=1:nAlgorithms
            values=squeeze(finalValues(f,a,:));
            times=squeeze(runtimes(f,a,:));
            fes=squeeze(actualFEs(f,a,:));

            finiteValues=values(isfinite(values));
            if isempty(finiteValues)
                finiteValues=realmax('double')/100;
            end

            n=numel(finiteValues);
            mu=mean(finiteValues);
            sigma=std(finiteValues,0);
            tCritical=t_critical_975(max(n-1,1));
            halfWidth=tCritical*sigma/sqrt(max(n,1));

            row=row+1;
            rows(row,:)={ ...
                D,functionIds(f),string(algorithms{a}),n, ...
                min(finiteValues),mu,median(finiteValues),sigma, ...
                max(finiteValues),mu-halfWidth,mu+halfWidth, ...
                mean(times,'omitnan'),mean(fes,'omitnan'), ...
                sum(~isfinite(values)), ...
                sprintf('%.6e +/- %.6e',mu,sigma)};
        end
    end

    summary=cell2table(rows,'VariableNames',{ ...
        'Dimension','FunctionId','Algorithm','ValidRuns', ...
        'Best','Mean','Median','Std','Worst', ...
        'CI95Low','CI95High','MeanRuntimeSeconds', ...
        'MeanActualFEs','NonfiniteRuns','MeanPlusMinusStd'});
end


function t=t_critical_975(df)
%T_CRITICAL_975 Two-sided 95% Student-t critical value.
%
% Toolbox-free lookup/interpolation sufficient for the benchmark protocol.
% The main experiment uses df=29; smoke and medium tests use df=1 and df=4.

    tableValues=[ ...
        12.7062047364, 4.30265272975, 3.18244630528, 2.77644510520, ...
        2.57058183661, 2.44691184879, 2.36462425101, 2.30600413503, ...
        2.26215716285, 2.22813885196, 2.20098516008, 2.17881282966, ...
        2.16036865646, 2.14478668792, 2.13144954556, 2.11990529922, ...
        2.10981557783, 2.10092204024, 2.09302405441, 2.08596344727, ...
        2.07961384473, 2.07387306790, 2.06865761042, 2.06389856163, ...
        2.05953855275, 2.05552943864, 2.05183051648, 2.04840714180, ...
        2.04522964213, 2.04227245630];

    if df<=30
        t=tableValues(max(1,round(df)));
    elseif df<=40
        t=2.02107539031;
    elseif df<=60
        t=2.00029782106;
    elseif df<=120
        t=1.97993040505;
    else
        t=1.95996398454;
    end
end
