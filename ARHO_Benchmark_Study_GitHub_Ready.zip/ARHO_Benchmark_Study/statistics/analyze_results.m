function statistics = analyze_results(resultMatFile)
%ANALYZE_RESULTS Descriptive and nonparametric benchmark analysis.

    data=load(resultMatFile);
    outputFolder=fileparts(resultMatFile);

    algorithms=data.algorithms;
    functionIds=data.functionIds;
    values=data.finalValues;
    D=data.D;
    alpha=data.config.alpha;

    nFunctions=numel(functionIds);
    nAlgorithms=numel(algorithms);
    arhoIndex=find(strcmpi(algorithms,'ARHO'),1);

    if isempty(arhoIndex)
        error('ARHO is not present in the algorithm list.');
    end

    % Median performance matrix for Friedman analysis.
    performance=nan(nFunctions,nAlgorithms);
    for f=1:nFunctions
        for a=1:nAlgorithms
            performance(f,a)=median(squeeze(values(f,a,:)), ...
                'omitnan');
        end
    end

    friedman=friedman_test(performance);
    friedmanTable=table( ...
        string(algorithms(:)),friedman.averageRanks(:), ...
        'VariableNames',{'Algorithm','AverageRank'});
    friedmanTable=sortrows(friedmanTable,'AverageRank','ascend');

    overallTable=table(D,friedman.Q,friedman.df, ...
        friedman.pChiSquare,friedman.imanDavenportF, ...
        friedman.imanDavenportP, ...
        'VariableNames',{'Dimension','FriedmanQ','DF', ...
        'FriedmanP','ImanDavenportF','ImanDavenportP'});

    [nemenyiTable,criticalDifference]=nemenyi_posthoc( ...
        algorithms,friedman.averageRanks,nFunctions,alpha);

    % Paired ARHO-vs-baseline Wilcoxon tests for every function.
    rows={};
    counter=0;
    for a=1:nAlgorithms
        if a==arhoIndex,continue;end
        for f=1:nFunctions
            x=squeeze(values(f,arhoIndex,:));
            y=squeeze(values(f,a,:));
            test=wilcoxon_signed_rank(x,y);

            counter=counter+1;
            rows(counter,:)={ ...
                D,functionIds(f),string(algorithms{a}), ...
                median(x,'omitnan'),median(y,'omitnan'), ...
                test.n,test.Wplus,test.Wminus,test.z,test.p, ...
                test.rankBiserialAdvantage};
        end
    end

    wilcoxonTable=cell2table(rows,'VariableNames',{ ...
        'Dimension','FunctionId','Baseline', ...
        'ARHOMedian','BaselineMedian','N','Wplus','Wminus', ...
        'Z','RawP','RankBiserialAdvantage'});

    wilcoxonTable.HolmP=holm_adjust(wilcoxonTable.RawP);
    decisions=strings(height(wilcoxonTable),1);

    for i=1:height(wilcoxonTable)
        if wilcoxonTable.HolmP(i)>=alpha
            decisions(i)="Tie";
        elseif wilcoxonTable.ARHOMedian(i) < ...
                wilcoxonTable.BaselineMedian(i)
            decisions(i)="Win";
        else
            decisions(i)="Loss";
        end
    end
    wilcoxonTable.Decision=decisions;

    baselineNames=setdiff(algorithms,{'ARHO'},'stable');
    wtlRows=cell(numel(baselineNames),4);
    for i=1:numel(baselineNames)
        subset=wilcoxonTable( ...
            strcmpi(wilcoxonTable.Baseline,baselineNames{i}),:);
        wtlRows(i,:)={string(baselineNames{i}), ...
            sum(subset.Decision=="Win"), ...
            sum(subset.Decision=="Tie"), ...
            sum(subset.Decision=="Loss")};
    end
    winTieLossTable=cell2table(wtlRows,'VariableNames',{ ...
        'Baseline','Wins','Ties','Losses'});

    writetable(friedmanTable, ...
        fullfile(outputFolder,'FriedmanAverageRanks.csv'));
    writetable(overallTable, ...
        fullfile(outputFolder,'FriedmanOverallTest.csv'));
    writetable(nemenyiTable, ...
        fullfile(outputFolder,'NemenyiPostHoc.csv'));
    writetable(wilcoxonTable, ...
        fullfile(outputFolder,'WilcoxonHolm.csv'));
    writetable(winTieLossTable, ...
        fullfile(outputFolder,'WinTieLoss.csv'));

    fid=fopen(fullfile(outputFolder,'NemenyiCriticalDifference.txt'),'w');
    fprintf(fid,'Dimension = %d\n',D);
    fprintf(fid,'Alpha = %.4f\n',alpha);
    fprintf(fid,'Critical difference = %.16g\n',criticalDifference);
    fclose(fid);

    statistics.friedmanTable=friedmanTable;
    statistics.overallTable=overallTable;
    statistics.nemenyiTable=nemenyiTable;
    statistics.wilcoxonTable=wilcoxonTable;
    statistics.winTieLossTable=winTieLossTable;
    statistics.criticalDifference=criticalDifference;
end
