function projectRoot = setup_project()
%SETUP_PROJECT Activate this repository and remove conflicting user paths.

    projectRoot=fileparts(mfilename('fullpath'));
    cd(projectRoot);

    restoredefaultpath;
    addpath(projectRoot,'-begin');
    addpath(fullfile(projectRoot,'algorithms'),'-begin');
    addpath(fullfile(projectRoot,'benchmarks'),'-begin');
    addpath(fullfile(projectRoot,'experiments'),'-begin');
    addpath(fullfile(projectRoot,'statistics'),'-begin');
    addpath(fullfile(projectRoot,'utilities'),'-begin');

    rehash toolboxcache;
    rehash path;

    fprintf('ARHO Benchmark Study activated:\n%s\n',projectRoot);
end
