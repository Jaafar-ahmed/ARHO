# Reproducibility protocol

The main study uses:

- Dimensions: 30, 100, and 500
- Functions: F1–F13
- Algorithms: ARHO, PSO, DE, GWO, RRO, and IRRO
- Population size: 30
- Independent runs: 30
- Seeds: 1–30
- Evaluation budget: `1000 × D`
- Convergence checkpoints: 101

| Dimension | Maximum objective evaluations |
|---:|---:|
| 30 | 30,000 |
| 100 | 100,000 |
| 500 | 500,000 |

All algorithms receive the same objective-function evaluation budget.

## F7 noise

F7 uses a dedicated random stream. For a given dimension, function, and
run, every optimizer receives the same objective-noise sequence while its
algorithmic random stream remains independent.

## F2 overflow protection

The Schwefel 2.22 product term is evaluated in the log domain when
necessary. Values outside double-precision range are capped at
`realmax/100`.

## Statistical outputs

The repository generates descriptive statistics, Friedman and
Iman–Davenport tests, Nemenyi post-hoc comparisons, paired Wilcoxon tests
with Holm correction, rank-biserial effect sizes, and Win/Tie/Loss tables.
