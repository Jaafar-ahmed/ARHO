# Adding another optimizer

Add a MATLAB function to `algorithms/` with this interface:

```matlab
[best,trace,out] = MyOptimizer(problem,N,maxFEs,options)
```

The returned structures must contain:

```matlab
best.position
best.fitness
best.FEs
trace.checkpoints
trace.best
```

Then update `experiments/default_config.m` and
`experiments/optimizer_dispatch.m`. Run the smoke and medium tests before
the complete study.
