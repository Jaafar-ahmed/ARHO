# RRO and IRRO implementation notes

The repository includes reproducible, paper-aligned reference
implementations of Raven Roosting Optimization (RRO) and Improved Raven
Roosting Optimization (IRRO).

## Primary references

- A. Brabazon, W. Cui, and M. O'Neill, “The raven roosting optimisation
  algorithm,” *Soft Computing*, 20, 525–545, 2016.
- S. Torabi and F. Safi-Esfahani, “Improved Raven Roosting Optimization
  algorithm (IRRO),” *Swarm and Evolutionary Computation*, 40, 144–154,
  2018.

## Explicit assumptions

The original descriptions leave some implementation details
underspecified. This repository records the adopted values.

### RRO

- Perception factor: 3.6
- Leader factor: 3.6
- Maximum local steps: 20
- Weak fraction: 0.4
- Stop probability: 0.2

### IRRO

- Perception factor: 3.6
- Leader factor: 3.6
- Maximum local steps: 20
- Weak fraction: 0.4
- Maximum food residual: 1.0

Both implementations use symmetric movement around the current position:

```matlab
candidate = position + (2*rand(1,D)-1).*radius;
```

This prevents directional bias toward the upper search bounds.

These files should be described as documented reference implementations,
not as author-supplied source code.
