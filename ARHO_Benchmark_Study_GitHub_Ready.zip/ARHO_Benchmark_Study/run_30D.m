clc;
clear;
close all;

setup_project();

config=default_config();
output=run_experiment(30,config);

resultFile=fullfile(output.outputFolder,'BenchmarkResults.mat');
validation=validate_results(resultFile);
statistics=analyze_results(resultFile);

disp(output.summary);
disp(validation.summary);
disp(statistics.friedmanTable);
disp(statistics.winTieLossTable);
