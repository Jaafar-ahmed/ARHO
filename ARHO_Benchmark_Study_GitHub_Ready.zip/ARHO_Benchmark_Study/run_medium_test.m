clc;
clear;
close all;

projectRoot=setup_project();

config=default_config();
config.nRuns=5;
config.seeds=(1:5)';
config.functionIds=1:13;
config.feBudgetMultiplier=100;
config.outputRoot=fullfile(projectRoot,'results','medium_test');

output=run_experiment(30,config);
validation=validate_results( ...
    fullfile(output.outputFolder,'BenchmarkResults.mat'));

disp(output.summary);
disp(validation.summary);
