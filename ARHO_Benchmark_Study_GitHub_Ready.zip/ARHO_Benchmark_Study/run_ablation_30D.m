clc;
clear;
close all;

setup_project();

% Optional reviewer-requested component-wise ablation.
% This script is computationally expensive and is not called by the main
% benchmark runner.

config=default_config();
D=30;
maxFEs=config.feBudgetMultiplier*D;
variants={ ...
    'full', ...
    'no_hotspot_memory', ...
    'no_occupancy', ...
    'no_local_verification', ...
    'no_leader_following', ...
    'no_diversification', ...
    'fixed_radius', ...
    'no_forgetting'};

outputFolder=fullfile(config.outputRoot,'ablation','D30');
if ~exist(outputFolder,'dir'),mkdir(outputFolder);end

results=nan(numel(config.functionIds),numel(variants),config.nRuns);

for f=1:numel(config.functionIds)
    fid=config.functionIds(f);

    for v=1:numel(variants)
        for run=1:config.nRuns
            seed=config.seeds(run);
            noiseSeed=3000000+fid*100+run;

            rng(seed,'twister');
            problem=getBenchmarkF13(fid,D,noiseSeed);

            opts=ARHO_DefaultOptions(config.N);
            opts=ARHO_AblationOptions(opts,variants{v});
            opts.maxFEs=maxFEs;
            opts.scheduleByFEs=true;
            opts.verbose=false;
            opts.nTracePoints=config.nTracePoints;

            [best,~,~]=ARHO_FE( ...
                problem,config.N,maxFEs,opts);

            results(f,v,run)=best.fitness;
            fprintf('Ablation F%02d | %-24s | run %02d | %.6e\n', ...
                fid,variants{v},run,best.fitness);
        end
    end
end

save(fullfile(outputFolder,'ARHO_Ablation_D30.mat'), ...
    'results','variants','config','D','maxFEs','-v7.3');

rows={};counter=0;
for f=1:numel(config.functionIds)
    for v=1:numel(variants)
        x=squeeze(results(f,v,:));
        counter=counter+1;
        rows(counter,:)={config.functionIds(f),string(variants{v}), ...
            min(x),mean(x),median(x),std(x,0),max(x)};
    end
end

summary=cell2table(rows,'VariableNames',{ ...
    'FunctionId','Variant','Best','Mean','Median','Std','Worst'});
writetable(summary,fullfile(outputFolder,'AblationSummary.csv'));
