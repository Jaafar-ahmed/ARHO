clc;
clear;

projectRoot=setup_project();

checks={ ...
    'ARHO',fullfile(projectRoot,'algorithms'); ...
    'RRO',fullfile(projectRoot,'algorithms'); ...
    'IRRO',fullfile(projectRoot,'algorithms'); ...
    'getBenchmarkF13',fullfile(projectRoot,'benchmarks'); ...
    'default_config',fullfile(projectRoot,'experiments'); ...
    'optimizer_dispatch',fullfile(projectRoot,'experiments'); ...
    'run_experiment',fullfile(projectRoot,'experiments'); ...
    'analyze_results',fullfile(projectRoot,'statistics'); ...
    'validate_results',fullfile(projectRoot,'utilities')};

for i=1:size(checks,1)
    functionName=checks{i,1};
    expectedFolder=checks{i,2};
    resolved=which(functionName);

    fprintf('%-24s -> %s\n',functionName,resolved);

    assert(~isempty(resolved), ...
        'Required function %s was not found.',functionName);
    assert(same_folder(fileparts(resolved),expectedFolder), ...
        'Function %s is being loaded from an unexpected folder.', ...
        functionName);
end

fprintf('\nPASS: the clean repository installation is active.\n');

function tf=same_folder(folderA,folderB)
    tf=strcmpi(canonical_path(folderA),canonical_path(folderB));
end

function value=canonical_path(value)
    try
        value=char(java.io.File(value).getCanonicalPath());
    catch
        value=char(value);
    end
    value=strrep(value,'/','\');
    while numel(value)>3 && value(end)=='\'
        value(end)=[];
    end
end
