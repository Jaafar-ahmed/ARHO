function [best,trace,out] = DE(problem,N,maxFEs,options)
%DE DE/rand/1/bin with an exact FE budget.

    if nargin < 4, options=struct(); end
    F=get_option(options,'F',0.5);
    CR=get_option(options,'CR',0.9);
    nTracePoints=get_option(options,'nTracePoints',101);

    if N<4, error('DE requires N >= 4.'); end

    D=problem.dim; lb=problem.lb; ub=problem.ub; span=ub-lb;
    X=lb+rand(N,D).*span;
    fitness=nan(N,1);
    FEs=0;

    for i=1:N
        fitness(i)=safe_eval(problem.objective,X(i,:));
        FEs=FEs+1;
    end

    [bestFit,idx]=min(fitness);
    bestX=X(idx,:);

    checkpoints=make_FE_checkpoints(N,maxFEs,nTracePoints);
    trace=trace_initialize(checkpoints,FEs,bestFit);

    while FEs<maxFEs
        Xold=X;
        fold=fitness;

        for i=1:N
            if FEs>=maxFEs, break; end

            pool=setdiff(1:N,i);
            chosen=pool(randperm(numel(pool),3));
            mutant=Xold(chosen(1),:) ...
                  + F*(Xold(chosen(2),:)-Xold(chosen(3),:));
            mutant=min(max(mutant,lb),ub);

            jrand=randi(D);
            mask=rand(1,D)<CR;
            mask(jrand)=true;
            trial=Xold(i,:);
            trial(mask)=mutant(mask);

            trialFit=safe_eval(problem.objective,trial);
            FEs=FEs+1;

            if trialFit<fold(i)
                X(i,:)=trial;
                fitness(i)=trialFit;
            else
                X(i,:)=Xold(i,:);
                fitness(i)=fold(i);
            end

            if fitness(i)<bestFit
                bestFit=fitness(i);
                bestX=X(i,:);
            end

            trace=trace_update(trace,FEs,bestFit);
        end
    end

    trace=trace_finalize(trace,bestFit);
    best.position=bestX;
    best.fitness=bestFit;
    best.FEs=FEs;
    out.options=options;
end

function value=safe_eval(fun,x)
    value=fun(x);
    if ~isfinite(value), value=realmax('double')/100; end
end

function value=get_option(s,name,default)
    if isfield(s,name), value=s.(name); else, value=default; end
end
