function [best,trace,out] = GWO(problem,N,maxFEs,options)
%GWO Standard Grey Wolf Optimizer with an exact FE budget.

    if nargin < 4, options=struct(); end
    nTracePoints=get_option(options,'nTracePoints',101);

    if N<3, error('GWO requires N >= 3.'); end

    D=problem.dim; lb=problem.lb; ub=problem.ub; span=ub-lb;
    X=lb+rand(N,D).*span;
    fitness=nan(N,1);
    FEs=0;

    for i=1:N
        fitness(i)=safe_eval(problem.objective,X(i,:));
        FEs=FEs+1;
    end

    [fitness,order]=sort(fitness);
    X=X(order,:);
    alphaX=X(1,:); alphaFit=fitness(1);
    betaX=X(2,:); betaFit=fitness(2);
    deltaX=X(3,:); deltaFit=fitness(3);

    checkpoints=make_FE_checkpoints(N,maxFEs,nTracePoints);
    trace=trace_initialize(checkpoints,FEs,alphaFit);

    while FEs<maxFEs
        progress=FEs/maxFEs;
        a=2*(1-progress);

        oldX=X;
        newX=X;
        newFit=fitness;

        for i=1:N
            if FEs>=maxFEs, break; end

            A1=2*a*rand(1,D)-a; C1=2*rand(1,D);
            A2=2*a*rand(1,D)-a; C2=2*rand(1,D);
            A3=2*a*rand(1,D)-a; C3=2*rand(1,D);

            X1=alphaX-A1.*abs(C1.*alphaX-oldX(i,:));
            X2=betaX -A2.*abs(C2.*betaX -oldX(i,:));
            X3=deltaX-A3.*abs(C3.*deltaX-oldX(i,:));

            candidate=(X1+X2+X3)/3;
            candidate=min(max(candidate,lb),ub);
            candidateFit=safe_eval(problem.objective,candidate);
            FEs=FEs+1;

            newX(i,:)=candidate;
            newFit(i)=candidateFit;

            if candidateFit<alphaFit
                alphaFit=candidateFit;
                alphaX=candidate;
            end

            trace=trace_update(trace,FEs,alphaFit);
        end

        X=newX;
        fitness=newFit;
        [fitness,order]=sort(fitness);
        X=X(order,:);

        alphaX=X(1,:); alphaFit=min(alphaFit,fitness(1));
        if fitness(1)<=alphaFit, alphaX=X(1,:); end
        betaX=X(min(2,N),:); betaFit=fitness(min(2,N));
        deltaX=X(min(3,N),:); deltaFit=fitness(min(3,N)); %#ok<NASGU>
    end

    trace=trace_finalize(trace,alphaFit);
    best.position=alphaX;
    best.fitness=alphaFit;
    best.FEs=FEs;
    out.options=options;
    out.betaFitness=betaFit;
    out.deltaFitness=deltaFit;
end

function value=safe_eval(fun,x)
    value=fun(x);
    if ~isfinite(value), value=realmax('double')/100; end
end

function value=get_option(s,name,default)
    if isfield(s,name), value=s.(name); else, value=default; end
end
