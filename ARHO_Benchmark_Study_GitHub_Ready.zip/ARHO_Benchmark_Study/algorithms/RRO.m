function [best,trace,out] = RRO(problem,N,maxFEs,options)
%RRO RRO implementation with local trace helpers.
%
% This version deliberately uses a unique function name and private local
% trace functions. It cannot accidentally call RRO_FE.m or trace_finalize.m
% from an older benchmark folder on the MATLAB path.

    if nargin<4,options=struct();end
    perceptionFactor=get_option(options,'perceptionFactor',3.6);
    leaderFactor=get_option(options,'leaderFactor',3.6);
    nSteps=get_option(options,'nSteps',20);
    weakFraction=get_option(options,'weakFraction',0.4);
    stopProbability=get_option(options,'stopProbability',0.2);
    nTracePoints=get_option(options,'nTracePoints',101);

    D=problem.dim;
    lb=problem.lb;
    ub=problem.ub;
    span=ub-lb;

    rPercept=(span/2)/(perceptionFactor*N^(1/D));
    rLeader=(span/2)/(leaderFactor*N^(1/D));
    nLeader=max(1,round(weakFraction*N));

    X=lb+rand(N,D).*span;
    fit=nan(N,1);
    FEs=0;

    for i=1:N
        fit(i)=safe_eval(problem.objective,X(i,:));
        FEs=FEs+1;
    end

    pbestX=X;
    pbestFit=fit;
    [gbestFit,idx]=min(pbestFit);
    gbestX=pbestX(idx,:);

    checkpoints=make_local_checkpoints(N,maxFEs,nTracePoints);
    trace=initialize_local_trace(checkpoints,FEs,gbestFit);

    while FEs<maxFEs
        leaderIndices=randperm(N,nLeader);
        isLeader=false(N,1);
        isLeader(leaderIndices)=true;

        for i=1:N
            radius=rPercept;
            if isLeader(i)
                radius=rLeader;
            end

            step=0;
            while step<nSteps && FEs<maxFEs
                candidate=X(i,:)+(2*rand(1,D)-1).*radius;
                candidate=min(max(candidate,lb),ub);

                candidateFit=safe_eval(problem.objective,candidate);
                FEs=FEs+1;

                if candidateFit<pbestFit(i)
                    pbestFit(i)=candidateFit;
                    pbestX(i,:)=candidate;

                    % Commit the global best immediately.
                    if candidateFit<gbestFit
                        gbestFit=candidateFit;
                        gbestX=candidate;
                    end

                    if rand<stopProbability
                        X(i,:)=candidate;
                        fit(i)=candidateFit;
                        trace=update_local_trace(trace,FEs,gbestFit);
                        break;
                    end
                end

                X(i,:)=candidate;
                fit(i)=candidateFit;
                step=step+1;

                if pbestFit(i)<gbestFit
                    gbestFit=pbestFit(i);
                    gbestX=pbestX(i,:);
                end

                trace=update_local_trace(trace,FEs,gbestFit);
            end
        end

        [candidateBest,idx]=min(pbestFit);
        if candidateBest<gbestFit
            gbestFit=candidateBest;
            gbestX=pbestX(idx,:);
        end
    end

    trace=finalize_local_trace(trace,gbestFit);

    best.position=gbestX;
    best.fitness=gbestFit;
    best.FEs=FEs;

    out.options=options;
    out.assumptionProfile='Published-reference assumptions';
    out.implementation='RRO';
end

function checkpoints=make_local_checkpoints(initialFEs,maxFEs,nPoints)
    checkpoints=unique(round(linspace(initialFEs,maxFEs,nPoints)));
    checkpoints(1)=initialFEs;
    checkpoints(end)=maxFEs;
end

function trace=initialize_local_trace(checkpoints,currentFEs,currentBest)
    trace.checkpoints=reshape(checkpoints,1,[]);
    trace.best=nan(size(trace.checkpoints));
    trace.nextIndex=1;
    trace=update_local_trace(trace,currentFEs,currentBest);
end

function trace=update_local_trace(trace,currentFEs,currentBest)
    while trace.nextIndex<=numel(trace.checkpoints) && ...
            currentFEs>=trace.checkpoints(trace.nextIndex)

        if trace.nextIndex==1
            recorded=currentBest;
        else
            recorded=min(trace.best(trace.nextIndex-1),currentBest);
        end

        trace.best(trace.nextIndex)=recorded;
        trace.nextIndex=trace.nextIndex+1;
    end
end

function trace=finalize_local_trace(trace,currentBest)
    if trace.nextIndex<=numel(trace.checkpoints)
        if trace.nextIndex==1
            previous=currentBest;
        else
            previous=min(trace.best(trace.nextIndex-1),currentBest);
        end
        trace.best(trace.nextIndex:end)=previous;
    end

    % Final cumulative-minimum projection implemented locally.
    for k=2:numel(trace.best)
        trace.best(k)=min(trace.best(k),trace.best(k-1));
    end

    trace=rmfield(trace,'nextIndex');
end

function value=safe_eval(fun,x)
    value=fun(x);
    if ~isfinite(value)
        value=realmax('double')/100;
    end
end

function value=get_option(s,name,default)
    if isfield(s,name)
        value=s.(name);
    else
        value=default;
    end
end
