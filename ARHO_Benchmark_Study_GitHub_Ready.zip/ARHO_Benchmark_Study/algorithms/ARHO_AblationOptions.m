function opts = ARHO_AblationOptions(opts, variant)
%ARHO_ABLATIONOPTIONS Configure a component-wise ARHO ablation.
%
% Supported variants:
%   "full"
%   "no_hotspot_memory"
%   "no_occupancy"
%   "no_local_verification"
%   "no_leader_following"
%   "no_diversification"
%   "fixed_radius"
%   "no_forgetting"

    variant = lower(string(variant));

    switch variant
        case "full"
            % No change.

        case "no_hotspot_memory"
            opts.useHotspotMemory = false;

        case "no_occupancy"
            opts.useOccupancy = false;

        case "no_local_verification"
            opts.useLocalVerification = false;

        case "no_leader_following"
            opts.useLeaderFollowing = false;

        case "no_diversification"
            opts.useDiversification = false;

        case "fixed_radius"
            opts.useAdaptiveRadius = false;

        case "no_forgetting"
            opts.useForgetting = false;

        otherwise
            error('Unknown ARHO ablation variant: %s', variant);
    end
end
