function [best,trace,out] = PSO(problem,N,maxFEs,options)
%PSO Standard global-best PSO with an exact FE budget.

    if nargin < 4, options = struct(); end
    wMax = get_option(options,'wMax',0.9);
    wMin = get_option(options,'wMin',0.4);
    c1 = get_option(options,'c1',2.0);
    c2 = get_option(options,'c2',2.0);
    velocityFraction = get_option(options,'velocityFraction',0.2);
    nTracePoints = get_option(options,'nTracePoints',101);

    D=problem.dim; lb=problem.lb; ub=problem.ub; span=ub-lb;
    vmax=velocityFraction*span;

    X=lb+rand(N,D).*span;
    V=(2*rand(N,D)-1).*vmax;

    fitness=nan(N,1);
    FEs=0;
    for i=1:N
        fitness(i)=safe_eval(problem.objective,X(i,:));
        FEs=FEs+1;
    end

    pbestX=X;
    pbestFit=fitness;
    [gbestFit,idx]=min(fitness);
    gbestX=X(idx,:);

    checkpoints=make_FE_checkpoints(N,maxFEs,nTracePoints);
    trace=trace_initialize(checkpoints,FEs,gbestFit);

    while FEs<maxFEs
        progress=FEs/maxFEs;
        w=wMax-(wMax-wMin)*progress;

        for i=1:N
            if FEs>=maxFEs, break; end

            V(i,:)=w*V(i,:) ...
                  + c1*rand(1,D).*(pbestX(i,:)-X(i,:)) ...
                  + c2*rand(1,D).*(gbestX-X(i,:));
            V(i,:)=min(max(V(i,:),-vmax),vmax);

            X(i,:)=min(max(X(i,:)+V(i,:),lb),ub);
            fitness(i)=safe_eval(problem.objective,X(i,:));
            FEs=FEs+1;

            if fitness(i)<pbestFit(i)
                pbestFit(i)=fitness(i);
                pbestX(i,:)=X(i,:);
            end
            if fitness(i)<gbestFit
                gbestFit=fitness(i);
                gbestX=X(i,:);
            end

            trace=trace_update(trace,FEs,gbestFit);
        end
    end

    trace=trace_finalize(trace,gbestFit);
    best.position=gbestX;
    best.fitness=gbestFit;
    best.FEs=FEs;
    out.options=options;
end

function value=safe_eval(fun,x)
    value=fun(x);
    if ~isfinite(value), value=realmax('double')/100; end
end

function value=get_option(s,name,default)
    if isfield(s,name), value=s.(name); else, value=default; end
end
