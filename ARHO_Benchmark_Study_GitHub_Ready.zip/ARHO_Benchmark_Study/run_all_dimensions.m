clc;
clear;
close all;

setup_project();

config=default_config();

for D=config.dimensions
    fprintf('\n============================================\n');
    fprintf('Starting the complete D=%d experiment\n',D);
    fprintf('============================================\n');

    output=run_experiment(D,config);
    resultFile=fullfile(output.outputFolder,'BenchmarkResults.mat');

    validate_results(resultFile);
    analyze_results(resultFile);
end

fprintf('\nAll configured dimensions are complete.\n');
