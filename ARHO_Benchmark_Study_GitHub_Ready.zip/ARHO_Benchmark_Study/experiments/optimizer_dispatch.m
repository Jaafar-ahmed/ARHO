function [best,trace,out] = optimizer_dispatch( ...
    algorithmName,problem,N,maxFEs,algorithmOptions)
%OPTIMIZER_DISPATCH Call one registered optimizer.

    if nargin<5,algorithmOptions=struct();end

    switch upper(string(algorithmName))
        case "ARHO"
            [best,trace,out]=ARHO_FE( ...
                problem,N,maxFEs,algorithmOptions);
        case "PSO"
            [best,trace,out]=PSO( ...
                problem,N,maxFEs,algorithmOptions);
        case "DE"
            [best,trace,out]=DE( ...
                problem,N,maxFEs,algorithmOptions);
        case "GWO"
            [best,trace,out]=GWO( ...
                problem,N,maxFEs,algorithmOptions);
        case "RRO"
            [best,trace,out]=RRO( ...
                problem,N,maxFEs,algorithmOptions);
        case "IRRO"
            [best,trace,out]=IRRO( ...
                problem,N,maxFEs,algorithmOptions);
        otherwise
            error('Unknown algorithm: %s',algorithmName);
    end
end
