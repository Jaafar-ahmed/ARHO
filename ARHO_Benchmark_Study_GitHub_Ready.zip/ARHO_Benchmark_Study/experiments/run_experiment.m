function output = run_experiment(D,config)
%RUN_EXPERIMENT Run F1-F13 for all configured optimizers at one dimension.

    if nargin<2 || isempty(config)
        config=default_config();
    end

    validateattributes(D,{'numeric'},{'scalar','integer','positive'});

    maxFEs=config.feBudgetMultiplier*D;
    algorithms=config.algorithms;
    functionIds=config.functionIds;
    nAlgorithms=numel(algorithms);
    nFunctions=numel(functionIds);
    nRuns=config.nRuns;

    outputFolder=fullfile(config.outputRoot,sprintf('D%d',D));
    if ~exist(outputFolder,'dir')
        mkdir(outputFolder);
    end

    finalValues=nan(nFunctions,nAlgorithms,nRuns);
    runtimes=nan(nFunctions,nAlgorithms,nRuns);
    actualFEs=nan(nFunctions,nAlgorithms,nRuns);
    traces=nan(nFunctions,nAlgorithms,nRuns,config.nTracePoints);
    status=strings(nFunctions,nAlgorithms,nRuns);

    rows=cell(nFunctions*nAlgorithms*nRuns,10);
    rowCounter=0;

    for fIndex=1:nFunctions
        fid=functionIds(fIndex);

        for aIndex=1:nAlgorithms
            algorithm=algorithms{aIndex};
            algorithmFolder=fullfile(outputFolder, ...
                sprintf('F%02d',fid),algorithm);

            if ~exist(algorithmFolder,'dir')
                mkdir(algorithmFolder);
            end

            for run=1:nRuns
                seed=config.seeds(run);
                objectiveNoiseSeed=1000000+D*10000+fid*100+run;
                runFile=fullfile(algorithmFolder, ...
                    sprintf('Run_%02d_seed_%d.mat',run,seed));

                problem=getBenchmarkF13(fid,D,objectiveNoiseSeed);
                runStatus="OK";

                if config.resume && exist(runFile,'file')
                    saved=load(runFile,'best','trace','elapsed','runStatus');

                    if isfield(saved,'best') && isfield(saved,'trace') && ...
                            isfield(saved,'elapsed')
                        best=saved.best;
                        trace=saved.trace;
                        elapsed=saved.elapsed;

                        if isfield(saved,'runStatus')
                            runStatus=string(saved.runStatus);
                        else
                            runStatus="LOADED";
                        end

                        fprintf(['D=%d | F%02d | %-5s | run %02d/%02d | ', ...
                            'loaded existing result\n'], ...
                            D,fid,algorithm,run,nRuns);
                        details=struct();
                    else
                        delete(runFile);
                        [best,trace,elapsed,runStatus,details]=execute_run( ...
                            algorithm,problem,config,maxFEs,seed);
                    end
                else
                    [best,trace,elapsed,runStatus,details]=execute_run( ...
                        algorithm,problem,config,maxFEs,seed);
                end

                if config.saveEveryRun && ~exist(runFile,'file')
                    save(runFile,'best','trace','details', ...
                        'algorithm','D','fid','seed','maxFEs', ...
                        'objectiveNoiseSeed','elapsed','runStatus');
                end

                finalValue=best.fitness;
                if ~isfinite(finalValue)
                    finalValue=realmax('double')/100;
                    runStatus="NONFINITE_REPLACED";
                end

                finalValues(fIndex,aIndex,run)=finalValue;
                runtimes(fIndex,aIndex,run)=elapsed;
                actualFEs(fIndex,aIndex,run)=best.FEs;
                traces(fIndex,aIndex,run,:)=reshape(trace.best,1,1,1,[]);
                status(fIndex,aIndex,run)=runStatus;

                rowCounter=rowCounter+1;
                rows(rowCounter,:)={ ...
                    D,fid,string(problem.name),string(algorithm), ...
                    run,seed,maxFEs,finalValue,elapsed,runStatus};
            end
        end
    end

    rawTable=cell2table(rows,'VariableNames',{ ...
        'Dimension','FunctionId','FunctionName','Algorithm', ...
        'Run','Seed','MaxFEs','FinalFitness', ...
        'RuntimeSeconds','Status'});

    writetable(rawTable,fullfile(outputFolder,'RawResults.csv'));
    writematrix(config.seeds,fullfile(outputFolder,'RandomSeeds.txt'));

    checkpoints=make_FE_checkpoints(config.N,maxFEs,config.nTracePoints);
    save(fullfile(outputFolder,'BenchmarkResults.mat'), ...
        'config','D','maxFEs','algorithms','functionIds', ...
        'finalValues','runtimes','actualFEs','traces', ...
        'status','rawTable','checkpoints','-v7.3');

    summary=generate_summary( ...
        D,algorithms,functionIds,finalValues,runtimes,actualFEs);
    writetable(summary,fullfile(outputFolder,'Summary.csv'));

    write_configuration( ...
        fullfile(outputFolder,'ExperimentConfiguration.txt'), ...
        config,D,maxFEs);

    output.finalValues=finalValues;
    output.runtimes=runtimes;
    output.actualFEs=actualFEs;
    output.traces=traces;
    output.status=status;
    output.rawTable=rawTable;
    output.summary=summary;
    output.outputFolder=outputFolder;
end

function [best,trace,elapsed,runStatus,details]=execute_run( ...
    algorithm,problem,config,maxFEs,seed)

    rng(seed,'twister');

    fprintf(['D=%d | F%02d | %-5s | seed=%d | maxFEs=%d\n'], ...
        problem.dim,problem.functionId,algorithm,seed,maxFEs);

    timer=tic;
    try
        options=config.algorithmOptions.(algorithm);
        [best,trace,details]=optimizer_dispatch( ...
            algorithm,problem,config.N,maxFEs,options);
        elapsed=toc(timer);
        runStatus="OK";
    catch ME
        elapsed=toc(timer);
        runStatus="ERROR";
        details.errorMessage=ME.message;
        details.errorReport=getReport(ME,'extended','hyperlinks','off');

        best.position=nan(1,problem.dim);
        best.fitness=realmax('double')/100;
        best.FEs=NaN;

        checkpoints=make_FE_checkpoints( ...
            config.N,maxFEs,config.nTracePoints);
        trace.checkpoints=checkpoints;
        trace.best=repmat(realmax('double')/100,size(checkpoints));
    end
end
