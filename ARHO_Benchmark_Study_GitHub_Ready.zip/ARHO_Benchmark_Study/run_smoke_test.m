clc;
clear;
close all;

projectRoot=setup_project();

config=default_config();
config.nRuns=2;
config.seeds=(1:2)';
config.functionIds=1:2;
config.feBudgetMultiplier=20;
config.outputRoot=fullfile(projectRoot,'results','smoke_test');

output=run_experiment(30,config);
validation=validate_results( ...
    fullfile(output.outputFolder,'BenchmarkResults.mat'));

disp(output.summary);
disp(validation.summary);
