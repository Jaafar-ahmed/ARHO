function write_configuration(filename,config,D,maxFEs)
%WRITE_CONFIGURATION Export all reproducibility settings.

    fid=fopen(filename,'w');
    if fid<0,error('Cannot open %s.',filename);end
    cleanup=onCleanup(@()fclose(fid));

    fprintf(fid,'ARHO benchmark protocol\n');
    fprintf(fid,'=====================================\n');
    fprintf(fid,'Dimension = %d\n',D);
    fprintf(fid,'Population size = %d\n',config.N);
    fprintf(fid,'Independent runs = %d\n',config.nRuns);
    fprintf(fid,'Maximum function evaluations = %d\n',maxFEs);
    fprintf(fid,'FE multiplier = %d*D\n',config.feBudgetMultiplier);
    fprintf(fid,'Functions = %s\n',mat2str(config.functionIds));
    fprintf(fid,'Algorithms = %s\n',strjoin(config.algorithms,', '));
    fprintf(fid,'Seeds = %s\n\n',mat2str(config.seeds'));

    fprintf(fid,'ARHO parameter consistency note:\n');
    fprintf(fid,'rho=0.30, phi=0.90, smin=0.05, matching the revised code.\n');
    fprintf(fid,['The manuscript parameter table must use the same values ', ...
                 'to remain consistent with engineering and benchmark runs.\n\n']);

    names=fieldnames(config.algorithmOptions);
    for k=1:numel(names)
        algorithm=names{k};
        fprintf(fid,'[%s]\n',algorithm);
        opts=config.algorithmOptions.(algorithm);
        fields=fieldnames(opts);
        for j=1:numel(fields)
            value=opts.(fields{j});
            if isnumeric(value)&&isscalar(value)
                fprintf(fid,'%s = %.16g\n',fields{j},value);
            else
                fprintf(fid,'%s = %s\n',fields{j},string(value));
            end
        end
        fprintf(fid,'\n');
    end

    fprintf(fid,'F7 objective noise:\n');
    fprintf(fid,['A dedicated RandStream is recreated for every function/run/', ...
                 'algorithm using the same objectiveNoiseSeed.\n']);
    fprintf(fid,['This provides a common noise sequence across algorithms ', ...
                 'without coupling it to algorithm random draws.\n\n']);

    fprintf(fid,'F2 overflow handling:\n');
    fprintf(fid,['The product term is evaluated in the log domain when needed ', ...
                 'and capped at realmax/100 instead of exporting Inf.\n']);
end
