function validation = validate_results(resultMatFile)
%VALIDATE_RESULTS Check the integrity of benchmark outputs.
%
% Checks:
%   1. all final objective values are finite;
%   2. every completed run reaches the common FE budget exactly;
%   3. best-so-far convergence traces are non-increasing;
%   4. trace arrays do not contain NaN/Inf;
%   5. no run is marked ERROR.

    data=load(resultMatFile);

    values=data.finalValues;
    fes=data.actualFEs;
    traces=data.traces;
    statuses=data.status;
    targetFEs=data.maxFEs;

    finiteFinal=all(isfinite(values(:)));
    finiteTraces=all(isfinite(traces(:)));

    validFEEntries=fes(isfinite(fes));
    exactBudget=~isempty(validFEEntries) && ...
        all(validFEEntries==targetFEs);

    noErrors=all(statuses(:)~="ERROR");

    traceMatrix=reshape(traces,[],size(traces,4));
    tolerance=1e-12;
    monotonicFlags=true(size(traceMatrix,1),1);

    for i=1:size(traceMatrix,1)
        row=traceMatrix(i,:);
        differences=diff(row);
        scale=max(1,max(abs(row)));
        monotonicFlags(i)=all(differences<=tolerance*scale);
    end

    monotonicBestSoFar=all(monotonicFlags);

    checkNames={ ...
        'Finite final values'; ...
        'Finite convergence traces'; ...
        'Exact common FE budget'; ...
        'No ERROR runs'; ...
        'Non-increasing best-so-far traces'};

    passed=[ ...
        finiteFinal; ...
        finiteTraces; ...
        exactBudget; ...
        noErrors; ...
        monotonicBestSoFar];

    validation.summary=table(string(checkNames),passed, ...
        'VariableNames',{'Check','Passed'});

    validation.finiteFinal=finiteFinal;
    validation.finiteTraces=finiteTraces;
    validation.exactBudget=exactBudget;
    validation.noErrors=noErrors;
    validation.monotonicBestSoFar=monotonicBestSoFar;
    validation.failedTraceCount=sum(~monotonicFlags);

    outputFolder=fileparts(resultMatFile);
    writetable(validation.summary, ...
        fullfile(outputFolder,'ValidationChecks.csv'));

    fid=fopen(fullfile(outputFolder,'ValidationReport.txt'),'w');
    fprintf(fid,'Benchmark validation report\n');
    fprintf(fid,'===========================\n');
    fprintf(fid,'Target FEs: %d\n\n',targetFEs);

    for i=1:height(validation.summary)
        fprintf(fid,'%-40s : %d\n', ...
            validation.summary.Check(i), ...
            validation.summary.Passed(i));
    end

    fprintf(fid,'\nFailed trace count: %d\n', ...
        validation.failedTraceCount);
    fclose(fid);

    if ~all(passed)
        warning(['One or more benchmark validation checks failed. ', ...
                 'Inspect ValidationReport.txt before using results.']);
    end
end
