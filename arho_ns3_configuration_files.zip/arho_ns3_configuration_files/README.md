# ARHO ns-3 Configuration Files

This package provides a proof-of-concept ns-3 configuration setup for the Anticipatory Raven Hotspot Optimizer (ARHO) spatial-validation experiment.

The purpose of these files is to document how the hotspot-guided movement logic can be transferred to a distributed mobile-node environment in ns-3. This setup is intended for reproducibility and transparency. It is not a full quantitative network-performance benchmark unless additional repeated PDR/SINR/throughput/delay experiments are added.

## Contents

- `configs/arho_ns3_config.json`: main configuration file.
- `configs/arho_ns3_seeds.csv`: seed list for 30 repeated runs.
- `scratch/arho_hotspot_mobility.cc`: optional ns-3 scratch example for hotspot-guided mobility.
- `scripts/run_arho_ns3.sh`: example batch runner.
- `outputs/`: suggested output directory.

## Suggested manuscript wording

The ns-3 configuration files, random seeds, spatial-validation parameters, and reproducibility scripts are provided in the public repository. The ns-3 experiment is used as a proof-of-concept transferability study of the hotspot-guided spatial-search mechanism rather than as a complete quantitative network-performance validation.

## Example ns-3 usage

Copy `scratch/arho_hotspot_mobility.cc` into the `scratch/` directory of your ns-3 installation, then run:

```bash
./ns3 run "scratch/arho_hotspot_mobility --nNodes=30 --simTime=100 --areaSize=100 --seed=1 --output=outputs/arho_ns3_positions_seed1.csv"
```

For multiple seeds, run:

```bash
bash scripts/run_arho_ns3.sh
```

## Notes

- Default setting: 30 mobile nodes, 100 s simulation time, 100 m x 100 m area.
- Node movement follows a hotspot-guided spatial logic inspired by ARHO.
- For a full quantitative network-performance study, extend the setup with repeated PDR, SINR, throughput, delay, energy-consumption, connectivity-duration, and topology-change-frequency measurements.
