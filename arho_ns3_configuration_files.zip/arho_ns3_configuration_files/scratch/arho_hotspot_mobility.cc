/*
 * ARHO Hotspot Mobility Proof-of-Concept for ns-3
 *
 * This scratch program demonstrates how hotspot-guided movement logic can be
 * mapped to ns-3 mobile nodes. It is intended as a qualitative spatial
 * transferability example, not as a complete quantitative network-performance
 * benchmark.
 *
 * Usage:
 *   ./ns3 run "scratch/arho_hotspot_mobility --nNodes=30 --simTime=100 --areaSize=100 --seed=1 --output=outputs/arho_ns3_positions_seed1.csv"
 */

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/mobility-module.h"

#include <fstream>
#include <cmath>
#include <vector>
#include <algorithm>

using namespace ns3;

struct Hotspot
{
  Vector center;
  double score;
  double radius;
  uint32_t occupancy;
};

static NodeContainer g_nodes;
static std::vector<Hotspot> g_hotspots;
static Ptr<UniformRandomVariable> g_uniform;
static std::ofstream g_out;

static uint32_t g_nNodes = 30;
static double g_areaSize = 100.0;
static double g_updateInterval = 1.0;
static double g_simTime = 100.0;
static double g_alpha = 0.35;
static double g_noiseScale = 0.05;

static double Clamp(double v, double lo, double hi)
{
  return std::max(lo, std::min(v, hi));
}

static double SyntheticQuality(const Vector& p)
{
  const double cx = 0.5 * g_areaSize;
  const double cy = 0.5 * g_areaSize;
  const double sigma = 0.15 * g_areaSize;
  const double dx = p.x - cx;
  const double dy = p.y - cy;
  const double d2 = dx * dx + dy * dy;
  return std::exp(-d2 / (2.0 * sigma * sigma));
}

static void InitializeHotspots()
{
  g_hotspots.clear();
  Hotspot h1;
  h1.center = Vector(0.50 * g_areaSize, 0.50 * g_areaSize, 0.0);
  h1.score = 1.0;
  h1.radius = 0.15 * g_areaSize;
  h1.occupancy = 0;
  g_hotspots.push_back(h1);

  Hotspot h2;
  h2.center = Vector(0.75 * g_areaSize, 0.25 * g_areaSize, 0.0);
  h2.score = 0.8;
  h2.radius = 0.15 * g_areaSize;
  h2.occupancy = 0;
  g_hotspots.push_back(h2);
}

static uint32_t SelectHotspot()
{
  double total = 0.0;
  std::vector<double> weights;
  for (const auto& h : g_hotspots)
    {
      double w = h.score / std::pow(1.0 + h.occupancy, 1.5);
      weights.push_back(w);
      total += w;
    }

  if (total <= 0.0)
    {
      return 0;
    }

  double r = g_uniform->GetValue(0.0, total);
  double acc = 0.0;
  for (uint32_t i = 0; i < weights.size(); ++i)
    {
      acc += weights[i];
      if (r <= acc)
        {
          return i;
        }
    }
  return static_cast<uint32_t>(weights.size() - 1);
}

static void UpdateOccupancy()
{
  for (auto& h : g_hotspots)
    {
      h.occupancy = 0;
    }

  for (uint32_t i = 0; i < g_nNodes; ++i)
    {
      Ptr<MobilityModel> mob = g_nodes.Get(i)->GetObject<MobilityModel>();
      Vector p = mob->GetPosition();

      uint32_t best = 0;
      double bestD = 1e100;
      for (uint32_t j = 0; j < g_hotspots.size(); ++j)
        {
          double dx = p.x - g_hotspots[j].center.x;
          double dy = p.y - g_hotspots[j].center.y;
          double d = std::sqrt(dx * dx + dy * dy);
          if (d < bestD)
            {
              bestD = d;
              best = j;
            }
        }
      if (bestD <= g_hotspots[best].radius)
        {
          g_hotspots[best].occupancy++;
        }
    }
}

static void WritePositions(double t)
{
  for (uint32_t i = 0; i < g_nNodes; ++i)
    {
      Ptr<MobilityModel> mob = g_nodes.Get(i)->GetObject<MobilityModel>();
      Vector p = mob->GetPosition();
      g_out << t << "," << i << "," << p.x << "," << p.y << "," << SyntheticQuality(p) << "\n";
    }
}

static void Step()
{
  double t = Simulator::Now().GetSeconds();
  UpdateOccupancy();

  for (uint32_t i = 0; i < g_nNodes; ++i)
    {
      Ptr<MobilityModel> mob = g_nodes.Get(i)->GetObject<MobilityModel>();
      Vector p = mob->GetPosition();

      uint32_t hIndex = SelectHotspot();
      Vector c = g_hotspots[hIndex].center;

      double nx = g_uniform->GetValue(-g_noiseScale, g_noiseScale) * g_areaSize;
      double ny = g_uniform->GetValue(-g_noiseScale, g_noiseScale) * g_areaSize;

      Vector next;
      next.x = p.x + g_alpha * (c.x - p.x) + nx;
      next.y = p.y + g_alpha * (c.y - p.y) + ny;
      next.z = 0.0;

      next.x = Clamp(next.x, 0.0, g_areaSize);
      next.y = Clamp(next.y, 0.0, g_areaSize);

      mob->SetPosition(next);

      double q = SyntheticQuality(next);
      g_hotspots[hIndex].score = 0.7 * g_hotspots[hIndex].score + 0.3 * q;
    }

  WritePositions(t);

  if (t + g_updateInterval <= g_simTime)
    {
      Simulator::Schedule(Seconds(g_updateInterval), &Step);
    }
}

int main(int argc, char* argv[])
{
  uint32_t seed = 1;
  std::string output = "outputs/arho_ns3_positions_seed1.csv";

  CommandLine cmd;
  cmd.AddValue("nNodes", "Number of mobile nodes", g_nNodes);
  cmd.AddValue("simTime", "Simulation time in seconds", g_simTime);
  cmd.AddValue("areaSize", "Square area side length in meters", g_areaSize);
  cmd.AddValue("updateInterval", "Mobility update interval in seconds", g_updateInterval);
  cmd.AddValue("seed", "Random seed", seed);
  cmd.AddValue("output", "CSV output file", output);
  cmd.Parse(argc, argv);

  RngSeedManager::SetSeed(seed);
  RngSeedManager::SetRun(seed);

  g_uniform = CreateObject<UniformRandomVariable>();
  g_nodes.Create(g_nNodes);

  MobilityHelper mobility;
  Ptr<ListPositionAllocator> positionAlloc = CreateObject<ListPositionAllocator>();
  for (uint32_t i = 0; i < g_nNodes; ++i)
    {
      double x = g_uniform->GetValue(0.0, g_areaSize);
      double y = g_uniform->GetValue(0.0, g_areaSize);
      positionAlloc->Add(Vector(x, y, 0.0));
    }

  mobility.SetPositionAllocator(positionAlloc);
  mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
  mobility.Install(g_nodes);

  InitializeHotspots();

  g_out.open(output.c_str());
  g_out << "time,node_id,x,y,quality\n";

  WritePositions(0.0);
  Simulator::Schedule(Seconds(g_updateInterval), &Step);
  Simulator::Stop(Seconds(g_simTime));
  Simulator::Run();
  Simulator::Destroy();

  g_out.close();
  return 0;
}
