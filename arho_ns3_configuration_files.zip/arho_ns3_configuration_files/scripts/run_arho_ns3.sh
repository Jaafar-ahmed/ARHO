#!/usr/bin/env bash
# Example batch runner for ARHO ns-3 proof-of-concept spatial validation.
# Run this script from the root directory of your ns-3 installation.

set -e
mkdir -p outputs

for seed in $(seq 1 30); do
  echo "Running ARHO ns-3 proof-of-concept simulation with seed ${seed}"
  ./ns3 run "scratch/arho_hotspot_mobility --nNodes=30 --simTime=100 --areaSize=100 --updateInterval=1 --seed=${seed} --output=outputs/arho_ns3_positions_seed${seed}.csv"
done

echo "All runs completed. CSV files are available in outputs/"
