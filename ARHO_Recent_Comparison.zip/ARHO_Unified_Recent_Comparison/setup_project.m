function root=setup_project()
%SETUP_PROJECT Activate only this self-contained comparison package.
    root=fileparts(mfilename('fullpath'));cd(root);restoredefaultpath;
    addpath(root,'-begin');addpath(fullfile(root,'algorithms'),'-begin');addpath(fullfile(root,'benchmarks'),'-begin');
    addpath(fullfile(root,'experiments'),'-begin');addpath(fullfile(root,'statistics'),'-begin');addpath(fullfile(root,'utilities'),'-begin');
    rehash toolboxcache;rehash path;fprintf('Unified ARHO comparison activated:\n%s\n',root);
end
