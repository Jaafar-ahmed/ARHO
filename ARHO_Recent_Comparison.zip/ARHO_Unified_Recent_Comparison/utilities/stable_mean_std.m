function [mu,sigma] = stable_mean_std(values)
%STABLE_MEAN_STD Scale-normalized mean and sample standard deviation.
    values = values(:);
    values = values(isfinite(values));
    if isempty(values)
        mu = realmax('double')/100;
        sigma = 0;
        return;
    end
    scale = max(abs(values));
    if scale==0
        mu=0; sigma=0;
    else
        normalized=values/scale;
        mu=scale*mean(normalized);
        sigma=scale*std(normalized,0);
    end
end
