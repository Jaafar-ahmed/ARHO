function [X0,initializationSeed,postInitializationState] = ...
    common_initial_population(problem,N,D,runSeed)
%COMMON_INITIAL_POPULATION Exact shared X0 and post-initialization RNG state.
%
% The paired run seed is used exactly as it would be in an optimizer that
% generates X0 using rand(N,D). The RNG state after those N*D draws is also
% captured. Before each optimizer starts, the runner restores this state.
% Consequently, all algorithms receive both the same X0 and the same random
% stream state immediately after initialization.

    initializationSeed = runSeed;
    previousState = rng;
    cleanup = onCleanup(@()rng(previousState)); %#ok<NASGU>

    rng(initializationSeed,'twister');
    U = rand(N,D);
    postInitializationState = rng;
    X0 = problem.lb + U.*(problem.ub-problem.lb);
end
