function trace = trace_update(trace,currentFEs,currentBest)
%TRACE_UPDATE Fill all checkpoints reached by the current FE count.

    while trace.nextIndex <= numel(trace.checkpoints) && ...
            currentFEs >= trace.checkpoints(trace.nextIndex)

        trace.best(trace.nextIndex) = currentBest;
        trace.nextIndex = trace.nextIndex + 1;
    end
end
