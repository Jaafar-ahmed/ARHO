function X = validate_initial_population(options,N,D,lb,ub)
%VALIDATE_INITIAL_POPULATION Return supplied X0 or generate a fallback.

    if isfield(options,'initialPopulation') && ~isempty(options.initialPopulation)
        X = options.initialPopulation;
        if ~isequal(size(X),[N,D]) || any(~isfinite(X(:)))
            error('initialPopulation must be a finite N-by-D matrix.');
        end
        tolerance = 1e-12*max(1,max(abs([lb,ub])));
        lowerMatrix = repmat(lb,N,1);
        upperMatrix = repmat(ub,N,1);
        if any(X(:) < lowerMatrix(:) - tolerance) || ...
                any(X(:) > upperMatrix(:) + tolerance)
            error('initialPopulation lies outside the benchmark bounds.');
        end
    else
        X = lb + rand(N,D).*(ub-lb);
    end
    X = min(max(X,lb),ub);
end
