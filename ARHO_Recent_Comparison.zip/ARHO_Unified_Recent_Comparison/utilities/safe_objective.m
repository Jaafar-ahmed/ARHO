function value = safe_objective(problem,x)
%SAFE_OBJECTIVE Finite scalar objective evaluation.
    value = problem.objective(x);
    if ~isscalar(value) || ~isfinite(value) || ~isreal(value)
        value = realmax('double')/100;
    end
end
