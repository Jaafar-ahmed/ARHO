function validation=validate_unified_results(matFile)
%VALIDATE_UNIFIED_RESULTS Integrity and identical-protocol checks.
    data=load(matFile);
    values=data.finalValues;
    fes=data.actualFEs;
    traces=data.traces;
    statuses=data.status;
    targetFEs=data.maxFEs;

    checks=strings(0,1);
    passed=false(0,1);
    [checks,passed]=add_check(checks,passed,'Finite final values',all(isfinite(values(:))));
    [checks,passed]=add_check(checks,passed,'Finite convergence traces',all(isfinite(traces(:))));

    finiteFEs=fes(isfinite(fes));
    exactBudget=~isempty(finiteFEs) && all(finiteFEs==targetFEs);
    [checks,passed]=add_check(checks,passed,'Exact common FE budget',exactBudget);
    [checks,passed]=add_check(checks,passed,'No ERROR runs',all(statuses(:)~="ERROR"));

    traceMatrix=reshape(traces,[],size(traces,4));
    monotonic=true(size(traceMatrix,1),1);
    for i=1:size(traceMatrix,1)
        row=traceMatrix(i,:);
        tolerance=1e-12*max(1,max(abs(row)));
        monotonic(i)=all(diff(row)<=tolerance);
    end
    [checks,passed]=add_check(checks,passed, ...
        'Non-increasing best-so-far traces',all(monotonic));

    identicalX0=true;
    identicalInitialBest=true;
    for f=1:size(data.initSumSq,1)
        for r=1:size(data.initSumSq,3)
            fingerprints=squeeze(data.initSumSq(f,:,r));
            identicalX0=identicalX0 && all(fingerprints==fingerprints(1));

            initialValues=squeeze(data.initialBest(f,:,r));
            identicalInitialBest=identicalInitialBest ...
                && all(isfinite(initialValues)) ...
                && all(initialValues==initialValues(1));
        end
    end
    [checks,passed]=add_check(checks,passed,'Identical X0 across algorithms',identicalX0);
    [checks,passed]=add_check(checks,passed, ...
        'Identical initial best fitness across algorithms',identicalInitialBest);

    complete=all(sum(isfinite(values),3)==data.config.nRuns,'all');
    [checks,passed]=add_check(checks,passed,'Complete run count per cell',complete);

    validation.summary=table(checks,passed,'VariableNames',{'Check','Passed'});
    validation.failedTraceCount=sum(~monotonic);
    outputFolder=fileparts(matFile);
    writetable(validation.summary,fullfile(outputFolder,'ValidationChecks.csv'));

    fid=fopen(fullfile(outputFolder,'ValidationReport.txt'),'w');
    fprintf(fid,'Unified comparison validation\n');
    fprintf(fid,'=============================\n');
    fprintf(fid,'Target FEs: %d\n\n',targetFEs);
    for i=1:height(validation.summary)
        fprintf(fid,'%-46s : %d\n',char(validation.summary.Check(i)), ...
            validation.summary.Passed(i));
    end
    fprintf(fid,'\nFailed trace count: %d\n',validation.failedTraceCount);
    fclose(fid);

    if ~all(passed)
        warning('Validation failed. Do not use these results before correction.');
    end
end

function [names,flags]=add_check(names,flags,name,flag)
    names(end+1,1)=string(name);
    flags(end+1,1)=logical(flag);
end
