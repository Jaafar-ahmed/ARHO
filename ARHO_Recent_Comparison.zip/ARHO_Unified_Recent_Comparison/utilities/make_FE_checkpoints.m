function checkpoints = make_FE_checkpoints(initialFEs,maxFEs,nPoints)
%MAKE_FE_CHECKPOINTS Common convergence-curve evaluation checkpoints.

    if nargin < 3 || isempty(nPoints)
        nPoints = 101;
    end

    checkpoints = unique(round(linspace(initialFEs,maxFEs,nPoints)));
    checkpoints(1) = initialFEs;
    checkpoints(end) = maxFEs;
end
