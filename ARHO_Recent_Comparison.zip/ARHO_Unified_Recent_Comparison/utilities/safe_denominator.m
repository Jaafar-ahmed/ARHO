function d = safe_denominator(d,referenceScale)
%SAFE_DENOMINATOR Preserve sign while avoiding exact zero denominators.
    if nargin<2 || isempty(referenceScale), referenceScale=1; end
    floorValue=eps(max(1,referenceScale));
    mask=abs(d)<floorValue;
    signs=sign(d);
    signs(signs==0)=1;
    d(mask)=signs(mask)*floorValue;
end
