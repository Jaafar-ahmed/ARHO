function trace = trace_initialize(checkpoints,currentFEs,currentBest)
%TRACE_INITIALIZE Initialize a fixed-checkpoint best-so-far recorder.

    trace.checkpoints = reshape(checkpoints,1,[]);
    trace.best = nan(size(trace.checkpoints));
    trace.nextIndex = 1;
    trace = trace_update(trace,currentFEs,currentBest);
end
