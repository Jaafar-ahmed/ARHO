function trace = trace_finalize(trace,currentBest)
%TRACE_FINALIZE Fill remaining checkpoints and enforce best-so-far monotonicity.

    if trace.nextIndex <= numel(trace.checkpoints)
        trace.best(trace.nextIndex:end) = currentBest;
    end

    % Defensive best-so-far projection. For minimization, a recorded
    % convergence curve must never increase between consecutive checkpoints.
    for k = 2:numel(trace.best)
        if trace.best(k) > trace.best(k-1)
            trace.best(k) = trace.best(k-1);
        end
    end

    trace = rmfield(trace,'nextIndex');
end
