function step = levy_step(n,D,beta,scaleFactor)
%LEVY_STEP Mantegna Levy-flight samples.
    if nargin<3 || isempty(beta), beta=1.5; end
    if nargin<4 || isempty(scaleFactor), scaleFactor=0.01; end
    sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
    u=randn(n,D)*sigma;
    v=randn(n,D);
    denominator=max(abs(v).^(1/beta),realmin('double'));
    step=scaleFactor*u./denominator;
end
