function opts = ARHO_DefaultOptions(N)
%ARHO_DEFAULTOPTIONS Default settings for the reviewer-ready ARHO code.
%
%   opts = ARHO_DefaultOptions(N)
%
% All constrained problems use feasibility-first selection. The raw
% engineering objective is never replaced by a penalized value in the
% reported results.

    if nargin < 1 || isempty(N)
        N = 30;
    end

    % Hotspot archive and memory
    opts.tau = 0.20;
    opts.lambdaC = 0.50;
    opts.rho = 0.30;
    opts.phi = 0.90;
    opts.smin = 0.05;
    opts.noImproveL = 5;
    opts.qualityTol = 1e-12;

    % Hotspot selection
    opts.beta = 5.0;
    opts.kappa = 1.5;

    % Broad anticipatory movement
    opts.alphaMax = 2.0;
    opts.alphaMin = 0.2;
    opts.sigmaMax = 0.10;
    opts.mu = 2.0;

    % Local verification
    opts.etaMax = 0.10;
    opts.etaMin = 0.01;

    % Adaptive hotspot radius, expressed as normalized search-range fractions
    opts.gammaD = 0.90;
    opts.gammaE = 1.10;
    opts.initRadiusFrac = 0.10;
    opts.minRadiusFrac = 0.02;
    opts.maxRadiusFrac = 0.30;
    opts.membershipFrac = 0.15;
    opts.occRadiusFrac = 0.10;

    % Sparse leader following
    opts.gamma = 0.30;
    opts.delta = 1e-6;
    opts.Smax = 10;
    opts.p0 = 0.05;
    opts.p1 = 0.25;

    % Occupancy-aware diversification
    opts.xi = 0.05;
    opts.eps0 = 1e-12;
    opts.nmax = max(2, round(0.30 * N));

    % Archive size
    opts.maxHotspots = max(5, ceil(0.50 * N));

    % Verification and comparison tolerances
    opts.feasibilityTol = 1e-6;
    opts.comparisonTol = 1e-12;

    % Reproducible evaluation budget
    opts.maxFEs = 30000;
    opts.scheduleByFEs = true;

    % Output
    opts.verbose = true;
    opts.displayInterval = 50;

    % Ablation switches
    opts.useHotspotMemory = true;
    opts.useOccupancy = true;
    opts.useLocalVerification = true;
    opts.useLeaderFollowing = true;
    opts.useDiversification = true;
    opts.useAdaptiveRadius = true;
    opts.useForgetting = true;
end
