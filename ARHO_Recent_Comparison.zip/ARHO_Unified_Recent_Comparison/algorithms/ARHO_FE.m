function [best,trace,out] = ARHO_FE(problem,N,maxFEs,options)
%ARHO_FE Function-evaluation-budget wrapper for ARHO.

    if nargin<4,options=struct();end

    opts=ARHO_DefaultOptions(N);
    fields=fieldnames(options);
    for k=1:numel(fields)
        opts.(fields{k})=options.(fields{k});
    end

    opts.maxFEs=maxFEs;
    opts.scheduleByFEs=true;
    opts.verbose=false;

    maxIterations=ceil(maxFEs/N)+20;
    [arhoBest,history,arhoOut]=ARHO( ...
        problem,N,maxIterations,opts);

    checkpoints=make_FE_checkpoints(N,maxFEs, ...
        get_option(options,'nTracePoints',101));

    values=nan(size(checkpoints));
    initialFit=arhoOut.initialBest.raw;

    for c=1:numel(checkpoints)
        idx=find(history.functionEvaluations<=checkpoints(c),1,'last');
        if isempty(idx)
            values(c)=initialFit;
        else
            values(c)=history.bestRaw(idx);
        end
    end
    values(end)=arhoBest.raw;
    for k=2:numel(values)
        values(k)=min(values(k),values(k-1));
    end

    trace.checkpoints=checkpoints;
    trace.best=values;

    best.position=arhoBest.searchX;
    best.fitness=arhoBest.raw;
    best.FEs=arhoOut.functionEvaluations;
    out=arhoOut;
end

function value=get_option(s,name,default)
    if isfield(s,name),value=s.(name);else,value=default;end
end
