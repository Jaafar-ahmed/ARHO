function [index, probabilities] = ARHO_SelectHotspot(archive, opts)
%ARHO_SELECTHOTSPOT Stable occupancy-aware roulette-wheel selection.
%
% Implements the numerically stable form of Eqs. (21)-(22):
%   log(w_j) = beta*(s_j-s_max) - kappa*log(1+n_j)

    if isempty(archive)
        error('The hotspot archive is empty.');
    end

    scores = [archive.s];
    occupancy = [archive.n];

    if ~opts.useOccupancy
        occupancy(:) = 0;
    end

    logWeights = opts.beta .* (scores - max(scores)) ...
               - opts.kappa .* log(1 + occupancy);
    logWeights = logWeights - max(logWeights);

    weights = exp(logWeights);
    totalWeight = sum(weights);

    if ~isfinite(totalWeight) || totalWeight <= 0
        probabilities = ones(1, numel(archive)) / numel(archive);
    else
        probabilities = weights / totalWeight;
    end

    cumulative = cumsum(probabilities);
    r = rand;
    index = find(r <= cumulative, 1, 'first');

    if isempty(index)
        index = numel(archive);
    end
end
