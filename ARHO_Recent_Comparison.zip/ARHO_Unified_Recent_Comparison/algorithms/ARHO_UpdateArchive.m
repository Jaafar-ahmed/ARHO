function archive = ARHO_UpdateArchive(archive, X, records, eliteIdx, problem, opts)
%ARHO_UPDATEARCHIVE Update ARHO spatial hotspot memory.
%
% This implementation includes:
%   - feasibility-aware elite assignment,
%   - revised quality normalization valid for negative objectives,
%   - explicit no-improvement counters,
%   - corrected two-stage score and forgetting update,
%   - normalized-distance occupancy calculation.

    lb = reshape(problem.lb, 1, []);
    ub = reshape(problem.ub, 1, []);
    span = ub - lb;
    D = problem.dim;

    if ~opts.useHotspotMemory
        bestRec = records(eliteIdx(1));
        archive = create_hotspot(bestRec.searchX, bestRec, opts);
        archive.s = 1;
        archive.qprev = 1;
        archive.n = count_occupancy(archive.c, archive.sigma, X, span, D, opts);
        return;
    end

    assignments = cell(1, numel(archive));

    % Assign elite solutions to existing hotspots or create new hotspots.
    for q = 1:numel(eliteIdx)
        idx = eliteIdx(q);
        x = X(idx,:);

        if isempty(archive)
            archive = create_hotspot(x, records(idx), opts);
            assignments = {idx};
            continue;
        end

        distances = zeros(1, numel(archive));
        for j = 1:numel(archive)
            distances(j) = normalized_distance(x, archive(j).c, span, D);
        end

        [minimumDistance, nearest] = min(distances);
        assignmentRadius = max(archive(nearest).sigma, opts.membershipFrac);

        if minimumDistance <= assignmentRadius
            assignments{nearest}(end+1) = idx;
        else
            archive(end+1) = create_hotspot(x, records(idx), opts); %#ok<AGROW>
            assignments{end+1} = idx; %#ok<AGROW>
        end
    end

    updated = false(1, numel(archive));

    % Center update and regional representative update.
    for j = 1:numel(archive)
        if j <= numel(assignments) && ~isempty(assignments{j})
            assigned = assignments{j};
            updated(j) = true;

            newCenter = mean(X(assigned,:), 1);
            archive(j).c = (1 - opts.lambdaC) .* archive(j).c ...
                         + opts.lambdaC .* newCenter;
            archive(j).c = ARHO_BoundaryControl( ...
                archive(j).c, lb, ub, problem.integerIndices);

            assignedRecords = records(assigned);
            assignedOrder = sort_record_indices( ...
                assignedRecords, opts.comparisonTol);
            archive(j).rep = assignedRecords(assignedOrder(1));
        end
    end

    % Revised Eq. (14): feasibility-aware normalized hotspot quality.
    representatives = [archive.rep];
    regionalMerit = feasibility_aware_merit(representatives);
    quality = normalized_quality(regionalMerit);

    % Revised Eqs. (15)-(19).
    for j = 1:numel(archive)
        temporaryScore = (1 - opts.rho) * archive(j).s ...
                       + opts.rho * quality(j);

        improved = updated(j) && ...
            quality(j) > archive(j).qprev + opts.qualityTol;

        if improved
            archive(j).nu = 0;

            if opts.useAdaptiveRadius
                archive(j).sigma = max(opts.minRadiusFrac, ...
                    opts.gammaD * archive(j).sigma);
            end
        else
            archive(j).nu = archive(j).nu + 1;

            if opts.useAdaptiveRadius
                archive(j).sigma = min(opts.maxRadiusFrac, ...
                    opts.gammaE * archive(j).sigma);
            end
        end

        if opts.useForgetting && archive(j).nu >= opts.noImproveL
            archive(j).s = opts.phi * temporaryScore;
        else
            archive(j).s = temporaryScore;
        end

        archive(j).qprev = quality(j);
    end

    % Remove weak hotspots while preserving at least one.
    scores = [archive.s];
    keep = scores >= opts.smin;

    if ~any(keep)
        [~, strongest] = max(scores);
        keep(strongest) = true;
    end

    archive = archive(keep);

    % Limit archive size, preserving the best representative.
    if numel(archive) > opts.maxHotspots
        reps = [archive.rep];
        repOrder = sort_record_indices(reps, opts.comparisonTol);
        bestRep = repOrder(1);

        [~, scoreOrder] = sort([archive.s], 'descend');
        chosen = bestRep;

        for k = 1:numel(scoreOrder)
            if ~ismember(scoreOrder(k), chosen)
                chosen(end+1) = scoreOrder(k); %#ok<AGROW>
            end
            if numel(chosen) >= opts.maxHotspots
                break;
            end
        end

        archive = archive(chosen);
    end

    % Occupancy update, corresponding to Eq. (20).
    for j = 1:numel(archive)
        if opts.useOccupancy
            archive(j).n = count_occupancy( ...
                archive(j).c, archive(j).sigma, X, span, D, opts);
        else
            archive(j).n = 0;
        end
    end
end

function hotspot = create_hotspot(center, rec, opts)
    hotspot.c = center;
    hotspot.s = 1.0;
    hotspot.n = 0;
    hotspot.sigma = opts.initRadiusFrac;
    hotspot.qprev = 0;
    hotspot.nu = 0;
    hotspot.rep = rec;
end

function count = count_occupancy(center, sigma, X, span, D, opts)
    effectiveRadius = max(sigma, opts.occRadiusFrac);
    count = 0;

    for i = 1:size(X,1)
        if normalized_distance(X(i,:), center, span, D) <= effectiveRadius
            count = count + 1;
        end
    end
end

function d = normalized_distance(x1, x2, span, D)
    z = (x1 - x2) ./ span;
    d = norm(z) / sqrt(D);
end

function merit = feasibility_aware_merit(records)
% Lower regional merit is better.
% Feasible records occupy [0,1); infeasible records occupy [1,2].

    K = numel(records);
    feasible = false(1,K);
    searchMerit = zeros(1,K);
    violation = zeros(1,K);

    for j = 1:K
        feasible(j) = records(j).feasible;
        searchMerit(j) = finite_or_large(records(j).merit);
        violation(j) = finite_or_large(records(j).vsum);
    end

    merit = zeros(1,K);

    if any(feasible)
        merit(feasible) = normalize_zero_one(searchMerit(feasible));

        if any(~feasible)
            merit(~feasible) = 1 + ...
                normalize_zero_one(violation(~feasible));
        end
    else
        merit = normalize_zero_one(violation);
    end
end

function Q = normalized_quality(merit)
% Revised Eq. (14):
% Q_j = (f_worst-f_j+epsilon)/(f_worst-f_best+epsilon)

    epsilonQ = 1e-12;
    bestMerit = min(merit);
    worstMerit = max(merit);
    meritRange = worstMerit - bestMerit;

    if meritRange <= epsilonQ
        Q = ones(size(merit));
    else
        Q = (worstMerit - merit + epsilonQ) ...
          ./ (meritRange + epsilonQ);
        Q = min(1, max(epsilonQ, Q));
    end
end

function order = sort_record_indices(records, tol)
    K = numel(records);
    keys = zeros(K,4);

    for i = 1:K
        keys(i,1) = double(~records(i).feasible);

        if records(i).feasible
            keys(i,2) = finite_or_large(records(i).merit);
            keys(i,3) = finite_or_large(records(i).vmax);
            keys(i,4) = finite_or_large(records(i).vsum);
        else
            keys(i,2) = finite_or_large(records(i).vsum);
            keys(i,3) = finite_or_large(records(i).vmax);
            keys(i,4) = finite_or_large(records(i).merit);
        end
    end

    keys(:,4) = keys(:,4) + (0:K-1)' * tol * eps;
    [~, order] = sortrows(keys, [1 2 3 4]);
    order = reshape(order, 1, []);
end

function y = normalize_zero_one(x)
    xmin = min(x);
    xmax = max(x);
    rangeX = xmax - xmin;

    if rangeX <= 1e-12
        y = zeros(size(x));
    else
        y = (x - xmin) ./ rangeX;
    end
end

function value = finite_or_large(value)
    if ~isfinite(value)
        value = realmax('double') / 100;
    end
end
