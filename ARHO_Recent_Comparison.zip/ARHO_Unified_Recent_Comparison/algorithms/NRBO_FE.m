function [best,trace,out] = NRBO_FE(problem,N,maxFEs,options)
%NRBO_FE Newton-Raphson-Based Optimizer with an exact FE budget.
% Protocol adaptation of the original 2024 NRBO equations.

    if nargin<4,options=struct();end
    D=problem.dim; lb=reshape(problem.lb,1,[]); ub=reshape(problem.ub,1,[]);
    if N<3,error('NRBO requires N >= 3.');end
    X=validate_initial_population(options,N,D,lb,ub);
    fitness=nan(N,1); FEs=0;
    for i=1:N
        fitness(i)=safe_objective(problem,X(i,:)); FEs=FEs+1;
    end
    initialFitness=fitness;
    [bestFit,bestIndex]=min(fitness); bestX=X(bestIndex,:);
    [worstFit,worstIndex]=max(fitness); worstX=X(worstIndex,:);
    checkpoints=make_FE_checkpoints(N,maxFEs,get_option(options,'nTracePoints',101));
    trace=trace_initialize(checkpoints,FEs,bestFit);
    DF=get_option(options,'DF',0.6);
    maxCycles=max(1,ceil((maxFEs-N)/N)); cycle=0;

    while FEs<maxFEs
        cycle=cycle+1;
        delta=(1-(2*cycle/maxCycles))^5;
        for i=1:N
            if FEs>=maxFEs,break;end
            idx=randperm(N,2); a1=idx(1); a2=idx(2);
            rho=rand*(bestX-X(i,:))+rand*(X(a1,:)-X(a2,:));
            nrsr=search_rule(bestX,worstX,X(i,:),rho,true);
            x1=X(i,:)-nrsr+rho;
            x2=bestX-nrsr+rho;
            xupdate=zeros(1,D);
            for j=1:D
                x3=X(i,j)-delta*(x2(j)-x1(j));
                r1=rand; r2=rand;
                xupdate(j)=r1*(r1*x1(j)+(1-r2)*x2(j))+(1-r2)*x3;
            end
            if rand<DF
                theta1=-1+2*rand; theta2=-0.5+rand;
                beta=rand<0.5;
                u1=beta*3*rand+(1-beta); u2=beta*rand+(1-beta);
                populationMean=mean(X,1);
                if u1<0.5
                    xnew=xupdate+theta1*(u1*bestX-u2*X(i,:)) ...
                        +theta2*delta*(u1*populationMean-u2*X(i,:));
                else
                    xnew=bestX+theta1*(u1*bestX-u2*X(i,:)) ...
                        +theta2*delta*(u1*populationMean-u2*X(i,:));
                end
            else
                xnew=xupdate;
            end
            xnew=min(max(xnew,lb),ub);
            fnew=safe_objective(problem,xnew); FEs=FEs+1;
            if fnew<fitness(i)
                X(i,:)=xnew; fitness(i)=fnew;
                if fnew<bestFit,bestFit=fnew;bestX=xnew;end
            end
            if fitness(i)>worstFit,worstFit=fitness(i);worstX=X(i,:);end
            trace=trace_update(trace,FEs,bestFit);
        end
    end
    trace=trace_finalize(trace,bestFit);
    best=struct('position',bestX,'fitness',bestFit,'FEs',FEs);
    out=struct('cycles',cycle,'initialFitness',initialFitness, ...
        'finalPopulation',X,'finalFitness',fitness,'numericalSafeguard','denominator floor only');
end

function nrsr=search_rule(best,worst,current,rho,flag)
    D=numel(current);
    delX=rand(1,D).*abs(best-current);
    denom=2*(best+worst-2*current);
    denom=safe_denominator(denom,max(abs([best,worst,current])));
    nrsr=randn*((best-worst).*delX)./denom;
    if flag,xa=current-nrsr+rho;else,xa=best-nrsr+rho;end
    r1=rand;r2=rand;
    yp=r1*(mean(xa+current)+r1*delX);
    yq=r2*(mean(xa+current)-r2*delX);
    denom2=2*(yp+yq-2*current);
    denom2=safe_denominator(denom2,max(abs([yp,yq,current])));
    nrsr=randn*((yp-yq).*delX)./denom2;
end
function value=get_option(s,name,default)
    if isfield(s,name),value=s.(name);else,value=default;end
end
