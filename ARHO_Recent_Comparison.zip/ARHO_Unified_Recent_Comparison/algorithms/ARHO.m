function [best, history, out] = ARHO( ...
    problem, N, MaxIter, userOptions)
%ARHO Anticipatory Raven Hotspot Optimizer.
%
%   [best,history,out] = ARHO(problem,N,MaxIter,options)
%
% The implementation provides:
%   - revised hotspot quality for positive and negative objectives,
%   - explicit no-improvement counters,
%   - corrected forgetting update,
%   - feasibility-first constraint handling,
%   - mixed/integer variable repair,
%   - exact function-evaluation counting,
%   - raw-objective reporting separate from search comparison.

    if nargin < 4
        userOptions = struct();
    end

    defaults = ARHO_DefaultOptions(N);
    opts = merge_options(defaults, userOptions);

    validate_problem(problem, N, MaxIter);

    lb = reshape(problem.lb, 1, []);
    ub = reshape(problem.ub, 1, []);
    span = ub - lb;
    D = problem.dim;

    % ------------------------------------------------------------
    % Population initialization
    % ------------------------------------------------------------
    % For the unified comparison, the runner may provide an exact shared
    % initial population. This changes initialization only; every ARHO
    % search/update equation remains unchanged.
    if isfield(opts,'initialPopulation') && ~isempty(opts.initialPopulation)
        X = opts.initialPopulation;
        if ~isequal(size(X),[N,D]) || any(~isfinite(X(:)))
            error('initialPopulation must be a finite N-by-D matrix.');
        end
    else
        X = lb + rand(N,D) .* span;
    end

    for i = 1:N
        X(i,:) = ARHO_BoundaryControl( ...
            X(i,:), lb, ub, problem.integerIndices);
    end

    firstRecord = problem.evaluate(X(1,:), opts.feasibilityTol);
    records = repmat(firstRecord, 1, N);
    FEs = 1;

    for i = 2:N
        if FEs >= opts.maxFEs
            error('The FE budget must be at least the population size.');
        end
        records(i) = problem.evaluate(X(i,:), opts.feasibilityTol);
        FEs = FEs + 1;
    end

    order = sort_record_indices(records, opts.comparisonTol);
    best = records(order(1));
    initialBest = best;

    archive = struct('c',{},'s',{},'n',{},'sigma',{}, ...
                     'qprev',{},'nu',{},'rep',{});

    history.bestRaw = nan(MaxIter,1);
    history.bestMerit = nan(MaxIter,1);
    history.bestVsum = nan(MaxIter,1);
    history.bestVmax = nan(MaxIter,1);
    history.bestFeasible = false(MaxIter,1);
    history.functionEvaluations = nan(MaxIter,1);
    history.archiveSize = nan(MaxIter,1);

    globalStagnation = 0;
    lastImprovement = 0;
    iterationsCompleted = 0;
    budgetReached = false;

    for t = 1:MaxIter
        if FEs >= opts.maxFEs
            budgetReached = true;
            break;
        end

        previousBest = best;

        order = sort_record_indices(records, opts.comparisonTol);
        eliteCount = max(1, ceil(opts.tau * N));
        eliteIdx = order(1:eliteCount);

        archive = ARHO_UpdateArchive( ...
            archive, X, records, eliteIdx, problem, opts);

        if isempty(archive)
            error('ARHO archive update returned an empty archive.');
        end

        if opts.scheduleByFEs && isfinite(opts.maxFEs)
            progress = FEs / opts.maxFEs;
        else
            progress = t / MaxIter;
        end
        progress = min(1, max(0, progress));

        leaderTrigger = (lastImprovement > opts.delta) || ...
                        (globalStagnation >= opts.Smax);

        Xnew = X;
        newRecords = records;

        for i = 1:N
            if FEs >= opts.maxFEs
                budgetReached = true;
                break;
            end

            [h, ~] = ARHO_SelectHotspot(archive, opts);

            state.progress = progress;
            state.leaderTrigger = leaderTrigger;
            state.currentFEs = FEs;
            state.maxFEs = opts.maxFEs;

            [candidate, usedFEs] = ARHO_GenerateCandidate( ...
                problem, X(i,:), records(i), archive(h), ...
                best, state, opts);

            FEs = FEs + usedFEs;

            % The manuscript uses greedy selection between broad/local
            % candidates. Leader and diversification candidates are also
            % accepted only when they improve the selected candidate.
            Xnew(i,:) = candidate.searchX;
            newRecords(i) = candidate;
        end

        X = Xnew;
        records = newRecords;

        order = sort_record_indices(records, opts.comparisonTol);
        iterationBest = records(order(1));

        if is_better(iterationBest, best, opts.comparisonTol)
            best = iterationBest;
        end

        lastImprovement = improvement_measure( ...
            previousBest, best, opts.comparisonTol);

        if is_better(best, previousBest, opts.comparisonTol)
            globalStagnation = 0;
        else
            globalStagnation = globalStagnation + 1;
        end

        iterationsCompleted = t;
        history.bestRaw(t) = best.raw;
        history.bestMerit(t) = best.merit;
        history.bestVsum(t) = best.vsum;
        history.bestVmax(t) = best.vmax;
        history.bestFeasible(t) = best.feasible;
        history.functionEvaluations(t) = FEs;
        history.archiveSize(t) = numel(archive);

        if opts.verbose && ...
                (t == 1 || mod(t,opts.displayInterval) == 0 || t == MaxIter)
            fprintf(['Iter %4d | FEs %7d | Raw %.12g | ', ...
                     'Vmax %.3e | Feasible %d | Hotspots %d\n'], ...
                    t, FEs, best.raw, best.vmax, ...
                    best.feasible, numel(archive));
        end

        if budgetReached
            break;
        end
    end

    fields = fieldnames(history);
    for k = 1:numel(fields)
        history.(fields{k}) = ...
            history.(fields{k})(1:iterationsCompleted,:);
    end

    out.initialBest = initialBest;
    out.finalPopulation = X;
    out.finalRecords = records;
    out.finalArchive = archive;
    out.options = opts;
    out.functionEvaluations = FEs;
    out.iterationsCompleted = iterationsCompleted;
    out.budgetReached = budgetReached;
end

function opts = merge_options(defaults, userOptions)
    opts = defaults;

    if isempty(userOptions)
        return;
    end

    fields = fieldnames(userOptions);
    for k = 1:numel(fields)
        opts.(fields{k}) = userOptions.(fields{k});
    end
end

function validate_problem(problem, N, MaxIter)
    required = {'name','dim','lb','ub','integerIndices', ...
                'evaluate','verify','sense'};

    for k = 1:numel(required)
        if ~isfield(problem, required{k})
            error('Missing problem field: %s', required{k});
        end
    end

    if N < 2 || N ~= round(N)
        error('N must be an integer greater than or equal to 2.');
    end

    if MaxIter < 1 || MaxIter ~= round(MaxIter)
        error('MaxIter must be a positive integer.');
    end

    if numel(problem.lb) ~= problem.dim || ...
            numel(problem.ub) ~= problem.dim
        error('The lengths of lb and ub must equal problem.dim.');
    end

    if any(problem.ub <= problem.lb)
        error('Every upper bound must exceed its lower bound.');
    end
end

function order = sort_record_indices(records, tol)
    K = numel(records);
    keys = zeros(K,4);

    for i = 1:K
        keys(i,1) = double(~records(i).feasible);

        if records(i).feasible
            keys(i,2) = finite_or_large(records(i).merit);
            keys(i,3) = finite_or_large(records(i).vmax);
            keys(i,4) = finite_or_large(records(i).vsum);
        else
            keys(i,2) = finite_or_large(records(i).vsum);
            keys(i,3) = finite_or_large(records(i).vmax);
            keys(i,4) = finite_or_large(records(i).merit);
        end
    end

    keys(:,4) = keys(:,4) + (0:K-1)' * tol * eps;
    [~,order] = sortrows(keys, [1 2 3 4]);
    order = reshape(order,1,[]);
end

function tf = is_better(a, b, tol)
    if a.feasible && ~b.feasible
        tf = true;
        return;
    elseif ~a.feasible && b.feasible
        tf = false;
        return;
    end

    if a.feasible && b.feasible
        tf = strictly_less(a.merit, b.merit, tol);
        return;
    end

    if strictly_less(a.vsum, b.vsum, tol)
        tf = true;
    elseif strictly_equal(a.vsum, b.vsum, tol)
        if strictly_less(a.vmax, b.vmax, tol)
            tf = true;
        elseif strictly_equal(a.vmax, b.vmax, tol)
            tf = strictly_less(a.merit, b.merit, tol);
        else
            tf = false;
        end
    else
        tf = false;
    end
end

function delta = improvement_measure(oldRec, newRec, tol)
    if ~is_better(newRec, oldRec, tol)
        delta = 0;
        return;
    end

    if ~oldRec.feasible && newRec.feasible
        delta = max(1, finite_or_large(oldRec.vsum));
    elseif oldRec.feasible && newRec.feasible
        delta = max(0, oldRec.merit - newRec.merit);
    else
        delta = max(0, oldRec.vsum - newRec.vsum);
    end
end

function tf = strictly_less(a, b, tol)
    scale = max([1, abs(a), abs(b)]);
    tf = a < b - tol * scale;
end

function tf = strictly_equal(a, b, tol)
    scale = max([1, abs(a), abs(b)]);
    tf = abs(a - b) <= tol * scale;
end

function value = finite_or_large(value)
    if ~isfinite(value)
        value = realmax('double') / 100;
    end
end
