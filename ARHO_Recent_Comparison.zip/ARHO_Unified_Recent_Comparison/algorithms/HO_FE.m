function [best,trace,out] = HO_FE(problem,N,maxFEs,options)
%HO_FE Hippopotamus Optimization Algorithm with exact FE accounting.
% Implements the three original phases; every objective call is counted.

    if nargin<4,options=struct();end
    D=problem.dim; lb=reshape(problem.lb,1,[]); ub=reshape(problem.ub,1,[]);
    if N<4,error('HO requires N >= 4.');end
    X=validate_initial_population(options,N,D,lb,ub);
    fit=nan(N,1);FEs=0;
    for i=1:N,fit(i)=safe_objective(problem,X(i,:));FEs=FEs+1;end
    [bestFit,idx]=min(fit);bestX=X(idx,:);initialFitness=fit;
    checkpoints=make_FE_checkpoints(N,maxFEs,get_option(options,'nTracePoints',101));
    trace=trace_initialize(checkpoints,FEs,bestFit);
    evaluationsPerCycle=3*N;
    maxCycles=max(1,ceil((maxFEs-N)/evaluationsPerCycle));cycle=0;
    half=floor(N/2);

    while FEs<maxFEs
        cycle=cycle+1;
        [currentBest,idx]=min(fit);
        if currentBest<bestFit,bestFit=currentBest;bestX=X(idx,:);end
        T=exp(-cycle/maxCycles);

        % Phase 1: river/pond exploration (two candidates per first-half agent)
        for i=1:half
            if FEs>=maxFEs,break;end
            I1=randi([1,2]);I2=randi([1,2]);Ip1=randi([0,1],1,2);
            groupCount=randi(N);group=randperm(N,groupCount);meanGroup=mean(X(group,:),1);
            alphaSet={I2*rand(1,D)+(~Ip1(1)),2*rand(1,D)-1,rand(1,D), ...
                      I1*rand(1,D)+(~Ip1(2)),rand};
            A=alphaSet{randi(5)};B=alphaSet{randi(5)};
            baseXi=X(i,:);
            baseBest=bestX;
            x1=baseXi+rand*(baseBest-I1*baseXi);
            if T>0.6
                x2=baseXi+A.*(baseBest-I2*meanGroup);
            elseif rand>0.5
                x2=baseXi+B.*(meanGroup-baseBest);
            else
                x2=lb+rand(1,D).*(ub-lb);
            end
            x1=min(max(x1,lb),ub);
            x2=min(max(x2,lb),ub);

            f1=safe_objective(problem,x1);
            FEs=FEs+1;
            if f1<fit(i)
                X(i,:)=x1;
                fit(i)=f1;
                if f1<bestFit
                    bestFit=f1;
                    bestX=x1;
                end
            end
            trace=trace_update(trace,FEs,bestFit);
            if FEs>=maxFEs,break;end

            f2=safe_objective(problem,x2);
            FEs=FEs+1;
            if f2<fit(i)
                X(i,:)=x2;
                fit(i)=f2;
                if f2<bestFit
                    bestFit=f2;
                    bestX=x2;
                end
            end
            trace=trace_update(trace,FEs,bestFit);
        end
        if FEs>=maxFEs,break;end

        % Phase 2: defense against predators (predator evaluation is counted)
        for i=half+1:N
            if FEs>=maxFEs,break;end
            predator=lb+rand(1,D).*(ub-lb);
            predatorFit=safe_objective(problem,predator);FEs=FEs+1;
            trace=trace_update(trace,FEs,bestFit);
            if FEs>=maxFEs,break;end
            distance=max(abs(predator-X(i,:)),eps(max(1,max(abs(ub-lb)))));
            b=2+2*rand;c=1+0.5*rand;d=2+rand;l=-2*pi+4*pi*rand;
            RL=0.05*levy_step(1,D,1.5,1.0);
            if fit(i)>predatorFit
                x3=RL.*predator+(b/(c-d*cos(l))).*(1./distance);
            else
                x3=RL.*predator+(b/(c-d*cos(l))).*(1./(2*distance+rand(1,D)));
            end
            x3=min(max(x3,lb),ub);
            f3=safe_objective(problem,x3);FEs=FEs+1;
            if f3<fit(i)
                X(i,:)=x3;
                fit(i)=f3;
                if f3<bestFit
                    bestFit=f3;
                    bestX=x3;
                end
            end
            trace=trace_update(trace,FEs,bestFit);
        end
        if FEs>=maxFEs,break;end

        % Phase 3: escaping/exploitation
        localLb=lb/max(1,cycle);localUb=ub/max(1,cycle);
        for i=1:N
            if FEs>=maxFEs,break;end
            alphaSet={2*rand(1,D)-1,rand,randn};Dcoef=alphaSet{randi(3)};
            x4=X(i,:)+rand*(localLb+Dcoef.*(localUb-localLb));
            x4=min(max(x4,lb),ub);
            f4=safe_objective(problem,x4);FEs=FEs+1;
            if f4<fit(i)
                X(i,:)=x4;
                fit(i)=f4;
                if f4<bestFit
                    bestFit=f4;
                    bestX=x4;
                end
            end
            trace=trace_update(trace,FEs,bestFit);
        end
    end
    trace=trace_finalize(trace,bestFit);
    best=struct('position',bestX,'fitness',bestFit,'FEs',FEs);
    out=struct('cycles',cycle,'initialFitness',initialFitness,'finalPopulation',X,'finalFitness',fit);
end
function value=get_option(s,name,default)
    if isfield(s,name),value=s.(name);else,value=default;end
end
