function [best,trace,out] = SFOA_FE(problem,N,maxFEs,options)
%SFOA_FE Starfish Optimization Algorithm with exact FE accounting.
% Protocol-adapted from the published SFOA movement/regeneration rules.

    if nargin<4,options=struct();end
    D=problem.dim;lb=reshape(problem.lb,1,[]);ub=reshape(problem.ub,1,[]);
    if N<5,error('SFOA requires N >= 5.');end
    X=validate_initial_population(options,N,D,lb,ub);
    fit=nan(N,1);FEs=0;
    for i=1:N,fit(i)=safe_objective(problem,X(i,:));FEs=FEs+1;end
    [bestFit,idx]=min(fit);bestX=X(idx,:);initialFitness=fit;
    checkpoints=make_FE_checkpoints(N,maxFEs,get_option(options,'nTracePoints',101));
    trace=trace_initialize(checkpoints,FEs,bestFit);
    maxCycles=max(1,ceil((maxFEs-N)/N));cycle=0;

    while FEs<maxFEs
        cycle=cycle+1;
        theta=(pi/2)*cycle/maxCycles;
        tEO=(maxCycles-cycle)/maxCycles*cos(theta);
        newX=X;
        if rand<0.5
            if D>5
                dims=randperm(D,5);
                for j=1:5
                    pm=(2*rand-1)*pi;
                    if rand<0.5
                        newX(:,dims(j))=X(:,dims(j))+pm*(bestX(dims(j))-X(:,dims(j)))*cos(theta);
                    else
                        newX(:,dims(j))=X(:,dims(j))-pm*(bestX(dims(j))-X(:,dims(j)))*sin(theta);
                    end
                end
            else
                dimIndex=randi(D);agents=randperm(N,2);r1=2*rand-1;r2=2*rand-1;
                newX(:,dimIndex)=tEO*X(:,dimIndex) ...
                    +r1*(X(agents(1),dimIndex)-X(:,dimIndex)) ...
                    +r2*(X(agents(2),dimIndex)-X(:,dimIndex));
            end
        else
            selected=randperm(N,5);differences=bestX-X(selected,:);
            pair=randperm(5,2);r1=rand;r2=rand;
            newX=X+r1*differences(pair(1),:)+r2*differences(pair(2),:);
            newX(end,:)=exp(-cycle*N/maxCycles).*X(end,:);
        end
        newX=min(max(newX,lb),ub);
        for i=1:N
            if FEs>=maxFEs,break;end
            fnew=safe_objective(problem,newX(i,:));FEs=FEs+1;
            if fnew<fit(i)
                X(i,:)=newX(i,:);
                fit(i)=fnew;
                if fnew<bestFit
                    bestFit=fnew;
                    bestX=newX(i,:);
                end
            end
            trace=trace_update(trace,FEs,bestFit);
        end
    end
    trace=trace_finalize(trace,bestFit);
    best=struct('position',bestX,'fitness',bestFit,'FEs',FEs);
    out=struct('cycles',cycle,'initialFitness',initialFitness,'finalPopulation',X,'finalFitness',fit);
end
function value=get_option(s,name,default)
    if isfield(s,name),value=s.(name);else,value=default;end
end
