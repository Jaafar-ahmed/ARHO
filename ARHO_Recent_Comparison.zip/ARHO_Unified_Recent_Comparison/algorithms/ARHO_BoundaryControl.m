function x = ARHO_BoundaryControl(x, lb, ub, integerIndices)
%ARHO_BOUNDARYCONTROL Bound correction and mixed-variable decoding support.
%
%   x = ARHO_BoundaryControl(x,lb,ub,integerIndices)
%
% The search position is clipped to [lb,ub]. Components listed in
% integerIndices are then rounded and clipped again.

    if nargin < 4 || isempty(integerIndices)
        integerIndices = [];
    end

    x = reshape(x, 1, []);
    lb = reshape(lb, 1, []);
    ub = reshape(ub, 1, []);

    x = min(max(x, lb), ub);

    if ~isempty(integerIndices)
        x(integerIndices) = round(x(integerIndices));
        x = min(max(x, lb), ub);
    end
end
