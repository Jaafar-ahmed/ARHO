function [best,trace,out] = SBOA_FE(problem,N,maxFEs,options)
%SBOA_FE Secretary Bird Optimization Algorithm with exact FE accounting.
% One hunting candidate and one escape candidate are evaluated per agent/cycle.

    if nargin<4,options=struct();end
    D=problem.dim;lb=reshape(problem.lb,1,[]);ub=reshape(problem.ub,1,[]);
    if N<3,error('SBOA requires N >= 3.');end
    X=validate_initial_population(options,N,D,lb,ub);
    fit=nan(N,1);FEs=0;
    for i=1:N,fit(i)=safe_objective(problem,X(i,:));FEs=FEs+1;end
    [bestFit,idx]=min(fit);bestX=X(idx,:);initialFitness=fit;
    checkpoints=make_FE_checkpoints(N,maxFEs,get_option(options,'nTracePoints',101));
    trace=trace_initialize(checkpoints,FEs,bestFit);
    maxCycles=max(1,ceil((maxFEs-N)/(2*N)));cycle=0;

    while FEs<maxFEs
        cycle=cycle+1;progress=min(1,cycle/maxCycles);
        % Hunting/exploration stage
        for i=1:N
            if FEs>=maxFEs,break;end
            if progress<1/3
                choices=setdiff(1:N,i);pick=choices(randperm(numel(choices),2));
                candidate=X(i,:)+(X(pick(1),:)-X(pick(2),:)).*rand(1,D);
            elseif progress<2/3
                RB=randn(1,D);
                candidate=bestX+exp(progress^4).*(RB-0.5).*(bestX-X(i,:));
            else
                factor=(max(0,1-progress))^(2*progress);
                RL=0.5*levy_step(1,D,1.5,0.01);
                candidate=bestX+factor.*X(i,:).*RL;
            end
            candidate=min(max(candidate,lb),ub);
            fnew=safe_objective(problem,candidate);FEs=FEs+1;
            if fnew<fit(i)
                X(i,:)=candidate;
                fit(i)=fnew;
                if fnew<bestFit
                    bestFit=fnew;
                    bestX=candidate;
                end
            end
            trace=trace_update(trace,FEs,bestFit);
        end
        if FEs>=maxFEs,break;end
        % Escape/exploitation stage
        for i=1:N
            if FEs>=maxFEs,break;end
            if rand<0.5
                RB=randn(1,D);
                candidate=bestX+(2*RB-1).*(1-progress)^2.*X(i,:);
            else
                randomX=X(randi(N),:);K=randi([1,2]);R2=randn(1,D);
                candidate=X(i,:)+R2.*(randomX-K*X(i,:));
            end
            candidate=min(max(candidate,lb),ub);
            fnew=safe_objective(problem,candidate);FEs=FEs+1;
            if fnew<fit(i)
                X(i,:)=candidate;
                fit(i)=fnew;
                if fnew<bestFit
                    bestFit=fnew;
                    bestX=candidate;
                end
            end
            trace=trace_update(trace,FEs,bestFit);
        end
    end
    trace=trace_finalize(trace,bestFit);
    best=struct('position',bestX,'fitness',bestFit,'FEs',FEs);
    out=struct('cycles',cycle,'initialFitness',initialFitness,'finalPopulation',X,'finalFitness',fit);
end
function value=get_option(s,name,default)
    if isfield(s,name),value=s.(name);else,value=default;end
end
