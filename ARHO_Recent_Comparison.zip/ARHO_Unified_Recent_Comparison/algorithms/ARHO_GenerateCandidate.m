function [candidate, usedFEs] = ARHO_GenerateCandidate( ...
    problem, currentX, currentRecord, hotspot, best, state, opts)
%ARHO_GENERATECANDIDATE Generate and evaluate one ARHO candidate.
%
% The function performs:
%   1. broad anticipatory movement,
%   2. local verification and greedy broad/local selection,
%   3. optional sparse leader following,
%   4. optional occupancy-aware diversification.
%
% The returned raw objective is always the original engineering objective.

    usedFEs = 0;
    candidate = currentRecord;

    if state.currentFEs >= state.maxFEs
        return;
    end

    lb = reshape(problem.lb, 1, []);
    ub = reshape(problem.ub, 1, []);
    span = ub - lb;
    D = problem.dim;

    progress = min(1, max(0, state.progress));

    alphaT = opts.alphaMax ...
           - (opts.alphaMax - opts.alphaMin) * progress;
    noiseT = opts.sigmaMax * (1 - progress)^opts.mu;

    etaT = opts.etaMax ...
         - (opts.etaMax - opts.etaMin) * progress;
    pLead = opts.p0 + (opts.p1 - opts.p0) * progress;

    % Broad movement, corresponding to Eqs. (23)-(25).
    xBroad = currentX ...
           + alphaT * rand .* (hotspot.c - currentX) ...
           + noiseT .* randn(1,D) .* span;

    xBroad = ARHO_BoundaryControl( ...
        xBroad, lb, ub, problem.integerIndices);

    broadRecord = problem.evaluate(xBroad, opts.feasibilityTol);
    usedFEs = usedFEs + 1;
    candidate = broadRecord;

    % Local verification, corresponding to Eqs. (26)-(28).
    if opts.useLocalVerification && ...
            state.currentFEs + usedFEs < state.maxFEs

        localStep = etaT .* (2*rand(1,D)-1) ...
                  .* hotspot.sigma .* span;

        xLocal = hotspot.c + localStep;
        xLocal = ARHO_BoundaryControl( ...
            xLocal, lb, ub, problem.integerIndices);

        localRecord = problem.evaluate(xLocal, opts.feasibilityTol);
        usedFEs = usedFEs + 1;

        if is_better(localRecord, candidate, opts.comparisonTol)
            candidate = localRecord;
        end
    end

    % Sparse leader following, corresponding to Eqs. (30)-(32).
    if opts.useLeaderFollowing && state.leaderTrigger ...
            && rand < pLead ...
            && state.currentFEs + usedFEs < state.maxFEs

        xLead = candidate.searchX ...
              + opts.gamma * rand .* ...
                (best.searchX - candidate.searchX);

        xLead = ARHO_BoundaryControl( ...
            xLead, lb, ub, problem.integerIndices);

        leadRecord = problem.evaluate(xLead, opts.feasibilityTol);
        usedFEs = usedFEs + 1;

        if is_better(leadRecord, candidate, opts.comparisonTol)
            candidate = leadRecord;
        end
    end

    % Occupancy-aware diversification, corresponding to Eqs. (33)-(34).
    if opts.useDiversification && opts.useOccupancy ...
            && hotspot.n > opts.nmax ...
            && state.currentFEs + usedFEs < state.maxFEs

        normalizedDirection = ...
            (candidate.searchX - hotspot.c) ./ span;
        directionNorm = norm(normalizedDirection);

        if directionNorm <= opts.eps0
            normalizedDirection = randn(1,D);
            directionNorm = norm(normalizedDirection);
        end

        unitDirection = normalizedDirection ...
                      / (directionNorm + opts.eps0);

        xDiv = candidate.searchX ...
             + opts.xi .* unitDirection .* span;

        xDiv = ARHO_BoundaryControl( ...
            xDiv, lb, ub, problem.integerIndices);

        divRecord = problem.evaluate(xDiv, opts.feasibilityTol);
        usedFEs = usedFEs + 1;

        if is_better(divRecord, candidate, opts.comparisonTol)
            candidate = divRecord;
        end
    end
end

function tf = is_better(a, b, tol)
    if a.feasible && ~b.feasible
        tf = true;
        return;
    elseif ~a.feasible && b.feasible
        tf = false;
        return;
    end

    if a.feasible && b.feasible
        tf = strictly_less(a.merit, b.merit, tol);
        return;
    end

    if strictly_less(a.vsum, b.vsum, tol)
        tf = true;
    elseif strictly_equal(a.vsum, b.vsum, tol)
        if strictly_less(a.vmax, b.vmax, tol)
            tf = true;
        elseif strictly_equal(a.vmax, b.vmax, tol)
            tf = strictly_less(a.merit, b.merit, tol);
        else
            tf = false;
        end
    else
        tf = false;
    end
end

function tf = strictly_less(a, b, tol)
    scale = max([1, abs(a), abs(b)]);
    tf = a < b - tol * scale;
end

function tf = strictly_equal(a, b, tol)
    scale = max([1, abs(a), abs(b)]);
    tf = abs(a - b) <= tol * scale;
end
