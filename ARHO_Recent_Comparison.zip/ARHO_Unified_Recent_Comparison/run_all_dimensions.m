clear;clc;setup_project();c=unified_config();for D=c.dimensions,run_unified_experiment(D,c);end
