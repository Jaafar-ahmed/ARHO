# Recommended run order

1. `START_HERE`
2. `run_unified_smoke_test`
3. Inspect `results/smoke/D10/ValidationChecks.csv`
4. `run_D30`
5. Audit and archive D30 outputs
6. `run_D100`
7. Audit and archive D100 outputs
8. `run_D500`

Do not combine outputs from the previous comparison package with this package.
