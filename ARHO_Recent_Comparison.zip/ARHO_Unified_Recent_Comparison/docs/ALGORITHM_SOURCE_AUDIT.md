# Algorithm source audit

- **ARHO:** full reviewer-ready source supplied by the authors; only an `initialPopulation` input hook was added. No search/update equation was changed.
- **NRBO (2024):** protocol adaptation of the public author implementation associated with DOI 10.1016/j.engappai.2023.107532. A denominator floor is used only when the Newton-Raphson denominator is numerically zero.
- **HO (2024):** protocol adaptation of the three phases in *Hippopotamus Optimization Algorithm: a novel nature-inspired optimization algorithm*, Scientific Reports, DOI 10.1038/s41598-024-54910-3. Predator objective evaluations are included in MaxFEs.
- **SBOA (2024):** equations follow Fu et al., *Artificial Intelligence Review* 57:123, DOI 10.1007/s10462-024-10729-y: differential search, Brownian stage, Levy attack, and the two escape strategies.
- **SFOA (2025):** protocol adaptation of Zhong et al., *Neural Computing and Applications* 37:3641–3683, DOI 10.1007/s00521-024-10694-1, including movement and regeneration rules.

All adaptations use a common interface, common clipping, supplied X0, fixed trace checkpoints, and exact FE termination.
