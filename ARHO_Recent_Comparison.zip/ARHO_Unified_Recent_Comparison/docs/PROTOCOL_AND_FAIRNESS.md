# Protocol and fairness decisions

1. **Fresh execution only:** no previous CSV/MAT result is imported.
2. **Full ARHO:** no ablation switch is enabled and no ARHO search equation is removed.
3. **Exact shared X0:** the paired seed generates one matrix per function/run; the same matrix is injected into all five algorithms, and the RNG state immediately after those initialization draws is restored before each optimizer starts.
4. **Independent internal randomness:** every optimizer receives the same RNG state immediately after the shared X0 generation, preserving the random-draw position that follows normal initialization.
5. **Noisy F7:** each algorithm receives a fresh benchmark object initialized with the same objective-noise seed, so the evaluation noise sequence is matched.
6. **Exact FE accounting:** every objective call, including HO predator evaluations, is counted.
7. **Boundary handling:** all generated candidates are clipped to the benchmark bounds.
8. **Statistics:** descriptive tables use scale-normalized mean/std; Friedman ranks use means; paired Wilcoxon uses exact-zero removal, Holm correction, and rank-biserial effect sizes.

The shared-initial-population hook changes only how ARHO receives X0; ARHO's hotspot memory, selection, broad movement, local verification, leader following, and occupancy-aware diversification remain active.
