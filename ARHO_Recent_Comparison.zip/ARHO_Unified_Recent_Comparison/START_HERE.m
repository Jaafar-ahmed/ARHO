clear;clc;root=setup_project();
fprintf('\nThis package executes fresh results for ARHO, NRBO, HO, SBOA, and SFOA.\n');
fprintf('It contains no historical-result import or merge step.\n\n');
run_package_integrity_check();
fprintf('\nNext command: run_unified_smoke_test\n');
