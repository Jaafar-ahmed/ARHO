function [pairTable,criticalDifference] = ...
    nemenyi_posthoc(algorithmNames,averageRanks,nFunctions,alpha)
%NEMENYI_POSTHOC Nemenyi critical-difference comparisons.
%
% Critical q values are the commonly used two-sided values q/sqrt(2)
% for alpha=0.05 and 2-10 algorithms.

    if nargin<4,alpha=0.05;end
    k=numel(algorithmNames);

    if abs(alpha-0.05)>eps
        error('This implementation currently supports alpha=0.05 only.');
    end

    qTable=[NaN,1.960,2.344,2.569,2.728,2.850, ...
            2.949,3.031,3.102,3.164];

    if k>10
        error('Nemenyi q table supports at most 10 algorithms.');
    end

    q=qTable(k);
    criticalDifference=q*sqrt(k*(k+1)/(6*nFunctions));

    rows={};
    counter=0;
    for i=1:k-1
        for j=i+1:k
            counter=counter+1;
            difference=abs(averageRanks(i)-averageRanks(j));
            rows(counter,:)={ ...
                string(algorithmNames{i}), ...
                string(algorithmNames{j}), ...
                averageRanks(i),averageRanks(j),difference, ...
                criticalDifference,difference>criticalDifference};
        end
    end

    pairTable=cell2table(rows,'VariableNames',{ ...
        'AlgorithmA','AlgorithmB','AverageRankA','AverageRankB', ...
        'RankDifference','CriticalDifference','Significant'});
end
