function statistics=analyze_unified_results(matFile)
%ANALYZE_UNIFIED_RESULTS Mean-based ranks and paired statistical tests.
    data=load(matFile);
    outputFolder=fileparts(matFile);
    algorithms=data.algorithms;
    functionIds=data.functionIds;
    values=data.finalValues;
    D=data.D;
    alpha=data.config.alpha;
    nFunctions=numel(functionIds);
    nAlgorithms=numel(algorithms);
    arhoIndex=find(strcmpi(algorithms,'ARHO'),1);

    performance=nan(nFunctions,nAlgorithms);
    for f=1:nFunctions
        for a=1:nAlgorithms
            [performance(f,a),~]=stable_mean_std(squeeze(values(f,a,:)));
        end
    end

    friedman=friedman_test(performance);
    averageRanks=table(string(algorithms(:)),friedman.averageRanks(:), ...
        'VariableNames',{'Algorithm','AverageRank'});
    averageRanks=sortrows(averageRanks,'AverageRank');

    functionRanks=array2table(friedman.rankMatrix, ...
        'VariableNames',matlab.lang.makeValidName(algorithms));
    functionRanks=addvars(functionRanks,functionIds(:),'Before',1, ...
        'NewVariableNames','FunctionId');

    overall=table(D,friedman.Q,friedman.df,friedman.pChiSquare, ...
        friedman.imanDavenportF,friedman.imanDavenportP, ...
        'VariableNames',{'Dimension','FriedmanQ','DF','FriedmanP', ...
        'ImanDavenportF','ImanDavenportP'});

    [nemenyi,criticalDifference]=nemenyi_posthoc( ...
        algorithms,friedman.averageRanks,nFunctions,alpha);

    rows={};
    rowCounter=0;
    for a=1:nAlgorithms
        if a==arhoIndex
            continue;
        end
        for f=1:nFunctions
            x=squeeze(values(f,arhoIndex,:));
            y=squeeze(values(f,a,:));
            test=wilcoxon_signed_rank_exactzero(x,y);
            [arhoMean,~]=stable_mean_std(x);
            [baselineMean,~]=stable_mean_std(y);

            rowCounter=rowCounter+1;
            rows(rowCounter,:)={D,functionIds(f),string(algorithms{a}), ...
                arhoMean,baselineMean,median(x),median(y),test.p,test.n, ...
                test.Wplus,test.Wminus,test.z,test.effect, ...
                test.pairedMedianDifference};
        end
    end

    wilcoxon=cell2table(rows,'VariableNames',{ ...
        'Dimension','FunctionId','Baseline','ARHOMean','BaselineMean', ...
        'ARHOMedian','BaselineMedian','RawP','N','Wplus','Wminus','Z', ...
        'RankBiserialAdvantage','PairedMedianDifference'});
    wilcoxon.HolmP_Global=holm_adjust(wilcoxon.RawP);
    wilcoxon.HolmP_WithinBaseline=nan(height(wilcoxon),1);

    baselines=unique(wilcoxon.Baseline,'stable');
    for b=1:numel(baselines)
        idx=wilcoxon.Baseline==baselines(b);
        wilcoxon.HolmP_WithinBaseline(idx)=holm_adjust(wilcoxon.RawP(idx));
    end

    decisions=strings(height(wilcoxon),1);
    for i=1:height(wilcoxon)
        if wilcoxon.HolmP_Global(i)>=alpha
            decisions(i)="Tie";
        elseif wilcoxon.PairedMedianDifference(i)<0
            decisions(i)="Win";
        else
            decisions(i)="Loss";
        end
    end
    wilcoxon.Decision_GlobalHolm=decisions;

    wtlRows=cell(numel(baselines),4);
    for b=1:numel(baselines)
        idx=wilcoxon.Baseline==baselines(b);
        d=wilcoxon.Decision_GlobalHolm(idx);
        wtlRows(b,:)={baselines(b),sum(d=="Win"),sum(d=="Tie"),sum(d=="Loss")};
    end
    winTieLoss=cell2table(wtlRows, ...
        'VariableNames',{'Baseline','Wins','Ties','Losses'});

    writetable(averageRanks,fullfile(outputFolder,'AverageRanks_MeanBased.csv'));
    writetable(functionRanks,fullfile(outputFolder,'FunctionLevelRanks_MeanBased.csv'));
    writetable(overall,fullfile(outputFolder,'FriedmanOverallTest.csv'));
    writetable(nemenyi,fullfile(outputFolder,'NemenyiPostHoc.csv'));
    writetable(wilcoxon,fullfile(outputFolder,'WilcoxonHolm_FunctionLevel.csv'));
    writetable(winTieLoss,fullfile(outputFolder,'WinTieLoss_GlobalHolm.csv'));

    fid=fopen(fullfile(outputFolder,'NemenyiCriticalDifference.txt'),'w');
    fprintf(fid,'Dimension = %d\n',D);
    fprintf(fid,'Alpha = %.4f\n',alpha);
    fprintf(fid,'Critical difference = %.16g\n',criticalDifference);
    fclose(fid);

    statistics=struct('averageRanks',averageRanks, ...
        'functionRanks',functionRanks,'overall',overall,'nemenyi',nemenyi, ...
        'wilcoxon',wilcoxon,'winTieLoss',winTieLoss, ...
        'criticalDifference',criticalDifference);
end
