function run_statistics_self_test()
    assert(max(abs(tied_rank([1 1 3])-[1.5;1.5;3]))<1e-14);
    d=[-3 -2 -2 -1 1 1 2 3 4 0]';t=wilcoxon_signed_rank_exactzero(d,zeros(size(d)));
    assert(abs(t.Wplus-25.5)<1e-14&&abs(t.Wminus-19.5)<1e-14);
    assert(abs(t.p-0.7652905044137499)<1e-12);
    a=holm_adjust([0.01;0.04;0.03]);assert(max(abs(a-[0.03;0.06;0.06]))<1e-14);
    fprintf('PASS: rank, Wilcoxon, effect-size, and Holm routines verified.\n');
end
