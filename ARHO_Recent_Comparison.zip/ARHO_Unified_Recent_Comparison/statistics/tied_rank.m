function ranks = tied_rank(values)
%TIED_RANK Toolbox-free ascending tied ranks.

    values=values(:);
    [sorted,order]=sort(values);
    ranksSorted=zeros(size(values));

    i=1;
    while i<=numel(values)
        j=i;
        while j<numel(values) && sorted(j+1)==sorted(i)
            j=j+1;
        end
        ranksSorted(i:j)=mean(i:j);
        i=j+1;
    end

    ranks=zeros(size(values));
    ranks(order)=ranksSorted;
end
