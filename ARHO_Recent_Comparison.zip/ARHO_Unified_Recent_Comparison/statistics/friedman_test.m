function result = friedman_test(performance)
%FRIEDMAN_TEST Toolbox-free Friedman and Iman-Davenport statistics.
%
% Rows are benchmark functions; columns are algorithms; lower is better.

    [n,k]=size(performance);
    rankMatrix=zeros(n,k);

    for i=1:n
        rankMatrix(i,:)=tied_rank(performance(i,:))';
    end

    averageRanks=mean(rankMatrix,1);
    Q=12*n/(k*(k+1))*sum(averageRanks.^2)-3*n*(k+1);
    df=k-1;
    pChi=1-gammainc(Q/2,df/2);

    denominator=n*(k-1)-Q;
    if denominator<=0
        Fstat=Inf;
        pIman=0;
    else
        Fstat=(n-1)*Q/denominator;
        d1=k-1;
        d2=(k-1)*(n-1);
        z=d1*Fstat/(d1*Fstat+d2);
        pIman=1-betainc(z,d1/2,d2/2);
    end

    result.rankMatrix=rankMatrix;
    result.averageRanks=averageRanks;
    result.Q=Q;
    result.df=df;
    result.pChiSquare=pChi;
    result.imanDavenportF=Fstat;
    result.imanDavenportP=pIman;
end
