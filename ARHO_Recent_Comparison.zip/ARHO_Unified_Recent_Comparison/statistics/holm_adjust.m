function adjusted = holm_adjust(pValues)
%HOLM_ADJUST Holm step-down family-wise error correction.

    pValues=pValues(:);
    m=numel(pValues);
    [sorted,order]=sort(pValues);
    adjustedSorted=zeros(m,1);

    running=0;
    for i=1:m
        candidate=(m-i+1)*sorted(i);
        running=max(running,candidate);
        adjustedSorted(i)=min(1,running);
    end

    adjusted=zeros(m,1);
    adjusted(order)=adjustedSorted;
end
