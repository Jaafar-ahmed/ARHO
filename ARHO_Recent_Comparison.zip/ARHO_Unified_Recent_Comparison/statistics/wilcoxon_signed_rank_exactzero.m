function result=wilcoxon_signed_rank_exactzero(x,y)
%WILCOXON_SIGNED_RANK_EXACTZERO Paired two-sided normal approximation.
% Only exact zero differences are removed. Positive effect means x is better.
    x=x(:);
    y=y(:);
    valid=isfinite(x)&isfinite(y);
    differences=x(valid)-y(valid);
    differences=differences(differences~=0);
    n=numel(differences);

    if n==0
        result=struct('n',0,'Wplus',0,'Wminus',0,'z',0,'p',1, ...
            'effect',0,'pairedMedianDifference',0);
        return;
    end

    absolute=abs(differences);
    ranks=tied_rank(absolute);
    Wplus=sum(ranks(differences>0));
    Wminus=sum(ranks(differences<0));
    mu=n*(n+1)/4;

    [~,~,groups]=unique(absolute);
    counts=accumarray(groups,1);
    tieCubicCorrection=sum(counts.^3-counts);
    variance=(n*(n+1)*(2*n+1)-0.5*tieCubicCorrection)/24;
    variance=max(variance,eps);

    z=max((abs(Wplus-mu)-0.5)/sqrt(variance),0);
    p=erfc(z/sqrt(2));
    result=struct('n',n,'Wplus',Wplus,'Wminus',Wminus,'z',z, ...
        'p',min(1,max(0,p)), ...
        'effect',(Wminus-Wplus)/max(Wminus+Wplus,eps), ...
        'pairedMedianDifference',median(differences));
end
