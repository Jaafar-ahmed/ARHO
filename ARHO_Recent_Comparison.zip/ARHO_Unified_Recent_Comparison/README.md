# Unified Fresh Comparison: Full ARHO vs Recent Metaheuristics

This package executes **Full ARHO, NRBO, HO, SBOA, and SFOA together in one MATLAB runner**. It does **not** read, merge, or reuse historical ARHO results.

## Identical protocol

- Population: 30
- Runs: 30
- Seeds: 1–30
- Benchmarks: F1–F13
- Dimensions: 30, 100, 500
- Budget: MaxFEs = 1000D
- Same exact initial population `X0` and the same post-initialization RNG state for every algorithm in each function/run
- Fresh benchmark object and identical F7 objective-noise seed for every algorithm
- Common clipping boundary control
- Exact objective-function evaluation counting

## Start

```matlab
START_HERE
run_unified_smoke_test
```

After the smoke test passes:

```matlab
run_D30
```

Upload `results/D30/RawResults.csv`, `Summary.csv`, and `ValidationChecks.csv` before running D=100.

## Outputs

Each dimension folder contains raw results, stable summary statistics, mean-based Friedman ranks, Iman-Davenport, Nemenyi, Wilcoxon-Holm, rank-biserial effects, W/T/L, convergence traces, and validation reports.

## Important interpretation

A fresh unified run improves fairness and reproducibility. It does not guarantee that ARHO will rank higher. Full ARHO is unchanged except that the runner supplies the shared initial population instead of letting each optimizer generate its own.
