function problem = getBenchmarkF13(fid, D, noiseSeed)
%GETBENCHMARKF13 Classical F1-F13 benchmark definition.
%
%   problem = getBenchmarkF13(fid,D,noiseSeed)
%
% The suite follows the function definitions used in the submitted ARHO
% manuscript:
%   F1  Sphere
%   F2  Schwefel 2.22
%   F3  Schwefel 1.2
%   F4  Schwefel 2.21
%   F5  Rosenbrock
%   F6  Step
%   F7  Quartic with additive U(0,1) noise
%   F8  Schwefel 2.26, unshifted (negative optimum)
%   F9  Rastrigin
%   F10 Ackley
%   F11 Griewank
%   F12 Penalized 1
%   F13 Penalized 2
%
% F7 uses an independent RandStream. Recreating the problem with the same
% noiseSeed gives each algorithm the same objective-noise sequence, while
% leaving the algorithm's own random stream independent.
%
% F2 uses a log-domain product only when the direct product would overflow.
% Values beyond floating-point range are capped at realmax/100 instead of
% being exported as Inf.

    validateattributes(fid, {'numeric'}, ...
        {'scalar','integer','>=',1,'<=',13});
    validateattributes(D, {'numeric'}, ...
        {'scalar','integer','>=',1});
    validateattributes(noiseSeed, {'numeric'}, ...
        {'scalar','integer','nonnegative'});

    noiseStream = RandStream('mt19937ar','Seed',noiseSeed);

    names = { ...
        'F1 Sphere', ...
        'F2 Schwefel 2.22', ...
        'F3 Schwefel 1.2', ...
        'F4 Schwefel 2.21', ...
        'F5 Rosenbrock', ...
        'F6 Step', ...
        'F7 Quartic with noise', ...
        'F8 Schwefel 2.26', ...
        'F9 Rastrigin', ...
        'F10 Ackley', ...
        'F11 Griewank', ...
        'F12 Penalized 1', ...
        'F13 Penalized 2'};

    lowerScalar = [-100,-10,-100,-100,-30,-100,-1.28, ...
                   -500,-5.12,-32,-600,-50,-50];
    upperScalar = [ 100, 10, 100, 100, 30, 100, 1.28, ...
                    500, 5.12, 32, 600, 50, 50];

    fopt = zeros(1,13);
    fopt(8) = -418.9829 * D;

    lb = lowerScalar(fid) * ones(1,D);
    ub = upperScalar(fid) * ones(1,D);

    problem.name = names{fid};
    problem.functionId = fid;
    problem.dim = D;
    problem.lb = lb;
    problem.ub = ub;
    problem.integerIndices = [];
    problem.sense = 'minimize';
    problem.fopt = fopt(fid);
    problem.isStochastic = (fid == 7);
    problem.noiseSeed = noiseSeed;

    problem.objective = @objective;
    problem.evaluate = @evaluate_record;
    problem.verify = @verify_record;

    function value = objective(x)
        x = reshape(x,1,[]);
        value = benchmark_value(x,fid,D,noiseStream);

        if ~isfinite(value)
            value = realmax('double')/100;
        end
    end

    function rec = evaluate_record(x, ~)
        x = ARHO_BoundaryControl(x,lb,ub,[]);
        value = objective(x);

        rec.searchX = x;
        rec.decodedX = x;
        rec.raw = value;
        rec.merit = value;
        rec.g = zeros(1,0);
        rec.margins = zeros(1,0);
        rec.vsum = 0;
        rec.vmax = 0;
        rec.feasible = true;
    end

    function report = verify_record(x, ~, verbose)
        if nargin < 3
            verbose = false;
        end

        % For deterministic functions, recompute directly. For F7, an
        % independent verification would draw a new noise sample, so the
        % stored objective is the authoritative experimental observation.
        x = ARHO_BoundaryControl(x,lb,ub,[]);
        report.decodedX = x;
        report.raw = objective(x);
        report.merit = report.raw;
        report.g = zeros(1,0);
        report.margins = zeros(1,0);
        report.vsum = 0;
        report.vmax = 0;
        report.feasible = true;

        if verbose
            fprintf('%s verification value = %.16g\n', ...
                problem.name, report.raw);
        end
    end
end

function f = benchmark_value(x,fid,D,noiseStream)
    switch fid
        case 1
            f = sum(x.^2);

        case 2
            absx = abs(x);
            sumTerm = sum(absx);

            positive = absx(absx > 0);
            if isempty(positive)
                productTerm = 0;
            else
                logProduct = sum(log(positive));
                cap = realmax('double')/100;
                if logProduct >= log(cap)
                    productTerm = cap;
                else
                    productTerm = exp(logProduct);
                end
            end
            f = sumTerm + productTerm;

        case 3
            f = sum(cumsum(x).^2);

        case 4
            f = max(abs(x));

        case 5
            f = sum(100*(x(2:end)-x(1:end-1).^2).^2 ...
                  + (x(1:end-1)-1).^2);

        case 6
            f = sum(floor(x+0.5).^2);

        case 7
            f = sum((1:D).*(x.^4)) + rand(noiseStream);

        case 8
            f = sum(-x.*sin(sqrt(abs(x))));

        case 9
            f = sum(x.^2 - 10*cos(2*pi*x) + 10);

        case 10
            f = -20*exp(-0.2*sqrt(sum(x.^2)/D)) ...
              - exp(sum(cos(2*pi*x))/D) + 20 + exp(1);

        case 11
            indices = 1:D;
            f = sum(x.^2)/4000 ...
              - prod(cos(x./sqrt(indices))) + 1;

        case 12
            y = 1 + (x+1)/4;
            term1 = 10*sin(pi*y(1))^2;
            term2 = sum((y(1:end-1)-1).^2 ...
                    .* (1+10*sin(pi*y(2:end)).^2));
            term3 = (y(end)-1)^2;
            f = (pi/D)*(term1+term2+term3) ...
              + sum(penalty_u(x,10,100,4));

        case 13
            term1 = sin(3*pi*x(1))^2;
            term2 = sum((x(1:end-1)-1).^2 ...
                    .* (1+sin(3*pi*x(2:end)).^2));
            term3 = (x(end)-1)^2 ...
                  * (1+sin(2*pi*x(end))^2);
            f = 0.1*(term1+term2+term3) ...
              + sum(penalty_u(x,5,100,4));

        otherwise
            error('Unknown benchmark function ID.');
    end
end

function value = penalty_u(x,a,k,m)
    value = zeros(size(x));
    high = x > a;
    low = x < -a;
    value(high) = k*(x(high)-a).^m;
    value(low) = k*(-x(low)-a).^m;
end
