function run_unified_smoke_test()
%RUN_UNIFIED_SMOKE_TEST Small non-research test including fresh Full ARHO.
    c=unified_config();c.outputRoot=fullfile(fileparts(fileparts(mfilename('fullpath'))),'results','smoke');
    c.functionIds=[1,8,13];c.nRuns=2;c.seeds=(1:2)';c.N=30;c.feBudgetMultiplier=50;c.resume=false;
    for a=1:numel(c.algorithms),c.algorithmOptions.(c.algorithms{a}).nTracePoints=c.nTracePoints;end
    run_unified_experiment(10,c);
    fprintf('\nSmoke test completed. These values are not manuscript results.\n');
end
