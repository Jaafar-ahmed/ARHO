function run_package_integrity_check()
%RUN_PACKAGE_INTEGRITY_CHECK Static protocol and source checks.
    root=fileparts(fileparts(mfilename('fullpath')));
    config=unified_config();

    required={'ARHO.m','ARHO_FE.m','NRBO_FE.m','HO_FE.m','SBOA_FE.m','SFOA_FE.m'};
    for i=1:numel(required)
        assert(exist(fullfile(root,'algorithms',required{i}),'file')==2, ...
            'Missing algorithm file: %s',required{i});
    end

    assert(isequal(config.algorithms,{'ARHO','NRBO','HO','SBOA','SFOA'}));
    assert(config.N==30);
    assert(config.nRuns==30);
    assert(config.feBudgetMultiplier==1000);
    assert(~exist(fullfile(root,'reference_results'),'dir'), ...
        'A historical reference-results folder was detected.');
    assert(~exist(fullfile(root,'experiments','run_merge_and_analyze.m'),'file'), ...
        'A historical result-merge script was detected.');

    run_statistics_self_test();
    fprintf('PASS: Full ARHO and four recent algorithms are registered.\n');
    fprintf('PASS: N=30, runs=30, seeds=1-30, MaxFEs=1000D.\n');
    fprintf('PASS: no historical ARHO data import or merge path exists.\n');
end
