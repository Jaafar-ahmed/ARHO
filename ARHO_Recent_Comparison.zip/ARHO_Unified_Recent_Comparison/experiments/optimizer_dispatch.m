function [best,trace,out] = optimizer_dispatch(name,problem,N,maxFEs,options)
%OPTIMIZER_DISPATCH Unified registry; all entries execute in this package.
    if nargin<5,options=struct();end
    switch upper(string(name))
        case "ARHO", [best,trace,out]=ARHO_FE(problem,N,maxFEs,options);
        case "NRBO", [best,trace,out]=NRBO_FE(problem,N,maxFEs,options);
        case "HO",   [best,trace,out]=HO_FE(problem,N,maxFEs,options);
        case "SBOA", [best,trace,out]=SBOA_FE(problem,N,maxFEs,options);
        case "SFOA", [best,trace,out]=SFOA_FE(problem,N,maxFEs,options);
        otherwise, error('Unknown algorithm: %s',name);
    end
end
