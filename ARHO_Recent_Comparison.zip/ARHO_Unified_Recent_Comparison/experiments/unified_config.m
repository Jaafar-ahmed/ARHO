function config = unified_config()
%UNIFIED_CONFIG Reviewer-facing identical-protocol configuration.
    config.dimensions=[30,100,500];
    config.functionIds=1:13;
    config.algorithms={'ARHO','NRBO','HO','SBOA','SFOA'};
    config.N=30;
    config.nRuns=30;
    config.seeds=(1:30)';
    config.feBudgetMultiplier=1000;
    config.nTracePoints=101;
    config.alpha=0.05;
    root=fileparts(fileparts(mfilename('fullpath')));
    config.outputRoot=fullfile(root,'results');
    config.saveEveryRun=true;
    config.resume=true;
    config.algorithmOptions.ARHO=struct('rho',0.30,'phi',0.90,'smin',0.05,'nTracePoints',101);
    config.algorithmOptions.NRBO=struct('DF',0.6,'nTracePoints',101);
    config.algorithmOptions.HO=struct('nTracePoints',101);
    config.algorithmOptions.SBOA=struct('nTracePoints',101);
    config.algorithmOptions.SFOA=struct('nTracePoints',101);
end
