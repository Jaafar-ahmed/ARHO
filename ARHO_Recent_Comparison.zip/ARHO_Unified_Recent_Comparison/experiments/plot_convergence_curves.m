function plot_convergence_curves(resultMatFile,functionIds)
%PLOT_CONVERGENCE_CURVES Mean best-so-far curves, one figure per function.
    d=load(resultMatFile);if nargin<2,functionIds=d.functionIds;end
    for fid=functionIds
        fi=find(d.functionIds==fid,1);if isempty(fi),continue;end
        figure('Name',sprintf('D%d F%02d',d.D,fid));hold on;
        for a=1:numel(d.algorithms)
            curve=squeeze(mean(d.traces(fi,a,:,:),3,'omitnan'));
            if all(curve>0)
                semilogy(d.checkpoints,curve,'LineWidth',1.5,'DisplayName',d.algorithms{a});
            else
                plot(d.checkpoints,curve,'LineWidth',1.5,'DisplayName',d.algorithms{a});
            end
        end
        grid on;xlabel('Function evaluations');ylabel('Mean best-so-far');title(sprintf('D=%d, F%02d',d.D,fid));legend('Location','best');hold off;
    end
end
