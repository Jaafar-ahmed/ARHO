function output = run_unified_experiment(D,config)
%RUN_UNIFIED_EXPERIMENT Fresh ARHO + recent algorithms in one runner.
% No historical ARHO result is read, merged, or imported.

    if nargin<2||isempty(config),config=unified_config();end
    validateattributes(D,{'numeric'},{'scalar','integer','positive'});
    maxFEs=config.feBudgetMultiplier*D;
    algorithms=config.algorithms;functionIds=config.functionIds;
    nA=numel(algorithms);nF=numel(functionIds);nR=config.nRuns;
    folder=fullfile(config.outputRoot,sprintf('D%d',D));
    if ~exist(folder,'dir'),mkdir(folder);end
    finalValues=nan(nF,nA,nR);runtimes=nan(nF,nA,nR);actualFEs=nan(nF,nA,nR);
    traces=nan(nF,nA,nR,config.nTracePoints);status=strings(nF,nA,nR);
    initSum=nan(nF,nA,nR);initSumSq=nan(nF,nA,nR);initialBest=nan(nF,nA,nR);
    rows=cell(nF*nA*nR,15);row=0;

    for fi=1:nF
        fid=functionIds(fi);
        for run=1:nR
            seed=config.seeds(run);
            noiseSeed=1000000+D*10000+fid*100+run;
            templateProblem=getBenchmarkF13(fid,D,noiseSeed);
            [X0,initializationSeed,postInitializationState]= ...
                common_initial_population(templateProblem,config.N,D,seed);
            fingerprint1=sum(X0(:));
            fingerprint2=sum(X0(:).^2);

            sharedFolder=fullfile(folder,sprintf('F%02d',fid),'SharedInitialization');
            if ~exist(sharedFolder,'dir')
                mkdir(sharedFolder);
            end
            sharedFile=fullfile(sharedFolder,sprintf('Run_%02d_seed_%d.mat',run,seed));
            if ~exist(sharedFile,'file')
                initialPopulation=X0; %#ok<NASGU>
                initialPopulationSum=fingerprint1; %#ok<NASGU>
                initialPopulationSumSquares=fingerprint2; %#ok<NASGU>
                save(sharedFile,'initialPopulation','initializationSeed', ...
                    'initialPopulationSum','initialPopulationSumSquares', ...
                    'postInitializationState','D','fid','seed','-v7.3');
            end

            for ai=1:nA
                algorithm=algorithms{ai};
                algorithmFolder=fullfile(folder,sprintf('F%02d',fid),algorithm);
                if ~exist(algorithmFolder,'dir'),mkdir(algorithmFolder);end
                runFile=fullfile(algorithmFolder,sprintf('Run_%02d_seed_%d.mat',run,seed));
                validLoaded=false;runStatus="OK";details=struct();
                if config.resume && exist(runFile,'file')
                    saved=load(runFile);
                    validLoaded=isfield(saved,'best') ...
                        && isfield(saved,'trace') ...
                        && isfield(saved,'elapsed') ...
                        && isfield(saved,'runStatus') ...
                        && isfield(saved,'initialPopulationSumSquares') ...
                        && saved.best.FEs==maxFEs ...
                        && isfinite(saved.best.fitness) ...
                        && string(saved.runStatus)~="ERROR" ...
                        && saved.initialPopulationSumSquares==fingerprint2;
                    if validLoaded
                        best=saved.best;trace=saved.trace;elapsed=saved.elapsed;runStatus=string(saved.runStatus);
                        if isfield(saved,'details'),details=saved.details;end
                        fprintf('D=%d | F%02d | %-5s | run %02d/%02d | loaded\n',D,fid,algorithm,run,nR);
                    else
                        delete(runFile);
                    end
                end
                if ~validLoaded
                    problem=getBenchmarkF13(fid,D,noiseSeed); % fresh equal F7 stream per algorithm
                    options=config.algorithmOptions.(algorithm);
                    options.initialPopulation=X0;
                    rng(postInitializationState); % identical state immediately after shared X0 generation
                    fprintf('D=%d | F%02d | %-5s | run %02d/%02d | seed=%d | MaxFEs=%d\n', ...
                        D,fid,algorithm,run,nR,seed,maxFEs);
                    timer=tic;
                    try
                        [best,trace,details]=optimizer_dispatch(algorithm,problem,config.N,maxFEs,options);
                        elapsed=toc(timer);runStatus="OK";
                    catch ME
                        elapsed=toc(timer);runStatus="ERROR";
                        details.errorMessage=ME.message;
                        details.errorReport=getReport(ME,'extended','hyperlinks','off');
                        best=struct('position',nan(1,D),'fitness',realmax('double')/100,'FEs',NaN);
                        cp=make_FE_checkpoints(config.N,maxFEs,config.nTracePoints);
                        trace=struct('checkpoints',cp,'best',repmat(realmax('double')/100,size(cp)));
                    end
                    initialPopulationSum=fingerprint1; %#ok<NASGU>
                    initialPopulationSumSquares=fingerprint2; %#ok<NASGU>
                    if config.saveEveryRun
                        save(runFile,'best','trace','details','algorithm','D','fid','seed','maxFEs', ...
                            'noiseSeed','initializationSeed','initialPopulationSum', ...
                            'initialPopulationSumSquares','elapsed','runStatus','-v7.3');
                    end
                end

                finalValues(fi,ai,run)=best.fitness;runtimes(fi,ai,run)=elapsed;actualFEs(fi,ai,run)=best.FEs;
                traces(fi,ai,run,:)=reshape(trace.best,1,1,1,[]);status(fi,ai,run)=runStatus;
                initSum(fi,ai,run)=fingerprint1;initSumSq(fi,ai,run)=fingerprint2;
                if isfield(details,'initialFitness')
                    initialBest(fi,ai,run)=min(details.initialFitness);
                elseif isfield(details,'initialBest') && isfield(details.initialBest,'raw')
                    initialBest(fi,ai,run)=details.initialBest.raw;
                end
                row=row+1;
                rows(row,:)={D,fid,string(templateProblem.name),string(algorithm),run,seed, ...
                    initializationSeed,noiseSeed,maxFEs,best.FEs,initialBest(fi,ai,run),best.fitness,elapsed,runStatus,fingerprint2};
            end
        end
    end

    rawTable=cell2table(rows,'VariableNames',{'Dimension','FunctionId','FunctionName','Algorithm','Run','Seed', ...
        'InitializationSeed','ObjectiveNoiseSeed','MaxFEs','ActualFEs','InitialBestFitness','FinalFitness','RuntimeSeconds','Status','InitialPopulationSumSquares'});
    writetable(rawTable,fullfile(folder,'RawResults.csv'));
    writematrix(config.seeds,fullfile(folder,'RandomSeeds.txt'));
    checkpoints=make_FE_checkpoints(config.N,maxFEs,config.nTracePoints);
    save(fullfile(folder,'UnifiedResults.mat'),'config','D','maxFEs','algorithms','functionIds', ...
        'finalValues','runtimes','actualFEs','traces','status','rawTable','checkpoints', ...
        'initSum','initSumSq','initialBest','-v7.3');
    summary=generate_summary_stable(D,algorithms,functionIds,finalValues,runtimes,actualFEs);
    writetable(summary,fullfile(folder,'Summary.csv'));
    write_configuration(fullfile(folder,'ExperimentConfiguration.txt'),config,D,maxFEs);
    validation=validate_unified_results(fullfile(folder,'UnifiedResults.mat'));
    if all(validation.summary.Passed)
        statistics=analyze_unified_results(fullfile(folder,'UnifiedResults.mat')); %#ok<NASGU>
    else
        warning('Analysis created only after all validation checks pass.');
    end
    output=struct('outputFolder',folder,'rawTable',rawTable,'summary',summary,'validation',validation);
end
