#!/usr/bin/env python3
"""Aggregate, validate, analyse, and plot the ARHO ns-3 study results."""

from __future__ import annotations

import argparse
import math
from pathlib import Path
from typing import Iterable

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import f as f_distribution
from scipy.stats import friedmanchisquare, rankdata, wilcoxon

METHODS = ["ARHO", "PSO", "RWP", "GM"]
LOADS = ["moderate", "stress"]
METRICS = {
    "PDR_percent": "higher",
    "Throughput_Mbps": "higher",
    "MeanDelay_ms": "lower",
    "PacketLoss_percent": "lower",
    "MeanPhySnr_dB": "higher",
    "MeanLinkDuration_s": "higher",
    "TopologyChangesPerNodeSecond": "lower",
    "MeanLargestComponentFraction": "higher",
    "MeanIsolatedNodes": "lower",
}


def stable_std(values: Iterable[float]) -> float:
    x = np.asarray(list(values), dtype=float)
    x = x[np.isfinite(x)]
    if x.size < 2:
        return float("nan")
    scale = np.max(np.abs(x))
    if scale == 0:
        return 0.0
    return float(scale * np.std(x / scale, ddof=1))


def holm_adjust(p_values: np.ndarray) -> np.ndarray:
    p = np.asarray(p_values, dtype=float)
    order = np.argsort(p)
    adjusted = np.empty_like(p)
    running = 0.0
    m = len(p)
    for rank, index in enumerate(order):
        candidate = (m - rank) * p[index]
        running = max(running, candidate)
        adjusted[index] = min(1.0, running)
    return adjusted


def rank_biserial_advantage(differences: np.ndarray) -> float:
    d = np.asarray(differences, dtype=float)
    d = d[np.isfinite(d)]
    d = d[d != 0]
    if d.size == 0:
        return 0.0
    ranks = rankdata(np.abs(d), method="average")
    positive = float(np.sum(ranks[d > 0]))
    negative = float(np.sum(ranks[d < 0]))
    total = positive + negative
    return 0.0 if total == 0 else (positive - negative) / total


def confidence_interval_95(values: np.ndarray) -> tuple[float, float]:
    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return float("nan"), float("nan")
    mean = float(np.mean(x))
    if x.size == 1:
        return mean, mean
    se = stable_std(x) / math.sqrt(x.size)
    return mean - 1.96 * se, mean + 1.96 * se


def collect_raw(raw_dir: Path) -> pd.DataFrame:
    files = sorted(raw_dir.rglob("*.csv"))
    if not files:
        raise FileNotFoundError(f"No per-run CSV files found under {raw_dir}")
    frames: list[pd.DataFrame] = []
    for path in files:
        frame = pd.read_csv(path)
        if frame.empty:
            raise ValueError(f"Empty result file: {path}")
        frame["SourceFile"] = str(path.relative_to(raw_dir))
        frames.append(frame)
    raw = pd.concat(frames, ignore_index=True)
    raw["Method"] = raw["Method"].astype(str).str.upper()
    raw["Load"] = raw["Load"].astype(str).str.lower()
    return raw


def validation_checks(raw: pd.DataFrame, expected_runs: int) -> pd.DataFrame:
    checks: list[dict[str, object]] = []

    def add(name: str, passed: bool, details: str) -> None:
        checks.append({"Check": name, "Passed": bool(passed), "Details": details})

    expected_rows = len(METHODS) * len(LOADS) * expected_runs
    add("Expected row count", len(raw) == expected_rows,
        f"observed={len(raw)}, expected={expected_rows}")

    duplicated = raw.duplicated(["Method", "Load", "Run"], keep=False)
    add("Unique method-load-run rows", not duplicated.any(),
        f"duplicates={int(duplicated.sum())}")

    observed_methods = sorted(raw["Method"].unique().tolist())
    add("All methods present", set(observed_methods) == set(METHODS),
        f"observed={observed_methods}")
    observed_loads = sorted(raw["Load"].unique().tolist())
    add("All loads present", set(observed_loads) == set(LOADS),
        f"observed={observed_loads}")

    group_counts = raw.groupby(["Method", "Load"]).size()
    add("Equal run counts", bool((group_counts == expected_runs).all()),
        group_counts.to_dict().__repr__())

    run_sets = raw.groupby(["Method", "Load"])["Run"].apply(lambda x: sorted(set(x)))
    expected_set = list(range(1, expected_runs + 1))
    add("Runs are complete", all(v == expected_set for v in run_sets),
        "expected run numbers 1..%d" % expected_runs)

    numeric_metrics = list(METRICS) + [
        "TxPackets", "RxPackets", "Throughput_Mbps", "SnrSamples",
        "InitialPositionChecksum", "TrafficChecksum", "TopologySamples"
    ]
    missing_columns = [c for c in numeric_metrics if c not in raw.columns]
    add("Required columns present", not missing_columns,
        f"missing={missing_columns}")

    if not missing_columns:
        finite_columns = [c for c in numeric_metrics if c not in {"MeanDelay_ms"}]
        finite_ok = np.isfinite(raw[finite_columns].to_numpy(dtype=float)).all()
        add("Finite numerical outputs", bool(finite_ok),
            "MeanDelay_ms may be NaN only when no packet is received")
        add("Traffic generated", bool((raw["TxPackets"] > 0).all()),
            f"minimum TxPackets={raw['TxPackets'].min()}")
        add("SNR samples collected", bool((raw["SnrSamples"] > 0).all()),
            f"minimum samples={raw['SnrSamples'].min()}")
        add("Topology sampled", bool((raw["TopologySamples"] > 0).all()),
            f"minimum samples={raw['TopologySamples'].min()}")

    initial_spread = raw.groupby(["Load", "Run"])["InitialPositionChecksum"].agg(
        lambda x: float(np.max(x) - np.min(x)))
    add("Paired initial positions", bool((initial_spread <= 1e-9).all()),
        f"maximum within-pair checksum spread={initial_spread.max():.3e}")

    traffic_spread = raw.groupby(["Load", "Run"])["TrafficChecksum"].agg(
        lambda x: float(np.max(x) - np.min(x)))
    add("Paired traffic definitions", bool((traffic_spread <= 1e-9).all()),
        f"maximum within-pair checksum spread={traffic_spread.max():.3e}")

    for column, lower, upper in [
        ("PDR_percent", 0.0, 100.0),
        ("PacketLoss_percent", 0.0, 100.0),
        ("MeanLargestComponentFraction", 0.0, 1.0),
    ]:
        if column in raw:
            valid = raw[column].between(lower - 1e-12, upper + 1e-12).all()
            add(f"{column} range", bool(valid), f"expected [{lower}, {upper}]")

    return pd.DataFrame(checks)


def summarize(raw: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for load in LOADS:
        for method in METHODS:
            subset = raw[(raw["Load"] == load) & (raw["Method"] == method)]
            for metric in METRICS:
                values = subset[metric].to_numpy(dtype=float)
                finite = values[np.isfinite(values)]
                ci_low, ci_high = confidence_interval_95(finite)
                rows.append({
                    "Load": load,
                    "Method": method,
                    "Metric": metric,
                    "Direction": METRICS[metric],
                    "N": int(finite.size),
                    "Mean": float(np.mean(finite)) if finite.size else np.nan,
                    "Std": stable_std(finite),
                    "Median": float(np.median(finite)) if finite.size else np.nan,
                    "Q1": float(np.quantile(finite, 0.25)) if finite.size else np.nan,
                    "Q3": float(np.quantile(finite, 0.75)) if finite.size else np.nan,
                    "IQR": float(np.quantile(finite, 0.75) - np.quantile(finite, 0.25))
                    if finite.size else np.nan,
                    "CI95_Lower": ci_low,
                    "CI95_Upper": ci_high,
                })
    return pd.DataFrame(rows)


def paired_matrix(raw: pd.DataFrame, load: str, metric: str) -> pd.DataFrame:
    matrix = raw[raw["Load"] == load].pivot(index="Run", columns="Method", values=metric)
    return matrix[METHODS].dropna()


def overall_tests(raw: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    friedman_rows: list[dict[str, object]] = []
    rank_rows: list[dict[str, object]] = []
    for load in LOADS:
        for metric, direction in METRICS.items():
            matrix = paired_matrix(raw, load, metric)
            if len(matrix) < 2:
                continue
            samples = [matrix[m].to_numpy(dtype=float) for m in METHODS]
            q, p_value = friedmanchisquare(*samples)
            n = len(matrix)
            k = len(METHODS)
            denominator = n * (k - 1) - q
            iman = ((n - 1) * q / denominator) if denominator > 0 else np.inf
            iman_p = float(f_distribution.sf(iman, k - 1, (k - 1) * (n - 1)))
            friedman_rows.append({
                "Load": load,
                "Metric": metric,
                "Direction": direction,
                "N_Runs": n,
                "Algorithms": k,
                "Friedman_Q": float(q),
                "Friedman_p": float(p_value),
                "ImanDavenport_F": float(iman),
                "ImanDavenport_p": iman_p,
            })

            sign = -1.0 if direction == "higher" else 1.0
            ranks_by_run = np.vstack([
                rankdata(sign * row.to_numpy(dtype=float), method="average")
                for _, row in matrix.iterrows()
            ])
            average_ranks = ranks_by_run.mean(axis=0)
            for method, avg_rank in zip(METHODS, average_ranks):
                rank_rows.append({
                    "Load": load,
                    "Metric": metric,
                    "Method": method,
                    "AverageRank": float(avg_rank),
                })
    return pd.DataFrame(friedman_rows), pd.DataFrame(rank_rows)


def pairwise_tests(raw: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows: list[dict[str, object]] = []
    for load in LOADS:
        for metric, direction in METRICS.items():
            matrix = paired_matrix(raw, load, metric)
            if matrix.empty:
                continue
            local_rows: list[dict[str, object]] = []
            raw_p: list[float] = []
            for baseline in [m for m in METHODS if m != "ARHO"]:
                arho = matrix["ARHO"].to_numpy(dtype=float)
                other = matrix[baseline].to_numpy(dtype=float)
                advantage = arho - other if direction == "higher" else other - arho
                nonzero = advantage[np.isfinite(advantage) & (advantage != 0)]
                if nonzero.size == 0:
                    p_value = 1.0
                else:
                    p_value = float(wilcoxon(
                        nonzero,
                        zero_method="wilcox",
                        correction=True,
                        alternative="two-sided",
                        method="auto",
                    ).pvalue)
                raw_p.append(p_value)
                local_rows.append({
                    "Load": load,
                    "Metric": metric,
                    "Direction": direction,
                    "Baseline": baseline,
                    "N_Pairs": int(np.isfinite(advantage).sum()),
                    "Median_ARHO": float(np.nanmedian(arho)),
                    "Median_Baseline": float(np.nanmedian(other)),
                    "Median_Advantage": float(np.nanmedian(advantage)),
                    "RawP": p_value,
                    "RankBiserial_ARHO_Advantage": rank_biserial_advantage(advantage),
                })
            adjusted = holm_adjust(np.asarray(raw_p))
            for row, adj in zip(local_rows, adjusted):
                row["HolmAdjustedP"] = float(adj)
                if adj < 0.05 and row["Median_Advantage"] > 0:
                    decision = "Win"
                elif adj < 0.05 and row["Median_Advantage"] < 0:
                    decision = "Loss"
                else:
                    decision = "Tie"
                row["Decision"] = decision
                rows.append(row)

    pairwise = pd.DataFrame(rows)
    wtl = (pairwise.groupby(["Load", "Baseline", "Decision"])
           .size().unstack(fill_value=0).reset_index())
    for column in ["Win", "Tie", "Loss"]:
        if column not in wtl:
            wtl[column] = 0
    wtl = wtl[["Load", "Baseline", "Win", "Tie", "Loss"]]
    return pairwise, wtl


def create_plots(raw: pd.DataFrame, output_dir: Path) -> None:
    plot_dir = output_dir / "plots"
    plot_dir.mkdir(parents=True, exist_ok=True)
    for load in LOADS:
        for metric in METRICS:
            data = [
                raw[(raw["Load"] == load) & (raw["Method"] == method)][metric]
                .dropna().to_numpy(dtype=float)
                for method in METHODS
            ]
            fig, ax = plt.subplots(figsize=(7.2, 4.8))
            ax.boxplot(data, labels=METHODS, showmeans=True)
            ax.set_title(f"{metric} — {load} load")
            ax.set_xlabel("Mobility / spatial method")
            ax.set_ylabel(metric)
            ax.grid(axis="y", alpha=0.25)
            fig.tight_layout()
            fig.savefig(plot_dir / f"{load}_{metric}.png", dpi=220)
            plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--expected-runs", type=int, default=30)
    parser.add_argument("--skip-plots", action="store_true")
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    raw = collect_raw(args.raw_dir)
    raw = raw.sort_values(["Load", "Method", "Run"]).reset_index(drop=True)
    raw.to_csv(args.output_dir / "RawNetworkResults.csv", index=False)

    checks = validation_checks(raw, args.expected_runs)
    checks.to_csv(args.output_dir / "ValidationChecks.csv", index=False)

    summary = summarize(raw)
    summary.to_csv(args.output_dir / "SummaryNetworkResults.csv", index=False)

    friedman, ranks = overall_tests(raw)
    friedman.to_csv(args.output_dir / "FriedmanImanDavenport.csv", index=False)
    ranks.to_csv(args.output_dir / "MethodAverageRanks.csv", index=False)

    pairwise, wtl = pairwise_tests(raw)
    pairwise.to_csv(args.output_dir / "WilcoxonHolmEffectSizes.csv", index=False)
    wtl.to_csv(args.output_dir / "WinTieLossAcrossMetrics.csv", index=False)

    if not args.skip_plots:
        create_plots(raw, args.output_dir)

    failed = checks.loc[~checks["Passed"]]
    print(f"Collected rows: {len(raw)}")
    print(checks.to_string(index=False))
    if not failed.empty:
        raise SystemExit("Validation failed; inspect ValidationChecks.csv")
    print(f"PASS: analysis written to {args.output_dir}")


if __name__ == "__main__":
    main()
