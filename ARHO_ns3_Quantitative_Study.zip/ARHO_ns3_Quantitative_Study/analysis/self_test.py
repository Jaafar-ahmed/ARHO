#!/usr/bin/env python3
"""Synthetic end-to-end self-test for analyze_results.py; no ns-3 required."""
from __future__ import annotations
import subprocess
import tempfile
from pathlib import Path
import numpy as np
import pandas as pd

methods=['ARHO','PSO','RWP','GM']
loads=['moderate','stress']
rng=np.random.default_rng(7)
with tempfile.TemporaryDirectory() as td:
    root=Path(td); raw=root/'raw'; out=root/'out'; raw.mkdir()
    for load_i,load in enumerate(loads):
        for run in range(1,4):
            init=1000+run; traffic=2000+load_i
            for method_i,method in enumerate(methods):
                pdr=95-method_i*2-load_i+rng.normal(0,.2)
                row={
                    'Method':method,'Load':load,'Seed':12345,'Run':run,'Nodes':30,
                    'AreaX_m':500,'AreaY_m':500,'Duration_s':120,'TrafficStart_s':10,
                    'TrafficStop_s':115,'UpdateInterval_s':1,'MinSpeed_mps':1,
                    'MaxSpeed_mps':3,'Flows':10 if load=='moderate' else 20,
                    'PacketRate_pps':10 if load=='moderate' else 20,'PacketSize_bytes':512,
                    'WifiStandard':'IEEE802.11g-AdHoc','PhyRate':'ErpOfdmRate6Mbps',
                    'TxPower_dBm':20,'RxNoiseFigure_dB':7,'PropagationModel':'LogDistance',
                    'PathLossExponent':3,'ReferenceLoss_dB':40.046,'ReferenceDistance_m':1,
                    'TopologyLinkThreshold_dBm':-85,'CrowdingDistance_m':20,
                    'InitialPositionChecksum':init,'TrafficChecksum':traffic,
                    'TxPackets':10000,'RxPackets':round(100*pdr),'TxBytes':5120000,
                    'RxBytes':round(51200*pdr),'PDR_percent':pdr,
                    'Throughput_Mbps':3.8-method_i*.1,'MeanDelay_ms':8+method_i,
                    'MeanJitter_ms':2+method_i*.1,'PacketLoss_percent':100-pdr,
                    'MeanPhySnr_dB':25-method_i,'SnrSamples':1000,
                    'MeanLinkDuration_s':35-method_i,'TopologyChanges':100+method_i*10,
                    'TopologyChangesPerNodeSecond':.03+method_i*.005,
                    'MeanLargestComponentFraction':.98-method_i*.02,
                    'MeanIsolatedNodes':method_i*.2,'MeanActiveLinks':120-method_i*5,
                    'TopologySamples':106,
                }
                pd.DataFrame([row]).to_csv(raw/f'{method}_{load}_{run}.csv',index=False)
    script=Path(__file__).with_name('analyze_results.py')
    subprocess.run(['python3',str(script),'--raw-dir',str(raw),'--output-dir',str(out),
                    '--expected-runs','3','--skip-plots'],check=True)
    checks=pd.read_csv(out/'ValidationChecks.csv')
    assert checks.Passed.all()
    assert len(pd.read_csv(out/'RawNetworkResults.csv'))==24
print('PASS: Python analysis self-test completed.')
