/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * Quantitative ns-3 validation of ARHO-based spatial mobility.
 * Target: ns-3.47 (February 2026).
 *
 * Methods:
 *   ARHO - full hotspot-memory mobility controller
 *   PSO  - particle-swarm spatial optimization baseline
 *   RWP  - random waypoint mobility baseline
 *   GM   - Gauss-Markov mobility baseline
 *
 * The optimization utility is geometry/link-quality based and is deliberately
 * independent of the reported packet-level outcome metrics.
 */

#include "ns3/aodv-module.h"
#include "ns3/applications-module.h"
#include "ns3/core-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/network-module.h"
#include "ns3/propagation-module.h"
#include "ns3/wifi-module.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

using namespace ns3;
using namespace ns3::wifi;

NS_LOG_COMPONENT_DEFINE("ArhoNs3QuantitativeStudy");

namespace
{

constexpr double PI = 3.14159265358979323846;

struct StudyConfig
{
    std::string method{"ARHO"};
    std::string load{"moderate"};
    uint64_t seed{12345};
    uint64_t run{1};

    uint32_t nNodes{30};
    double areaX{500.0};
    double areaY{500.0};
    double duration{120.0};
    double trafficStart{10.0};
    double trafficStop{115.0};
    double updateInterval{1.0};
    double minSpeed{1.0};
    double maxSpeed{3.0};

    uint32_t nFlows{0};
    double packetRatePps{0.0};
    uint32_t packetSizeBytes{512};

    double txPowerDbm{20.0};
    double rxNoiseFigureDb{7.0};
    double pathLossExponent{3.0};
    double referenceLossDb{40.046};
    double referenceDistanceM{1.0};
    double noiseFloorDbm{-96.0};
    double topologyLinkThresholdDbm{-85.0};
    double crowdingDistanceM{20.0};

    double rwpPauseSeconds{1.0};
    double gmAlpha{0.85};
    double gmVelocityStd{0.25};
    double gmDirectionStd{0.20};

    std::string outputFile{"result.csv"};
    bool enablePcap{false};
    bool verbose{false};
};

struct NetworkMetrics
{
    uint64_t txPackets{0};
    uint64_t rxPackets{0};
    uint64_t txBytes{0};
    uint64_t rxBytes{0};
    double pdrPercent{0.0};
    double throughputMbps{0.0};
    double meanDelayMs{std::numeric_limits<double>::quiet_NaN()};
    double meanJitterMs{std::numeric_limits<double>::quiet_NaN()};
    double packetLossPercent{0.0};
};

struct SnrAccumulator
{
    double sumDb{0.0};
    uint64_t samples{0};
    double start{0.0};
    double stop{0.0};
};

SnrAccumulator g_snr;

void
MonitorSniffRx(Ptr<const Packet> packet,
               uint16_t channelFreqMhz,
               WifiTxVector txVector,
               MpduInfo aMpdu,
               SignalNoiseDbm signalNoise,
               uint16_t staId)
{
    (void)packet;
    (void)channelFreqMhz;
    (void)txVector;
    (void)aMpdu;
    (void)staId;

    const double now = Simulator::Now().GetSeconds();
    if (now >= g_snr.start && now <= g_snr.stop)
    {
        const double snrDb = signalNoise.signal - signalNoise.noise;
        if (std::isfinite(snrDb))
        {
            g_snr.sumDb += snrDb;
            ++g_snr.samples;
        }
    }
}

double
Clamp(double value, double lower, double upper)
{
    return std::max(lower, std::min(value, upper));
}

double
Distance2D(const Vector& a, const Vector& b)
{
    const double dx = a.x - b.x;
    const double dy = a.y - b.y;
    return std::sqrt(dx * dx + dy * dy);
}

Vector
ClampToArea(const Vector& p, const StudyConfig& cfg)
{
    return Vector(Clamp(p.x, 0.0, cfg.areaX), Clamp(p.y, 0.0, cfg.areaY), 0.0);
}

Vector
LimitDisplacement(const Vector& from, const Vector& proposed, double maxDistance)
{
    const double dx = proposed.x - from.x;
    const double dy = proposed.y - from.y;
    const double norm = std::sqrt(dx * dx + dy * dy);
    if (norm <= maxDistance || norm <= 1e-15)
    {
        return proposed;
    }
    const double scale = maxDistance / norm;
    return Vector(from.x + scale * dx, from.y + scale * dy, 0.0);
}

double
EstimatedRxPowerDbm(double distanceM, const StudyConfig& cfg)
{
    const double d = std::max(distanceM, cfg.referenceDistanceM);
    return cfg.txPowerDbm - cfg.referenceLossDb -
           10.0 * cfg.pathLossExponent * std::log10(d / cfg.referenceDistanceM);
}

double
LinkScore(double distanceM, const StudyConfig& cfg)
{
    const double snrDb = EstimatedRxPowerDbm(distanceM, cfg) - cfg.noiseFloorDbm;
    // Linear clipping from unusable (5 dB) to strong (30 dB).
    return Clamp((snrDb - 5.0) / 25.0, 0.0, 1.0);
}

std::vector<Vector>
GetPositions(const NodeContainer& nodes)
{
    std::vector<Vector> positions;
    positions.reserve(nodes.GetN());
    for (uint32_t i = 0; i < nodes.GetN(); ++i)
    {
        positions.push_back(nodes.Get(i)->GetObject<MobilityModel>()->GetPosition());
    }
    return positions;
}

void
SetPositions(const NodeContainer& nodes, const std::vector<Vector>& positions)
{
    NS_ABORT_MSG_IF(nodes.GetN() != positions.size(), "Position vector size mismatch");
    for (uint32_t i = 0; i < nodes.GetN(); ++i)
    {
        nodes.Get(i)->GetObject<MobilityModel>()->SetPosition(positions[i]);
    }
}

std::vector<Vector>
GenerateInitialPositions(const StudyConfig& cfg)
{
    Ptr<UniformRandomVariable> xRv = CreateObject<UniformRandomVariable>();
    Ptr<UniformRandomVariable> yRv = CreateObject<UniformRandomVariable>();
    xRv->SetStream(101);
    yRv->SetStream(102);

    const double marginX = 0.05 * cfg.areaX;
    const double marginY = 0.05 * cfg.areaY;
    std::vector<Vector> positions;
    positions.reserve(cfg.nNodes);
    for (uint32_t i = 0; i < cfg.nNodes; ++i)
    {
        positions.emplace_back(xRv->GetValue(marginX, cfg.areaX - marginX),
                               yRv->GetValue(marginY, cfg.areaY - marginY),
                               0.0);
    }
    return positions;
}

double
PositionChecksum(const std::vector<Vector>& positions)
{
    double checksum = 0.0;
    for (uint32_t i = 0; i < positions.size(); ++i)
    {
        checksum += static_cast<double>(i + 1) *
                    (positions[i].x + 3.0 * positions[i].y);
    }
    return checksum;
}

std::vector<uint32_t>
BuildPartners(uint32_t nNodes)
{
    std::vector<uint32_t> partners(nNodes);
    const uint32_t offset = std::max<uint32_t>(1, nNodes / 2);
    for (uint32_t i = 0; i < nNodes; ++i)
    {
        partners[i] = (i + offset) % nNodes;
    }
    return partners;
}

double
TrafficChecksum(uint32_t nNodes, uint32_t nFlows)
{
    double checksum = 0.0;
    const uint32_t offset = std::max<uint32_t>(1, nNodes / 2);
    for (uint32_t i = 0; i < nFlows; ++i)
    {
        const uint32_t source = i % nNodes;
        const uint32_t destination = (source + offset) % nNodes;
        checksum += static_cast<double>(i + 1) *
                    (static_cast<double>(source + 1) +
                     7.0 * static_cast<double>(destination + 1));
    }
    return checksum;
}

// Lower is better. This utility is independent of PDR, throughput, and delay.
double
NodeMerit(uint32_t nodeIndex,
          const Vector& candidate,
          const std::vector<Vector>& positions,
          const std::vector<uint32_t>& partners,
          const StudyConfig& cfg)
{
    const uint32_t n = positions.size();
    NS_ABORT_MSG_IF(nodeIndex >= n, "Node index out of range");

    const Vector partnerPosition = positions[partners[nodeIndex]];
    const double partnerScore = LinkScore(Distance2D(candidate, partnerPosition), cfg);

    double neighborScoreSum = 0.0;
    uint32_t connected = 0;
    uint32_t crowded = 0;
    for (uint32_t j = 0; j < n; ++j)
    {
        if (j == nodeIndex)
        {
            continue;
        }
        const double d = Distance2D(candidate, positions[j]);
        neighborScoreSum += LinkScore(d, cfg);
        if (EstimatedRxPowerDbm(d, cfg) >= cfg.topologyLinkThresholdDbm)
        {
            ++connected;
        }
        if (d < cfg.crowdingDistanceM)
        {
            ++crowded;
        }
    }

    const double denominator = static_cast<double>(std::max<uint32_t>(1, n - 1));
    const double neighborScore = neighborScoreSum / denominator;
    const double connectivityRatio = static_cast<double>(connected) / denominator;
    const double crowdingRatio = static_cast<double>(crowded) / denominator;

    const double utility = 0.45 * partnerScore + 0.35 * neighborScore +
                           0.20 * connectivityRatio - 0.15 * crowdingRatio;
    return -utility;
}

class MobilityController
{
  public:
    MobilityController(NodeContainer nodes,
                       StudyConfig cfg,
                       std::vector<uint32_t> partners)
        : m_nodes(std::move(nodes)),
          m_cfg(std::move(cfg)),
          m_partners(std::move(partners))
    {
    }

    virtual ~MobilityController() = default;

    void Start()
    {
        Initialize();
        Simulator::Schedule(Seconds(m_cfg.updateInterval),
                            &MobilityController::Tick,
                            this);
    }

  protected:
    virtual void Initialize() {}
    virtual void Step() = 0;

    NodeContainer m_nodes;
    StudyConfig m_cfg;
    std::vector<uint32_t> m_partners;

  private:
    void Tick()
    {
        Step();
        const double next = Simulator::Now().GetSeconds() + m_cfg.updateInterval;
        if (next <= m_cfg.trafficStop + 1e-9)
        {
            Simulator::Schedule(Seconds(m_cfg.updateInterval),
                                &MobilityController::Tick,
                                this);
        }
    }
};

class RandomWaypointController final : public MobilityController
{
  public:
    RandomWaypointController(NodeContainer nodes,
                             StudyConfig cfg,
                             std::vector<uint32_t> partners)
        : MobilityController(std::move(nodes), std::move(cfg), std::move(partners)),
          m_uniform(CreateObject<UniformRandomVariable>())
    {
        m_uniform->SetStream(10001);
    }

  protected:
    void Initialize() override
    {
        const uint32_t n = m_nodes.GetN();
        m_targets.resize(n);
        m_speeds.resize(n);
        m_pauseRemaining.assign(n, 0.0);
        for (uint32_t i = 0; i < n; ++i)
        {
            SelectNewTarget(i);
        }
    }

    void Step() override
    {
        std::vector<Vector> positions = GetPositions(m_nodes);
        for (uint32_t i = 0; i < positions.size(); ++i)
        {
            if (m_pauseRemaining[i] > 0.0)
            {
                m_pauseRemaining[i] =
                    std::max(0.0, m_pauseRemaining[i] - m_cfg.updateInterval);
                if (m_pauseRemaining[i] <= 0.0)
                {
                    SelectNewTarget(i);
                }
                continue;
            }

            const double remaining = Distance2D(positions[i], m_targets[i]);
            const double stepDistance = m_speeds[i] * m_cfg.updateInterval;
            if (remaining <= stepDistance)
            {
                positions[i] = m_targets[i];
                m_pauseRemaining[i] = m_cfg.rwpPauseSeconds;
            }
            else
            {
                positions[i] = LimitDisplacement(positions[i], m_targets[i], stepDistance);
            }
        }
        SetPositions(m_nodes, positions);
    }

  private:
    void SelectNewTarget(uint32_t i)
    {
        m_targets[i] = Vector(m_uniform->GetValue(0.0, m_cfg.areaX),
                              m_uniform->GetValue(0.0, m_cfg.areaY),
                              0.0);
        m_speeds[i] = m_uniform->GetValue(m_cfg.minSpeed, m_cfg.maxSpeed);
    }

    Ptr<UniformRandomVariable> m_uniform;
    std::vector<Vector> m_targets;
    std::vector<double> m_speeds;
    std::vector<double> m_pauseRemaining;
};

class GaussMarkovController final : public MobilityController
{
  public:
    GaussMarkovController(NodeContainer nodes,
                          StudyConfig cfg,
                          std::vector<uint32_t> partners)
        : MobilityController(std::move(nodes), std::move(cfg), std::move(partners)),
          m_uniform(CreateObject<UniformRandomVariable>()),
          m_normal(CreateObject<NormalRandomVariable>())
    {
        m_uniform->SetStream(11001);
        m_normal->SetStream(11002);
        m_normal->SetAttribute("Mean", DoubleValue(0.0));
        m_normal->SetAttribute("Variance", DoubleValue(1.0));
        m_normal->SetAttribute("Bound", DoubleValue(4.0));
    }

  protected:
    void Initialize() override
    {
        const uint32_t n = m_nodes.GetN();
        m_meanSpeed.resize(n);
        m_speed.resize(n);
        m_meanDirection.resize(n);
        m_direction.resize(n);
        for (uint32_t i = 0; i < n; ++i)
        {
            m_meanSpeed[i] = m_uniform->GetValue(m_cfg.minSpeed, m_cfg.maxSpeed);
            m_speed[i] = m_meanSpeed[i];
            m_meanDirection[i] = m_uniform->GetValue(0.0, 2.0 * PI);
            m_direction[i] = m_meanDirection[i];
        }
    }

    void Step() override
    {
        std::vector<Vector> positions = GetPositions(m_nodes);
        const double alpha = m_cfg.gmAlpha;
        const double innovation = std::sqrt(std::max(0.0, 1.0 - alpha * alpha));

        for (uint32_t i = 0; i < positions.size(); ++i)
        {
            m_speed[i] = alpha * m_speed[i] + (1.0 - alpha) * m_meanSpeed[i] +
                         innovation * m_cfg.gmVelocityStd * m_normal->GetValue();
            m_speed[i] = Clamp(m_speed[i], m_cfg.minSpeed, m_cfg.maxSpeed);

            m_direction[i] = alpha * m_direction[i] +
                             (1.0 - alpha) * m_meanDirection[i] +
                             innovation * m_cfg.gmDirectionStd * m_normal->GetValue();

            Vector proposed(positions[i].x +
                                m_speed[i] * m_cfg.updateInterval * std::cos(m_direction[i]),
                            positions[i].y +
                                m_speed[i] * m_cfg.updateInterval * std::sin(m_direction[i]),
                            0.0);

            if (proposed.x < 0.0 || proposed.x > m_cfg.areaX)
            {
                m_direction[i] = PI - m_direction[i];
                proposed.x = Clamp(proposed.x, 0.0, m_cfg.areaX);
            }
            if (proposed.y < 0.0 || proposed.y > m_cfg.areaY)
            {
                m_direction[i] = -m_direction[i];
                proposed.y = Clamp(proposed.y, 0.0, m_cfg.areaY);
            }
            positions[i] = proposed;
        }
        SetPositions(m_nodes, positions);
    }

  private:
    Ptr<UniformRandomVariable> m_uniform;
    Ptr<NormalRandomVariable> m_normal;
    std::vector<double> m_meanSpeed;
    std::vector<double> m_speed;
    std::vector<double> m_meanDirection;
    std::vector<double> m_direction;
};

class PsoController final : public MobilityController
{
  public:
    PsoController(NodeContainer nodes,
                  StudyConfig cfg,
                  std::vector<uint32_t> partners)
        : MobilityController(std::move(nodes), std::move(cfg), std::move(partners)),
          m_uniform(CreateObject<UniformRandomVariable>())
    {
        m_uniform->SetStream(12001);
    }

  protected:
    void Initialize() override
    {
        const std::vector<Vector> positions = GetPositions(m_nodes);
        const uint32_t n = positions.size();
        m_velocity.assign(n, Vector(0.0, 0.0, 0.0));
        m_personalBestPosition = positions;
        m_personalBestMerit.resize(n);
        for (uint32_t i = 0; i < n; ++i)
        {
            m_personalBestMerit[i] =
                NodeMerit(i, positions[i], positions, m_partners, m_cfg);
        }
        UpdateGlobalBest();
    }

    void Step() override
    {
        std::vector<Vector> positions = GetPositions(m_nodes);
        for (uint32_t i = 0; i < positions.size(); ++i)
        {
            const double merit = NodeMerit(i, positions[i], positions, m_partners, m_cfg);
            if (merit < m_personalBestMerit[i])
            {
                m_personalBestMerit[i] = merit;
                m_personalBestPosition[i] = positions[i];
            }
        }
        UpdateGlobalBest();

        const double progress = Clamp(Simulator::Now().GetSeconds() / m_cfg.trafficStop,
                                      0.0,
                                      1.0);
        const double inertia = 0.9 - 0.5 * progress;
        constexpr double c1 = 2.0;
        constexpr double c2 = 2.0;
        const double maxDisplacement = m_cfg.maxSpeed * m_cfg.updateInterval;

        std::vector<Vector> proposed = positions;
        for (uint32_t i = 0; i < positions.size(); ++i)
        {
            const double r1x = m_uniform->GetValue();
            const double r1y = m_uniform->GetValue();
            const double r2x = m_uniform->GetValue();
            const double r2y = m_uniform->GetValue();

            m_velocity[i].x = inertia * m_velocity[i].x +
                              c1 * r1x * (m_personalBestPosition[i].x - positions[i].x) +
                              c2 * r2x * (m_globalBestPosition.x - positions[i].x);
            m_velocity[i].y = inertia * m_velocity[i].y +
                              c1 * r1y * (m_personalBestPosition[i].y - positions[i].y) +
                              c2 * r2y * (m_globalBestPosition.y - positions[i].y);

            const double velocityNorm =
                std::sqrt(m_velocity[i].x * m_velocity[i].x +
                          m_velocity[i].y * m_velocity[i].y);
            if (velocityNorm > maxDisplacement)
            {
                const double scale = maxDisplacement / velocityNorm;
                m_velocity[i].x *= scale;
                m_velocity[i].y *= scale;
            }

            proposed[i] = ClampToArea(Vector(positions[i].x + m_velocity[i].x,
                                             positions[i].y + m_velocity[i].y,
                                             0.0),
                                      m_cfg);
        }
        SetPositions(m_nodes, proposed);
    }

  private:
    void UpdateGlobalBest()
    {
        const auto iterator =
            std::min_element(m_personalBestMerit.begin(), m_personalBestMerit.end());
        const uint32_t index =
            static_cast<uint32_t>(std::distance(m_personalBestMerit.begin(), iterator));
        m_globalBestMerit = *iterator;
        m_globalBestPosition = m_personalBestPosition[index];
    }

    Ptr<UniformRandomVariable> m_uniform;
    std::vector<Vector> m_velocity;
    std::vector<Vector> m_personalBestPosition;
    std::vector<double> m_personalBestMerit;
    Vector m_globalBestPosition;
    double m_globalBestMerit{std::numeric_limits<double>::infinity()};
};

class ArhoController final : public MobilityController
{
  private:
    struct Record
    {
        Vector position;
        double merit{std::numeric_limits<double>::infinity()};
    };

    struct Hotspot
    {
        Vector center;
        double score{1.0};
        uint32_t occupancy{0};
        double sigma{0.10};
        double previousQuality{0.0};
        uint32_t noImprove{0};
        Record representative;
    };

  public:
    ArhoController(NodeContainer nodes,
                   StudyConfig cfg,
                   std::vector<uint32_t> partners)
        : MobilityController(std::move(nodes), std::move(cfg), std::move(partners)),
          m_uniform(CreateObject<UniformRandomVariable>()),
          m_normal(CreateObject<NormalRandomVariable>())
    {
        m_uniform->SetStream(13001);
        m_normal->SetStream(13002);
        m_normal->SetAttribute("Mean", DoubleValue(0.0));
        m_normal->SetAttribute("Variance", DoubleValue(1.0));
        m_normal->SetAttribute("Bound", DoubleValue(4.0));
    }

  protected:
    void Initialize() override
    {
        const std::vector<Vector> positions = GetPositions(m_nodes);
        m_records.resize(positions.size());
        for (uint32_t i = 0; i < positions.size(); ++i)
        {
            m_records[i] = Evaluate(i, positions[i], positions);
        }
        const uint32_t bestIndex = BestRecordIndex(m_records);
        m_best = m_records[bestIndex];
    }

    void Step() override
    {
        const std::vector<Vector> positions = GetPositions(m_nodes);
        RefreshRecords(positions);
        UpdateArchive(positions);
        NS_ABORT_MSG_IF(m_archive.empty(), "ARHO archive is empty");

        const double progress = Clamp(Simulator::Now().GetSeconds() / m_cfg.trafficStop,
                                      0.0,
                                      1.0);
        const bool leaderTrigger =
            (m_lastImprovement > 1e-6) || (m_globalStagnation >= 10);

        std::vector<Vector> proposed = positions;
        for (uint32_t i = 0; i < positions.size(); ++i)
        {
            const uint32_t hotspotIndex = SelectHotspot();
            proposed[i] = GenerateCandidate(i,
                                            positions[i],
                                            positions,
                                            m_archive[hotspotIndex],
                                            progress,
                                            leaderTrigger);
        }
        SetPositions(m_nodes, proposed);

        RefreshRecords(proposed);
        const Record previousBest = m_best;
        const uint32_t currentBestIndex = BestRecordIndex(m_records);
        if (m_records[currentBestIndex].merit < m_best.merit)
        {
            m_best = m_records[currentBestIndex];
        }

        if (m_best.merit < previousBest.merit)
        {
            m_lastImprovement = previousBest.merit - m_best.merit;
            m_globalStagnation = 0;
        }
        else
        {
            m_lastImprovement = 0.0;
            ++m_globalStagnation;
        }
    }

  private:
    Record Evaluate(uint32_t nodeIndex,
                    const Vector& position,
                    const std::vector<Vector>& population) const
    {
        return Record{position,
                      NodeMerit(nodeIndex,
                                position,
                                population,
                                m_partners,
                                m_cfg)};
    }

    void RefreshRecords(const std::vector<Vector>& positions)
    {
        for (uint32_t i = 0; i < positions.size(); ++i)
        {
            m_records[i] = Evaluate(i, positions[i], positions);
        }
    }

    static uint32_t BestRecordIndex(const std::vector<Record>& records)
    {
        uint32_t best = 0;
        for (uint32_t i = 1; i < records.size(); ++i)
        {
            if (records[i].merit < records[best].merit)
            {
                best = i;
            }
        }
        return best;
    }

    double NormalizedDistance(const Vector& a, const Vector& b) const
    {
        const double dx = (a.x - b.x) / m_cfg.areaX;
        const double dy = (a.y - b.y) / m_cfg.areaY;
        return std::sqrt(dx * dx + dy * dy) / std::sqrt(2.0);
    }

    uint32_t CountOccupancy(const Vector& center,
                            double sigma,
                            const std::vector<Vector>& positions) const
    {
        const double effectiveRadius = std::max(sigma, 0.10);
        uint32_t count = 0;
        for (const Vector& p : positions)
        {
            if (NormalizedDistance(p, center) <= effectiveRadius)
            {
                ++count;
            }
        }
        return count;
    }

    void UpdateArchive(const std::vector<Vector>& positions)
    {
        const uint32_t n = positions.size();
        std::vector<uint32_t> order(n);
        std::iota(order.begin(), order.end(), 0);
        std::stable_sort(order.begin(), order.end(), [this](uint32_t a, uint32_t b) {
            return m_records[a].merit < m_records[b].merit;
        });

        const uint32_t eliteCount =
            std::max<uint32_t>(1, static_cast<uint32_t>(std::ceil(0.20 * n)));
        std::vector<std::vector<uint32_t>> assignments(m_archive.size());

        for (uint32_t q = 0; q < eliteCount; ++q)
        {
            const uint32_t index = order[q];
            const Vector x = positions[index];
            if (m_archive.empty())
            {
                Hotspot h;
                h.center = x;
                h.representative = m_records[index];
                m_archive.push_back(h);
                assignments.resize(1);
                assignments[0].push_back(index);
                continue;
            }

            uint32_t nearest = 0;
            double minimumDistance = NormalizedDistance(x, m_archive[0].center);
            for (uint32_t j = 1; j < m_archive.size(); ++j)
            {
                const double d = NormalizedDistance(x, m_archive[j].center);
                if (d < minimumDistance)
                {
                    minimumDistance = d;
                    nearest = j;
                }
            }

            const double assignmentRadius = std::max(m_archive[nearest].sigma, 0.15);
            if (minimumDistance <= assignmentRadius)
            {
                assignments.resize(m_archive.size());
                assignments[nearest].push_back(index);
            }
            else
            {
                Hotspot h;
                h.center = x;
                h.representative = m_records[index];
                m_archive.push_back(h);
                assignments.resize(m_archive.size());
                assignments.back().push_back(index);
            }
        }

        std::vector<bool> updated(m_archive.size(), false);
        for (uint32_t j = 0; j < m_archive.size(); ++j)
        {
            if (j >= assignments.size() || assignments[j].empty())
            {
                continue;
            }
            updated[j] = true;
            Vector mean(0.0, 0.0, 0.0);
            uint32_t representativeIndex = assignments[j][0];
            for (uint32_t index : assignments[j])
            {
                mean.x += positions[index].x;
                mean.y += positions[index].y;
                if (m_records[index].merit < m_records[representativeIndex].merit)
                {
                    representativeIndex = index;
                }
            }
            mean.x /= static_cast<double>(assignments[j].size());
            mean.y /= static_cast<double>(assignments[j].size());
            m_archive[j].center = ClampToArea(
                Vector(0.5 * m_archive[j].center.x + 0.5 * mean.x,
                       0.5 * m_archive[j].center.y + 0.5 * mean.y,
                       0.0),
                m_cfg);
            m_archive[j].representative = m_records[representativeIndex];
        }

        double bestMerit = std::numeric_limits<double>::infinity();
        double worstMerit = -std::numeric_limits<double>::infinity();
        for (const Hotspot& h : m_archive)
        {
            bestMerit = std::min(bestMerit, h.representative.merit);
            worstMerit = std::max(worstMerit, h.representative.merit);
        }
        const double range = worstMerit - bestMerit;

        for (uint32_t j = 0; j < m_archive.size(); ++j)
        {
            const double quality =
                (range <= 1e-12)
                    ? 1.0
                    : Clamp((worstMerit - m_archive[j].representative.merit + 1e-12) /
                                (range + 1e-12),
                            1e-12,
                            1.0);
            const double temporaryScore =
                0.70 * m_archive[j].score + 0.30 * quality;
            const bool improved =
                updated[j] && quality > m_archive[j].previousQuality + 1e-12;

            if (improved)
            {
                m_archive[j].noImprove = 0;
                m_archive[j].sigma = std::max(0.02, 0.90 * m_archive[j].sigma);
            }
            else
            {
                ++m_archive[j].noImprove;
                m_archive[j].sigma = std::min(0.30, 1.10 * m_archive[j].sigma);
            }

            m_archive[j].score =
                (m_archive[j].noImprove >= 5) ? 0.90 * temporaryScore : temporaryScore;
            m_archive[j].previousQuality = quality;
        }

        if (m_archive.size() > 1)
        {
            m_archive.erase(std::remove_if(m_archive.begin(),
                                           m_archive.end(),
                                           [](const Hotspot& h) {
                                               return h.score < 0.05;
                                           }),
                            m_archive.end());
        }
        if (m_archive.empty())
        {
            Hotspot h;
            const uint32_t bestIndex = BestRecordIndex(m_records);
            h.center = positions[bestIndex];
            h.representative = m_records[bestIndex];
            m_archive.push_back(h);
        }

        const uint32_t maxHotspots =
            std::max<uint32_t>(5, static_cast<uint32_t>(std::ceil(0.50 * n)));
        if (m_archive.size() > maxHotspots)
        {
            std::stable_sort(m_archive.begin(),
                             m_archive.end(),
                             [](const Hotspot& a, const Hotspot& b) {
                                 return a.score > b.score;
                             });
            m_archive.resize(maxHotspots);
        }

        for (Hotspot& h : m_archive)
        {
            h.occupancy = CountOccupancy(h.center, h.sigma, positions);
        }
    }

    uint32_t SelectHotspot()
    {
        std::vector<double> logWeights(m_archive.size());
        double maximum = -std::numeric_limits<double>::infinity();
        for (uint32_t j = 0; j < m_archive.size(); ++j)
        {
            logWeights[j] = 5.0 * m_archive[j].score -
                            1.5 * std::log(1.0 + m_archive[j].occupancy);
            maximum = std::max(maximum, logWeights[j]);
        }

        std::vector<double> weights(m_archive.size());
        double total = 0.0;
        for (uint32_t j = 0; j < m_archive.size(); ++j)
        {
            weights[j] = std::exp(logWeights[j] - maximum);
            total += weights[j];
        }
        if (!(total > 0.0) || !std::isfinite(total))
        {
            return static_cast<uint32_t>(m_uniform->GetInteger(0, m_archive.size() - 1));
        }

        const double draw = m_uniform->GetValue(0.0, total);
        double cumulative = 0.0;
        for (uint32_t j = 0; j < weights.size(); ++j)
        {
            cumulative += weights[j];
            if (draw <= cumulative)
            {
                return j;
            }
        }
        return static_cast<uint32_t>(weights.size() - 1);
    }

    Vector PrepareCandidate(const Vector& current, const Vector& raw) const
    {
        const Vector bounded = ClampToArea(raw, m_cfg);
        const Vector limited = LimitDisplacement(current,
                                                 bounded,
                                                 m_cfg.maxSpeed * m_cfg.updateInterval);
        return ClampToArea(limited, m_cfg);
    }

    Vector GenerateCandidate(uint32_t nodeIndex,
                             const Vector& current,
                             const std::vector<Vector>& positions,
                             const Hotspot& hotspot,
                             double progress,
                             bool leaderTrigger)
    {
        const double alpha = 2.0 - 1.8 * progress;
        const double noise = 0.10 * std::pow(1.0 - progress, 2.0);
        const double eta = 0.10 - 0.09 * progress;
        const double pLead = 0.05 + 0.20 * progress;

        Vector broadRaw(current.x +
                            alpha * m_uniform->GetValue() * (hotspot.center.x - current.x) +
                            noise * m_normal->GetValue() * m_cfg.areaX,
                        current.y +
                            alpha * m_uniform->GetValue() * (hotspot.center.y - current.y) +
                            noise * m_normal->GetValue() * m_cfg.areaY,
                        0.0);
        Vector candidate = PrepareCandidate(current, broadRaw);
        double candidateMerit =
            NodeMerit(nodeIndex, candidate, positions, m_partners, m_cfg);

        Vector localRaw(hotspot.center.x +
                            eta * (2.0 * m_uniform->GetValue() - 1.0) *
                                hotspot.sigma * m_cfg.areaX,
                        hotspot.center.y +
                            eta * (2.0 * m_uniform->GetValue() - 1.0) *
                                hotspot.sigma * m_cfg.areaY,
                        0.0);
        const Vector local = PrepareCandidate(current, localRaw);
        const double localMerit =
            NodeMerit(nodeIndex, local, positions, m_partners, m_cfg);
        if (localMerit < candidateMerit)
        {
            candidate = local;
            candidateMerit = localMerit;
        }

        if (leaderTrigger && m_uniform->GetValue() < pLead)
        {
            Vector leaderRaw(candidate.x +
                                 0.30 * m_uniform->GetValue() *
                                     (m_best.position.x - candidate.x),
                             candidate.y +
                                 0.30 * m_uniform->GetValue() *
                                     (m_best.position.y - candidate.y),
                             0.0);
            const Vector leader = PrepareCandidate(current, leaderRaw);
            const double leaderMerit =
                NodeMerit(nodeIndex, leader, positions, m_partners, m_cfg);
            if (leaderMerit < candidateMerit)
            {
                candidate = leader;
                candidateMerit = leaderMerit;
            }
        }

        const uint32_t nmax =
            std::max<uint32_t>(2, static_cast<uint32_t>(std::llround(0.30 * m_nodes.GetN())));
        if (hotspot.occupancy > nmax)
        {
            double dx = (candidate.x - hotspot.center.x) / m_cfg.areaX;
            double dy = (candidate.y - hotspot.center.y) / m_cfg.areaY;
            double norm = std::sqrt(dx * dx + dy * dy);
            if (norm <= 1e-12)
            {
                dx = m_normal->GetValue();
                dy = m_normal->GetValue();
                norm = std::sqrt(dx * dx + dy * dy);
            }
            dx /= (norm + 1e-12);
            dy /= (norm + 1e-12);
            Vector diversifyRaw(candidate.x + 0.05 * dx * m_cfg.areaX,
                                candidate.y + 0.05 * dy * m_cfg.areaY,
                                0.0);
            const Vector diversify = PrepareCandidate(current, diversifyRaw);
            const double diversifyMerit =
                NodeMerit(nodeIndex, diversify, positions, m_partners, m_cfg);
            if (diversifyMerit < candidateMerit)
            {
                candidate = diversify;
            }
        }

        return candidate;
    }

    Ptr<UniformRandomVariable> m_uniform;
    Ptr<NormalRandomVariable> m_normal;
    std::vector<Record> m_records;
    std::vector<Hotspot> m_archive;
    Record m_best;
    double m_lastImprovement{0.0};
    uint32_t m_globalStagnation{0};
};

class TopologyTracker
{
  public:
    TopologyTracker(NodeContainer nodes, StudyConfig cfg)
        : m_nodes(std::move(nodes)),
          m_cfg(std::move(cfg)),
          m_activeStart(m_cfg.nNodes * m_cfg.nNodes, -1.0),
          m_previous(m_cfg.nNodes * m_cfg.nNodes, false)
    {
    }

    void Start()
    {
        Simulator::Schedule(Seconds(m_cfg.trafficStart),
                            &TopologyTracker::Sample,
                            this);
    }

    void Finalize()
    {
        const double end = m_cfg.trafficStop;
        for (uint32_t i = 0; i < m_cfg.nNodes; ++i)
        {
            for (uint32_t j = i + 1; j < m_cfg.nNodes; ++j)
            {
                const uint32_t index = Index(i, j);
                if (m_previous[index] && m_activeStart[index] >= 0.0)
                {
                    m_linkDurationSum += end - m_activeStart[index];
                    ++m_linkEpisodes;
                    m_activeStart[index] = -1.0;
                }
            }
        }
    }

    double MeanLinkDuration() const
    {
        return (m_linkEpisodes > 0)
                   ? m_linkDurationSum / static_cast<double>(m_linkEpisodes)
                   : 0.0;
    }

    uint64_t TopologyChanges() const { return m_topologyChanges; }

    double TopologyChangeRate() const
    {
        const double measurement = m_cfg.trafficStop - m_cfg.trafficStart;
        return (measurement > 0.0 && m_cfg.nNodes > 0)
                   ? static_cast<double>(m_topologyChanges) /
                         (measurement * static_cast<double>(m_cfg.nNodes))
                   : 0.0;
    }

    double MeanLargestComponentFraction() const
    {
        return (m_samples > 0) ? m_largestComponentFractionSum / m_samples : 0.0;
    }

    double MeanIsolatedNodes() const
    {
        return (m_samples > 0) ? m_isolatedNodesSum / m_samples : 0.0;
    }

    double MeanActiveLinks() const
    {
        return (m_samples > 0) ? m_activeLinksSum / m_samples : 0.0;
    }

    uint64_t Samples() const { return m_samples; }

  private:
    uint32_t Index(uint32_t i, uint32_t j) const
    {
        return i * m_cfg.nNodes + j;
    }

    void Sample()
    {
        const std::vector<Vector> positions = GetPositions(m_nodes);
        std::vector<bool> current(m_cfg.nNodes * m_cfg.nNodes, false);
        std::vector<std::vector<uint32_t>> adjacency(m_cfg.nNodes);
        uint32_t isolated = 0;
        uint32_t activeLinks = 0;
        const double now = Simulator::Now().GetSeconds();

        for (uint32_t i = 0; i < m_cfg.nNodes; ++i)
        {
            for (uint32_t j = i + 1; j < m_cfg.nNodes; ++j)
            {
                const bool active =
                    EstimatedRxPowerDbm(Distance2D(positions[i], positions[j]), m_cfg) >=
                    m_cfg.topologyLinkThresholdDbm;
                current[Index(i, j)] = active;
                current[Index(j, i)] = active;
                if (active)
                {
                    ++activeLinks;
                    adjacency[i].push_back(j);
                    adjacency[j].push_back(i);
                }

                if (m_samples == 0)
                {
                    if (active)
                    {
                        m_activeStart[Index(i, j)] = now;
                    }
                }
                else if (active != m_previous[Index(i, j)])
                {
                    ++m_topologyChanges;
                    if (active)
                    {
                        m_activeStart[Index(i, j)] = now;
                    }
                    else if (m_activeStart[Index(i, j)] >= 0.0)
                    {
                        m_linkDurationSum += now - m_activeStart[Index(i, j)];
                        ++m_linkEpisodes;
                        m_activeStart[Index(i, j)] = -1.0;
                    }
                }
            }
        }

        for (uint32_t i = 0; i < m_cfg.nNodes; ++i)
        {
            if (adjacency[i].empty())
            {
                ++isolated;
            }
        }

        std::vector<bool> visited(m_cfg.nNodes, false);
        uint32_t largest = 0;
        for (uint32_t start = 0; start < m_cfg.nNodes; ++start)
        {
            if (visited[start])
            {
                continue;
            }
            uint32_t componentSize = 0;
            std::queue<uint32_t> queue;
            queue.push(start);
            visited[start] = true;
            while (!queue.empty())
            {
                const uint32_t u = queue.front();
                queue.pop();
                ++componentSize;
                for (uint32_t v : adjacency[u])
                {
                    if (!visited[v])
                    {
                        visited[v] = true;
                        queue.push(v);
                    }
                }
            }
            largest = std::max(largest, componentSize);
        }

        ++m_samples;
        m_largestComponentFractionSum +=
            static_cast<double>(largest) / static_cast<double>(m_cfg.nNodes);
        m_isolatedNodesSum += isolated;
        m_activeLinksSum += activeLinks;
        m_previous = std::move(current);

        const double next = now + m_cfg.updateInterval;
        if (next <= m_cfg.trafficStop + 1e-9)
        {
            Simulator::Schedule(Seconds(m_cfg.updateInterval),
                                &TopologyTracker::Sample,
                                this);
        }
    }

    NodeContainer m_nodes;
    StudyConfig m_cfg;
    std::vector<double> m_activeStart;
    std::vector<bool> m_previous;
    uint64_t m_samples{0};
    uint64_t m_topologyChanges{0};
    uint64_t m_linkEpisodes{0};
    double m_linkDurationSum{0.0};
    double m_largestComponentFractionSum{0.0};
    double m_isolatedNodesSum{0.0};
    double m_activeLinksSum{0.0};
};

void
InstallConstantPositionMobility(const NodeContainer& nodes,
                                const std::vector<Vector>& initialPositions)
{
    Ptr<ListPositionAllocator> allocator = CreateObject<ListPositionAllocator>();
    for (const Vector& p : initialPositions)
    {
        allocator->Add(p);
    }
    MobilityHelper mobility;
    mobility.SetPositionAllocator(allocator);
    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    mobility.Install(nodes);
}

std::set<uint16_t>
InstallTraffic(const NodeContainer& nodes,
               const Ipv4InterfaceContainer& interfaces,
               const StudyConfig& cfg)
{
    std::set<uint16_t> dataPorts;
    const uint64_t rateBps = static_cast<uint64_t>(
        std::llround(cfg.packetRatePps * cfg.packetSizeBytes * 8.0));
    const uint32_t offset = std::max<uint32_t>(1, cfg.nNodes / 2);

    for (uint32_t flow = 0; flow < cfg.nFlows; ++flow)
    {
        const uint32_t source = flow % cfg.nNodes;
        const uint32_t destination = (source + offset) % cfg.nNodes;
        const uint16_t port = static_cast<uint16_t>(9000 + flow);
        dataPorts.insert(port);

        PacketSinkHelper sink("ns3::UdpSocketFactory",
                              InetSocketAddress(Ipv4Address::GetAny(), port));
        ApplicationContainer sinkApp = sink.Install(nodes.Get(destination));
        sinkApp.Start(Seconds(std::max(0.0, cfg.trafficStart - 1.0)));
        sinkApp.Stop(Seconds(cfg.duration));

        OnOffHelper onoff("ns3::UdpSocketFactory",
                          InetSocketAddress(interfaces.GetAddress(destination), port));
        onoff.SetAttribute("DataRate", DataRateValue(DataRate(rateBps)));
        onoff.SetAttribute("PacketSize", UintegerValue(cfg.packetSizeBytes));
        onoff.SetAttribute("OnTime",
                           StringValue("ns3::ConstantRandomVariable[Constant=1]"));
        onoff.SetAttribute("OffTime",
                           StringValue("ns3::ConstantRandomVariable[Constant=0]"));
        ApplicationContainer sourceApp = onoff.Install(nodes.Get(source));
        sourceApp.Start(Seconds(cfg.trafficStart + 0.01 * flow));
        sourceApp.Stop(Seconds(cfg.trafficStop));
    }
    return dataPorts;
}

NetworkMetrics
ExtractFlowMetrics(FlowMonitorHelper& helper,
                   Ptr<FlowMonitor> monitor,
                   const std::set<uint16_t>& dataPorts,
                   const StudyConfig& cfg)
{
    monitor->CheckForLostPackets();
    Ptr<Ipv4FlowClassifier> classifier =
        DynamicCast<Ipv4FlowClassifier>(helper.GetClassifier());
    NS_ABORT_MSG_IF(!classifier, "Unable to obtain IPv4 flow classifier");

    NetworkMetrics metrics;
    Time delaySum = Seconds(0.0);
    Time jitterSum = Seconds(0.0);
    uint64_t jitterSamples = 0;

    for (const auto& [flowId, stats] : monitor->GetFlowStats())
    {
        const Ipv4FlowClassifier::FiveTuple tuple = classifier->FindFlow(flowId);
        if (tuple.protocol != 17 || dataPorts.count(tuple.destinationPort) == 0)
        {
            continue;
        }
        metrics.txPackets += stats.txPackets;
        metrics.rxPackets += stats.rxPackets;
        metrics.txBytes += stats.txBytes;
        metrics.rxBytes += stats.rxBytes;
        delaySum += stats.delaySum;
        jitterSum += stats.jitterSum;
        if (stats.rxPackets > 1)
        {
            jitterSamples += stats.rxPackets - 1;
        }
    }

    if (metrics.txPackets > 0)
    {
        metrics.pdrPercent =
            100.0 * static_cast<double>(metrics.rxPackets) / metrics.txPackets;
        metrics.packetLossPercent =
            100.0 * static_cast<double>(metrics.txPackets - metrics.rxPackets) /
            metrics.txPackets;
    }
    const double measurementDuration = cfg.trafficStop - cfg.trafficStart;
    if (measurementDuration > 0.0)
    {
        metrics.throughputMbps =
            static_cast<double>(metrics.rxBytes) * 8.0 /
            (measurementDuration * 1e6);
    }
    if (metrics.rxPackets > 0)
    {
        metrics.meanDelayMs =
            1000.0 * delaySum.GetSeconds() / static_cast<double>(metrics.rxPackets);
    }
    if (jitterSamples > 0)
    {
        metrics.meanJitterMs =
            1000.0 * jitterSum.GetSeconds() / static_cast<double>(jitterSamples);
    }
    return metrics;
}

void
WriteResult(const StudyConfig& cfg,
            const NetworkMetrics& metrics,
            const TopologyTracker& topology,
            double initialPositionChecksum,
            double trafficChecksum)
{
    const std::filesystem::path outputPath(cfg.outputFile);
    if (outputPath.has_parent_path())
    {
        std::filesystem::create_directories(outputPath.parent_path());
    }
    std::ofstream out(cfg.outputFile, std::ios::out | std::ios::trunc);
    NS_ABORT_MSG_IF(!out.is_open(), "Cannot open output file: " << cfg.outputFile);

    out << "Method,Load,Seed,Run,Nodes,AreaX_m,AreaY_m,Duration_s,TrafficStart_s,"
        << "TrafficStop_s,UpdateInterval_s,MinSpeed_mps,MaxSpeed_mps,Flows,"
        << "PacketRate_pps,PacketSize_bytes,WifiStandard,PhyRate,TxPower_dBm,"
        << "RxNoiseFigure_dB,PropagationModel,PathLossExponent,ReferenceLoss_dB,"
        << "ReferenceDistance_m,TopologyLinkThreshold_dBm,CrowdingDistance_m,"
        << "InitialPositionChecksum,TrafficChecksum,TxPackets,RxPackets,TxBytes,"
        << "RxBytes,PDR_percent,Throughput_Mbps,MeanDelay_ms,MeanJitter_ms,"
        << "PacketLoss_percent,MeanPhySnr_dB,SnrSamples,MeanLinkDuration_s,"
        << "TopologyChanges,TopologyChangesPerNodeSecond,"
        << "MeanLargestComponentFraction,MeanIsolatedNodes,MeanActiveLinks,"
        << "TopologySamples\n";

    const double meanSnr = (g_snr.samples > 0)
                               ? g_snr.sumDb / static_cast<double>(g_snr.samples)
                               : std::numeric_limits<double>::quiet_NaN();

    out << std::setprecision(15)
        << cfg.method << ',' << cfg.load << ',' << cfg.seed << ',' << cfg.run << ','
        << cfg.nNodes << ',' << cfg.areaX << ',' << cfg.areaY << ',' << cfg.duration << ','
        << cfg.trafficStart << ',' << cfg.trafficStop << ',' << cfg.updateInterval << ','
        << cfg.minSpeed << ',' << cfg.maxSpeed << ',' << cfg.nFlows << ','
        << cfg.packetRatePps << ',' << cfg.packetSizeBytes << ','
        << "IEEE802.11g-AdHoc" << ',' << "ErpOfdmRate6Mbps" << ','
        << cfg.txPowerDbm << ',' << cfg.rxNoiseFigureDb << ','
        << "LogDistance" << ',' << cfg.pathLossExponent << ','
        << cfg.referenceLossDb << ',' << cfg.referenceDistanceM << ','
        << cfg.topologyLinkThresholdDbm << ',' << cfg.crowdingDistanceM << ','
        << initialPositionChecksum << ',' << trafficChecksum << ','
        << metrics.txPackets << ',' << metrics.rxPackets << ','
        << metrics.txBytes << ',' << metrics.rxBytes << ','
        << metrics.pdrPercent << ',' << metrics.throughputMbps << ','
        << metrics.meanDelayMs << ',' << metrics.meanJitterMs << ','
        << metrics.packetLossPercent << ',' << meanSnr << ',' << g_snr.samples << ','
        << topology.MeanLinkDuration() << ',' << topology.TopologyChanges() << ','
        << topology.TopologyChangeRate() << ','
        << topology.MeanLargestComponentFraction() << ','
        << topology.MeanIsolatedNodes() << ',' << topology.MeanActiveLinks() << ','
        << topology.Samples() << '\n';
}

void
ApplyLoadDefaults(StudyConfig& cfg)
{
    std::string load = cfg.load;
    std::transform(load.begin(), load.end(), load.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    cfg.load = load;
    if (load == "moderate")
    {
        if (cfg.nFlows == 0)
        {
            cfg.nFlows = 10;
        }
        if (cfg.packetRatePps <= 0.0)
        {
            cfg.packetRatePps = 10.0;
        }
    }
    else if (load == "stress")
    {
        if (cfg.nFlows == 0)
        {
            cfg.nFlows = 20;
        }
        if (cfg.packetRatePps <= 0.0)
        {
            cfg.packetRatePps = 20.0;
        }
    }
    else
    {
        throw std::invalid_argument("load must be moderate or stress");
    }
}

void
ValidateConfig(const StudyConfig& cfg)
{
    static const std::set<std::string> methods{"ARHO", "PSO", "RWP", "GM"};
    NS_ABORT_MSG_IF(methods.count(cfg.method) == 0,
                    "method must be ARHO, PSO, RWP, or GM");
    NS_ABORT_MSG_IF(cfg.seed == 0 || cfg.seed > std::numeric_limits<uint32_t>::max(),
                    "seed must be in [1, 2^32-1]");
    NS_ABORT_MSG_IF(cfg.run == 0, "run must be positive");
    NS_ABORT_MSG_IF(cfg.nNodes < 4, "At least four nodes are required");
    NS_ABORT_MSG_IF(cfg.areaX <= 0.0 || cfg.areaY <= 0.0, "Invalid simulation area");
    NS_ABORT_MSG_IF(cfg.trafficStart < 0.0 || cfg.trafficStop <= cfg.trafficStart ||
                        cfg.duration <= cfg.trafficStop,
                    "Require 0 <= trafficStart < trafficStop < duration");
    NS_ABORT_MSG_IF(cfg.updateInterval <= 0.0, "updateInterval must be positive");
    NS_ABORT_MSG_IF(cfg.minSpeed < 0.0 || cfg.maxSpeed < cfg.minSpeed,
                    "Invalid speed bounds");
    NS_ABORT_MSG_IF(cfg.nFlows == 0 || cfg.packetRatePps <= 0.0,
                    "Traffic configuration is invalid");
}

} // namespace

int
main(int argc, char* argv[])
{
    StudyConfig cfg;
    CommandLine cmd(__FILE__);
    cmd.AddValue("method", "ARHO, PSO, RWP, or GM", cfg.method);
    cmd.AddValue("load", "moderate or stress", cfg.load);
    cmd.AddValue("seed", "Global ns-3 RNG seed", cfg.seed);
    cmd.AddValue("run", "Independent ns-3 run number", cfg.run);
    cmd.AddValue("nNodes", "Number of mobile nodes", cfg.nNodes);
    cmd.AddValue("areaX", "Simulation area width in metres", cfg.areaX);
    cmd.AddValue("areaY", "Simulation area height in metres", cfg.areaY);
    cmd.AddValue("duration", "Simulation duration in seconds", cfg.duration);
    cmd.AddValue("trafficStart", "Traffic start time in seconds", cfg.trafficStart);
    cmd.AddValue("trafficStop", "Traffic stop time in seconds", cfg.trafficStop);
    cmd.AddValue("updateInterval", "Mobility update interval in seconds", cfg.updateInterval);
    cmd.AddValue("minSpeed", "Minimum baseline speed in m/s", cfg.minSpeed);
    cmd.AddValue("maxSpeed", "Maximum speed/displacement cap in m/s", cfg.maxSpeed);
    cmd.AddValue("nFlows", "Override number of UDP flows; zero uses load default", cfg.nFlows);
    cmd.AddValue("packetRatePps",
                 "Override per-flow packet rate; zero uses load default",
                 cfg.packetRatePps);
    cmd.AddValue("packetSizeBytes", "UDP payload size in bytes", cfg.packetSizeBytes);
    cmd.AddValue("txPowerDbm", "Wi-Fi transmit power in dBm", cfg.txPowerDbm);
    cmd.AddValue("rxNoiseFigureDb", "Wi-Fi receiver noise figure in dB", cfg.rxNoiseFigureDb);
    cmd.AddValue("pathLossExponent", "Log-distance path-loss exponent", cfg.pathLossExponent);
    cmd.AddValue("referenceLossDb", "Reference loss at 1 m in dB", cfg.referenceLossDb);
    cmd.AddValue("topologyLinkThresholdDbm",
                 "Rx-power threshold for large-scale topology graph",
                 cfg.topologyLinkThresholdDbm);
    cmd.AddValue("crowdingDistanceM", "Distance defining spatial crowding", cfg.crowdingDistanceM);
    cmd.AddValue("outputFile", "One-row CSV output path", cfg.outputFile);
    cmd.AddValue("enablePcap", "Enable Wi-Fi PCAP traces", cfg.enablePcap);
    cmd.AddValue("verbose", "Enable selected log messages", cfg.verbose);
    cmd.Parse(argc, argv);

    std::transform(cfg.method.begin(), cfg.method.end(), cfg.method.begin(), [](unsigned char c) {
        return static_cast<char>(std::toupper(c));
    });
    ApplyLoadDefaults(cfg);
    ValidateConfig(cfg);

    RngSeedManager::SetSeed(static_cast<uint32_t>(cfg.seed));
    RngSeedManager::SetRun(cfg.run);
    g_snr = SnrAccumulator{};
    g_snr.start = cfg.trafficStart;
    g_snr.stop = cfg.trafficStop;

    if (cfg.verbose)
    {
        LogComponentEnable("ArhoNs3QuantitativeStudy", LOG_LEVEL_INFO);
    }

    NodeContainer nodes;
    nodes.Create(cfg.nNodes);

    const std::vector<Vector> initialPositions = GenerateInitialPositions(cfg);
    const double initialChecksum = PositionChecksum(initialPositions);
    const double trafficPairsChecksum = TrafficChecksum(cfg.nNodes, cfg.nFlows);
    InstallConstantPositionMobility(nodes, initialPositions);
    const std::vector<uint32_t> partners = BuildPartners(cfg.nNodes);

    Config::SetDefault("ns3::WifiPhy::ChannelSettings",
                       StringValue("{0, 20, BAND_2_4GHZ, 0}"));

    YansWifiChannelHelper channel;
    channel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
    channel.AddPropagationLoss("ns3::LogDistancePropagationLossModel",
                               "Exponent",
                               DoubleValue(cfg.pathLossExponent),
                               "ReferenceDistance",
                               DoubleValue(cfg.referenceDistanceM),
                               "ReferenceLoss",
                               DoubleValue(cfg.referenceLossDb));

    YansWifiPhyHelper phy;
    phy.SetChannel(channel.Create());
    phy.Set("TxPowerStart", DoubleValue(cfg.txPowerDbm));
    phy.Set("TxPowerEnd", DoubleValue(cfg.txPowerDbm));
    phy.Set("RxNoiseFigure", DoubleValue(cfg.rxNoiseFigureDb));

    WifiHelper wifi;
    wifi.SetStandard(WIFI_STANDARD_80211g);
    wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                                 "DataMode",
                                 StringValue("ErpOfdmRate6Mbps"),
                                 "ControlMode",
                                 StringValue("ErpOfdmRate6Mbps"));

    WifiMacHelper mac;
    mac.SetType("ns3::AdhocWifiMac");
    NetDeviceContainer devices = wifi.Install(phy, mac, nodes);
    WifiHelper::AssignStreams(devices, 2000);

    AodvHelper aodv;
    InternetStackHelper internet;
    internet.SetRoutingHelper(aodv);
    internet.Install(nodes);

    Ipv4AddressHelper addresses;
    addresses.SetBase("10.1.0.0", "255.255.0.0");
    Ipv4InterfaceContainer interfaces = addresses.Assign(devices);

    const std::set<uint16_t> dataPorts = InstallTraffic(nodes, interfaces, cfg);

    std::unique_ptr<MobilityController> controller;
    if (cfg.method == "ARHO")
    {
        controller = std::make_unique<ArhoController>(nodes, cfg, partners);
    }
    else if (cfg.method == "PSO")
    {
        controller = std::make_unique<PsoController>(nodes, cfg, partners);
    }
    else if (cfg.method == "RWP")
    {
        controller = std::make_unique<RandomWaypointController>(nodes, cfg, partners);
    }
    else
    {
        controller = std::make_unique<GaussMarkovController>(nodes, cfg, partners);
    }
    controller->Start();

    TopologyTracker topology(nodes, cfg);
    topology.Start();

    Config::ConnectWithoutContext(
        "/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/Phy/$ns3::WifiPhy/MonitorSnifferRx",
        MakeCallback(&MonitorSniffRx));

    if (cfg.enablePcap)
    {
        phy.EnablePcap("arho-ns3-" + cfg.method + "-" + cfg.load + "-run" +
                           std::to_string(cfg.run),
                       devices);
    }

    FlowMonitorHelper flowHelper;
    Ptr<FlowMonitor> flowMonitor = flowHelper.InstallAll();

    Simulator::Stop(Seconds(cfg.duration));
    Simulator::Run();

    topology.Finalize();
    const NetworkMetrics metrics =
        ExtractFlowMetrics(flowHelper, flowMonitor, dataPorts, cfg);
    WriteResult(cfg, metrics, topology, initialChecksum, trafficPairsChecksum);

    if (cfg.verbose)
    {
        std::cout << std::fixed << std::setprecision(4)
                  << "PASS method=" << cfg.method << " load=" << cfg.load
                  << " run=" << cfg.run << " PDR=" << metrics.pdrPercent
                  << "% throughput=" << metrics.throughputMbps
                  << "Mbps delay=" << metrics.meanDelayMs << "ms\n";
    }

    Simulator::Destroy();
    return 0;
}
