# Quantitative ns-3 experimental protocol

## Purpose
This experiment evaluates whether full ARHO hotspot-guided mobility changes measurable network outcomes compared with one spatial optimizer (PSO) and two stochastic mobility baselines (Random Waypoint and Gauss-Markov).

## Pairing and replication
The global seed is fixed at 12345 and the ns-3 run number varies from 1 to 30. Within a given traffic load and run number, all four methods receive the same initial node coordinates and the same source-destination flow definitions. This supports paired statistical tests.

## Methods
- **ARHO:** full hotspot archive, occupancy-aware probabilistic selection, broad movement, local verification, sparse leader following, adaptive hotspot management, and occupancy-aware diversification.
- **PSO:** continuous 2-D swarm baseline with inertia decreasing from 0.9 to 0.4 and c1=c2=2.
- **RWP:** transparent Random Waypoint implementation using the same speed cap and area.
- **GM:** transparent Gauss-Markov implementation with alpha=0.85.

All controllers update positions every second and obey the same 1-3 m/s displacement constraint.

## Independent optimization utility
ARHO and PSO optimize a geometry/link-quality utility composed of partner-link score (0.45), mean neighbor-link score (0.35), connectivity ratio (0.20), and crowding penalty (0.15). Packet delivery, throughput, and delay are not included in that utility, so the primary reported outcomes are independent of the optimized criterion.

## Network configuration
See `configuration/SimulationConfiguration.csv`. The main setup is 30 nodes in 500 x 500 m, 120 s duration, IEEE 802.11g ad hoc Wi-Fi at a fixed 6 Mb/s PHY rate, AODV, UDP traffic, LogDistance propagation, and two traffic loads.

## Metrics
Primary: PDR, aggregate throughput, and mean end-to-end delay. Supporting: packet loss, PHY SNR sampled from MonitorSnifferRx, link-duration and topology-change statistics, largest connected-component fraction, and isolated-node count.

The reported PHY metric is **SNR**, not interference-aware SINR. This distinction must be preserved in the manuscript.

## Statistics
For each load and metric: mean, sample SD, median, IQR, and 95% confidence interval. Overall differences use Friedman and Iman-Davenport tests. ARHO is compared with each baseline using paired Wilcoxon signed-rank tests, Holm correction, and rank-biserial effect size.

## Reproducibility outputs
The C++ program creates one CSV per method/load/run. The Python script validates all 240 rows and generates descriptive, ranking, omnibus, pairwise, effect-size, and boxplot outputs.
