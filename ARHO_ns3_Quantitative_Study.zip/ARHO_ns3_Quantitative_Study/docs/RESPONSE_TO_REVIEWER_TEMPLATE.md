# Response template — quantitative ns-3 validation

**Reviewer comment:** Strengthen the ns-3 validation with quantitative and reproducible results.

**Response:** We thank the reviewer and agree that the previous qualitative visualization was insufficient. The ns-3 study has therefore been replaced by a repeated quantitative experiment. Full ARHO mobility was compared with PSO-based spatial mobility, Random Waypoint, and Gauss-Markov mobility under identical initial positions, traffic definitions, simulation duration, radio settings, and random-run protocol. The revised manuscript reports the complete ns-3 configuration, including the simulator version, 30 mobile nodes, 500 m × 500 m area, 120 s duration, mobility limits, IEEE 802.11g ad hoc radio, LogDistance propagation, AODV routing, UDP traffic, and run numbers 1–30.

Packet delivery ratio, aggregate throughput, end-to-end delay, packet loss, PHY SNR, link duration, topology-change rate, connected-component fraction, and isolated-node count were recorded. The results were analyzed using descriptive statistics, Friedman and Iman–Davenport tests, paired Wilcoxon signed-rank tests with Holm correction, and rank-biserial effect sizes. The raw per-run CSV files, configuration table, source code, validation checks, statistical scripts, and plots are included in the reproducibility package. All claims in the manuscript will be limited to the effects supported by these quantitative results.

> Replace the future tense and add the actual numerical findings only after the 240 simulations have completed and passed validation.
