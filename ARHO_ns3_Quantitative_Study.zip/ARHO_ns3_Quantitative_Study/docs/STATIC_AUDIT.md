# Static audit and limitations

- The scenario is written for the current CMake-based ns-3 scratch workflow and pins the study to ns-3.47 APIs.
- Braces, parentheses, and brackets were mechanically checked for balance.
- Every run writes a single configuration-complete CSV row.
- Initial-position and traffic checksums support paired-run validation.
- FlowMonitor filters only the study UDP destination ports.
- PHY SNR is collected during the traffic measurement interval.
- The analysis script includes a synthetic end-to-end self-test.
- ns-3 is not installed in the artifact-generation environment; therefore the C++ scenario was statically reviewed but not compiled or executed here. The included smoke test is mandatory before the full study.
