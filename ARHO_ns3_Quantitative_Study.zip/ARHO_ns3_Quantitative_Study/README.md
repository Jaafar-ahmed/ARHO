# ARHO ns-3 Quantitative Validation Package

A replacement, reproducible ns-3 study created from scratch after the original source was lost. It addresses the reviewer request for full configuration disclosure, quantitative network metrics, relevant baselines, repeated independent runs, and statistical analysis.

## Study design

Methods: Full ARHO, PSO mobility, Random Waypoint, and Gauss-Markov. Loads: moderate and stress. Replications: 30 run numbers per method/load (240 simulations total).

Primary outcomes are PDR, throughput, and end-to-end delay. Additional outcomes are packet loss, PHY SNR, mean link duration, topology-change rate, connected-component fraction, isolated nodes, and active links.

## Requirements

- Linux or WSL2
- ns-3.47 source tree
- C++ compiler, CMake, and Python supported by that ns-3 release
- Python packages listed in `analysis/requirements.txt`

## Setup

```bash
python3 -m pip install -r analysis/requirements.txt
export NS3_ROOT=$HOME/ns-allinone-3.47/ns-3.47
./scripts/check_environment.sh
```

The script copies `src/arho-ns3-study.cc` into the ns-3 `scratch/` directory and builds ns-3.

## Mandatory smoke test

```bash
./scripts/run_smoke_test.sh
```

Do not start the 240-run experiment until all four smoke-test rows are produced and the script prints `PASS`.

## Full experiment

```bash
./scripts/run_all.sh
./scripts/run_analysis.sh
```

The full run is resumable: existing nonempty per-run CSV files are skipped.

Or execute the complete sequence:

```bash
./scripts/run_complete_study.sh
```

## Main outputs

`results/analysis/` will contain:

- `RawNetworkResults.csv`
- `ValidationChecks.csv`
- `SummaryNetworkResults.csv`
- `FriedmanImanDavenport.csv`
- `MethodAverageRanks.csv`
- `WilcoxonHolmEffectSizes.csv`
- `WinTieLossAcrossMetrics.csv`
- metric boxplots

## Analysis self-test without ns-3

```bash
python3 analysis/self_test.py
```

## Scientific cautions

- The package reports PHY **SNR**, not SINR.
- ARHO and PSO optimize a geometry/link-quality utility that excludes PDR, throughput, and delay.
- Do not claim superiority until `ValidationChecks.csv` passes and the statistical outputs support the claim.
- Keep Full ARHO unchanged; this is a network-domain mapping, not a post-hoc benchmark modification.
