#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/common.sh" "${1:-}"

OUT="${PACKAGE_ROOT}/results/smoke"
rm -rf "${OUT}"
mkdir -p "${OUT}"
cd "${NS3_ROOT}"

for method in ARHO PSO RWP GM; do
  output="${OUT}/${method}_moderate_run01.csv"
  ./ns3 run "scratch/${SCENARIO_NAME} --method=${method} --load=moderate --seed=12345 --run=1 --nNodes=12 --duration=25 --trafficStart=5 --trafficStop=22 --nFlows=4 --packetRatePps=5 --outputFile=${output} --verbose=1"
  test -s "${output}"
done

python3 - "${OUT}" <<'PY'
import sys
from pathlib import Path
import pandas as pd
root=Path(sys.argv[1])
files=sorted(root.glob('*.csv'))
assert len(files)==4, f'expected 4 files, found {len(files)}'
df=pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
assert set(df.Method)=={'ARHO','PSO','RWP','GM'}
assert (df.TxPackets>0).all()
assert df.InitialPositionChecksum.max()-df.InitialPositionChecksum.min() <= 1e-9
assert df.TrafficChecksum.max()-df.TrafficChecksum.min() <= 1e-9
print(df[['Method','PDR_percent','Throughput_Mbps','MeanDelay_ms','MeanPhySnr_dB']].to_string(index=False))
print('PASS: unified ns-3 smoke test completed.')
PY
