#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/common.sh" "${1:-}"

OUT="${PACKAGE_ROOT}/results/raw"
mkdir -p "${OUT}"
cd "${NS3_ROOT}"

methods=(ARHO PSO RWP GM)
loads=(moderate stress)
seed=12345

for load in "${loads[@]}"; do
  mkdir -p "${OUT}/${load}"
  for run in $(seq 1 30); do
    for method in "${methods[@]}"; do
      output="${OUT}/${load}/${method}_${load}_run$(printf '%02d' "${run}").csv"
      if [[ -s "${output}" ]]; then
        echo "SKIP ${method} ${load} run ${run}: output already exists"
        continue
      fi
      echo "RUN  ${method} ${load} run ${run}/30"
      ./ns3 run "scratch/${SCENARIO_NAME} --method=${method} --load=${load} --seed=${seed} --run=${run} --outputFile=${output}"
      test -s "${output}"
    done
  done
done

echo "PASS: 240 simulation outputs are available under ${OUT}"
