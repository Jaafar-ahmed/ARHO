#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
NS3_ARG="${1:-}"
"${SCRIPT_DIR}/check_environment.sh" "${NS3_ARG}"
"${SCRIPT_DIR}/run_smoke_test.sh" "${NS3_ARG}"
"${SCRIPT_DIR}/run_all.sh" "${NS3_ARG}"
"${SCRIPT_DIR}/run_analysis.sh"
