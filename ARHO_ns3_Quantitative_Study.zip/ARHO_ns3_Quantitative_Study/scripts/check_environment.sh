#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/common.sh" "${1:-}"

echo "Package root : ${PACKAGE_ROOT}"
echo "ns-3 root    : ${NS3_ROOT}"
echo "ns-3 VERSION : ${NS3_VERSION}"
echo "Python       : $(python3 --version 2>&1)"
echo "CMake        : $(cmake --version | head -1)"
echo "C++ compiler : $(c++ --version | head -1)"

cd "${NS3_ROOT}"
./ns3 configure --enable-examples
./ns3 build

echo "PASS: ns-3 configured and scenario copied to scratch/${SCENARIO_NAME}.cc"
