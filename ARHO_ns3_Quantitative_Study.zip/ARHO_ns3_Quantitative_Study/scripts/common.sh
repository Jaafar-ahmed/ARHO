#!/usr/bin/env bash
set -euo pipefail

PACKAGE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NS3_ROOT="${NS3_ROOT:-${1:-}}"

if [[ -z "${NS3_ROOT}" ]]; then
  echo "ERROR: set NS3_ROOT or pass the ns-3 root directory as the first argument." >&2
  echo "Example: NS3_ROOT=~/ns-allinone-3.47/ns-3.47 $0" >&2
  exit 2
fi
NS3_ROOT="$(cd "${NS3_ROOT}" && pwd)"
if [[ ! -x "${NS3_ROOT}/ns3" ]]; then
  echo "ERROR: ${NS3_ROOT}/ns3 was not found or is not executable." >&2
  exit 2
fi

SCENARIO_NAME="arho-ns3-study"
SCENARIO_SRC="${PACKAGE_ROOT}/src/${SCENARIO_NAME}.cc"
SCENARIO_DST="${NS3_ROOT}/scratch/${SCENARIO_NAME}.cc"
mkdir -p "${NS3_ROOT}/scratch"
cp "${SCENARIO_SRC}" "${SCENARIO_DST}"

NS3_VERSION="unknown"
if [[ -f "${NS3_ROOT}/VERSION" ]]; then
  NS3_VERSION="$(tr -d '[:space:]' < "${NS3_ROOT}/VERSION")"
fi
export PACKAGE_ROOT NS3_ROOT SCENARIO_NAME NS3_VERSION
