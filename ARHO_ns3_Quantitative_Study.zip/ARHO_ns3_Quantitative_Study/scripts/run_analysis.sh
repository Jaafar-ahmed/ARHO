#!/usr/bin/env bash
set -euo pipefail
PACKAGE_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 "${PACKAGE_ROOT}/analysis/analyze_results.py" \
  --raw-dir "${PACKAGE_ROOT}/results/raw" \
  --output-dir "${PACKAGE_ROOT}/results/analysis" \
  --expected-runs 30
