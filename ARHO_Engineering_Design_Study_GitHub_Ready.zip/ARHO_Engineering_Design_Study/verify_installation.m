clc;
clear;

projectRoot=setup_project();

checks={ ...
    'ARHO',fullfile(projectRoot,'algorithms'); ...
    'pressure_vessel_problem',fullfile(projectRoot,'problems'); ...
    'welded_beam_problem',fullfile(projectRoot,'problems'); ...
    'cantilever_beam_problem',fullfile(projectRoot,'problems'); ...
    'tension_compression_spring_problem',fullfile(projectRoot,'problems'); ...
    'rolling_element_bearing_problem',fullfile(projectRoot,'problems'); ...
    'multi_plate_clutch_brake_problem',fullfile(projectRoot,'problems'); ...
    'step_cone_pulley_problem',fullfile(projectRoot,'problems'); ...
    'speed_reducer_problem',fullfile(projectRoot,'problems'); ...
    'run_engineering_problem',fullfile(projectRoot,'experiments')};

for i=1:size(checks,1)
    functionName=checks{i,1};
    expectedFolder=checks{i,2};
    resolved=which(functionName);

    fprintf('%-40s -> %s\n',functionName,resolved);

    assert(~isempty(resolved), ...
        'Required function %s was not found.',functionName);

    assert(same_folder(fileparts(resolved),expectedFolder), ...
        'Function %s is being loaded from an unexpected folder.', ...
        functionName);
end

fprintf('\nPASS: the clean engineering repository is active.\n');

function same=same_folder(folderA,folderB)
    same=strcmpi(canonical_path(folderA),canonical_path(folderB));
end

function value=canonical_path(value)
    try
        value=char(java.io.File(value).getCanonicalPath());
    catch
        value=char(value);
    end
    value=strrep(value,'/','\');
    while numel(value)>3 && value(end)=='\'
        value(end)=[];
    end
end
