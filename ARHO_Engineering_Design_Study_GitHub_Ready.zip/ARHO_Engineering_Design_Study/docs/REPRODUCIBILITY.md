# Reproducibility protocol

The engineering study uses the same ARHO implementation as the benchmark
study.

## Common settings

- Population size: 30
- Independent runs: 30
- Seeds: 1–30
- Function-evaluation budget: 30,000
- Feasibility tolerance: \(10^{-6}\)
- Function-evaluation-based parameter scheduling
- Feasibility-first solution comparison

For each run, the reported raw objective and every constraint are
recomputed independently from the full-precision decoded design variables.

## Variable formulations

- Tension/compression spring: continuous relaxation
- Pressure vessel: mixed-discrete thickness variables
- Welded beam: continuous
- Multi-plate clutch brake: discrete
- Step-cone pulley: continuous with 1-mm equality tolerance
- Cantilever beam: continuous
- Speed reducer: mixed-integer
- Rolling-element bearing: mixed-integer maximization

## Resume behavior

Each run is saved separately. Re-running an individual or complete script
loads completed runs and continues only the missing runs.

## Results

Each problem folder contains:

- `AllRuns_FullPrecision.csv`
- `SummaryStatistics.csv`
- `BestFeasibleSolution.csv`
- `ConstraintValuesAndMargins.csv`
- `ValidationChecks.csv`
- `RandomSeeds.txt`
- `ExperimentConfiguration.txt`
- `CompleteExperiment.mat`
- convergence and constraint-violation figures
