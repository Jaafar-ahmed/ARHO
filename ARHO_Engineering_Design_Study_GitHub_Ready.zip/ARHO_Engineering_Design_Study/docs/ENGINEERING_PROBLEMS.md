# Engineering problems

The repository contains eight constrained design problems.

| Key | Problem | Direction | Variable type |
|---|---|---|---|
| `tension_compression_spring` | Tension/compression spring | Minimize | Continuous relaxation |
| `pressure_vessel` | Pressure vessel | Minimize | Mixed-discrete |
| `welded_beam` | Welded beam | Minimize | Continuous |
| `multi_plate_clutch_brake` | Multi-plate disc clutch brake | Minimize | Discrete |
| `step_cone_pulley` | Step-cone pulley | Minimize | Continuous with equality tolerance |
| `cantilever_beam` | Cantilever beam | Minimize | Continuous |
| `speed_reducer` | Speed reducer | Minimize | Mixed-integer |
| `rolling_element_bearing` | Rolling-element bearing | Maximize | Mixed-integer |

All inequality constraints are implemented in the form \(g_i(x)\leq0\).
For the step-cone pulley, the three belt-length equalities are represented
with an absolute tolerance of 1 mm.
