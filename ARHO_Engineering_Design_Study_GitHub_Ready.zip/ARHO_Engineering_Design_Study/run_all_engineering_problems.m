clc;
clear;
close all;

setup_project();

config=default_engineering_config();
keys=engineering_problem_keys();

allSummaries=table();
allValidations=table();

for i=1:numel(keys)
    fprintf('\n==================================================\n');
    fprintf('Starting: %s\n',keys{i});
    fprintf('==================================================\n');

    output=run_engineering_problem(keys{i},config);
    allSummaries=[allSummaries;output.summary]; %#ok<AGROW>
    allValidations=[allValidations;output.validation]; %#ok<AGROW>
end

writetable(allSummaries, ...
    fullfile(config.outputRoot,'AllProblems_Summary.csv'));
writetable(allValidations, ...
    fullfile(config.outputRoot,'AllProblems_Validation.csv'));

disp(allSummaries);
disp(allValidations);
