clc;
clear;
close all;

setup_project();

config=default_engineering_config();
output=run_engineering_problem('rolling_element_bearing',config);

disp(output.summary);
disp(output.bestRow);
disp(output.validation);
