# ARHO Engineering Design Study

This repository contains the MATLAB implementation and reproducibility
workflow for eight constrained engineering-design applications of the
**Anticipatory Raven Hotspot Optimizer (ARHO)**.

## Included problems

1. Tension/compression spring
2. Pressure vessel
3. Welded beam
4. Multi-plate disc clutch brake
5. Step-cone pulley
6. Cantilever beam
7. Speed reducer
8. Rolling-element bearing

The collection includes continuous, discrete, mixed-discrete, and
mixed-integer formulations, as well as minimization and maximization
problems.

## Quick start

Open MATLAB in the repository root and run:

```matlab
verify_installation
run_smoke_test
verify_reference_solutions
```

To run an individual problem:

```matlab
run_pressure_vessel
run_welded_beam
run_cantilever_beam
run_tension_compression_spring
run_multi_plate_clutch_brake
run_step_cone_pulley
run_speed_reducer
run_rolling_element_bearing
```

To reproduce the complete engineering study:

```matlab
run_all_engineering_problems
```

## Experimental protocol

- Population size: 30
- Independent runs: 30
- Seeds: 1–30
- Objective-function evaluations: 30,000 per run
- Feasibility tolerance: \(10^{-6}\)

Every reported raw objective and constraint vector is independently
recomputed from the full-precision design variables.

## Resume support

Each run is stored separately. If MATLAB or the computer stops, rerunning
the same script loads completed runs and continues the missing runs.

## Repository structure

```text
algorithms/          ARHO implementation
problems/            Engineering formulations
verification/        Independent objective and constraint checks
experiments/         Configuration, runner, summary, and export functions
reference_results/   Verified full-precision results
docs/                Formulation and reproducibility notes
results/             Generated outputs
```

## Reference results

The `reference_results` folder includes the verified best designs and
30-run statistics used in the manuscript revision. Runtime values depend
on the computer and MATLAB environment.

Please cite the associated ARHO paper when using this repository.
