function problem = pressure_vessel_problem()
%PRESSURE_VESSEL_PROBLEM Standard mixed-discrete pressure-vessel problem.
%
% Search vector: [z1,z2,R,L]
% Decoded vector: [Ts,Th,R,L]
% Ts = 0.0625*z1 and Th = 0.0625*z2.

    problem.name = 'Pressure Vessel Design';
    problem.sense = 'minimize';
    problem.dim = 4;
    problem.lb = [1, 1, 10, 10];
    problem.ub = [99, 99, 200, 200];
    problem.integerIndices = [1,2];
    problem.decodedVariableNames = {'Ts','Th','R','L'};
    problem.constraintNames = {'g1_shell','g2_head','g3_volume','g4_length'};
    problem.formulation = ['Mixed-discrete: Ts and Th are multiples ', ...
                           'of 0.0625; R and L are continuous.'];
    problem.evaluate = @evaluate_candidate;
    problem.verify = @(x,tol,verbose) ...
        verify_pressure_vessel(x,tol,verbose);
end

function rec = evaluate_candidate(y, tol)
    y = ARHO_BoundaryControl(y, [1,1,10,10], ...
                                [99,99,200,200], [1,2]);

    z1 = y(1);
    z2 = y(2);
    R = y(3);
    L = y(4);

    Ts = 0.0625*z1;
    Th = 0.0625*z2;
    decoded = [Ts,Th,R,L];

    raw = 0.6224*Ts*R*L ...
        + 1.7781*Th*R^2 ...
        + 3.1661*Ts^2*L ...
        + 19.84*Ts^2*R;

    g = [ ...
        0.0193*R - Ts, ...
        0.00954*R - Th, ...
        1296000 - pi*R^2*L - (4/3)*pi*R^3, ...
        L - 240];

    rec = make_record(y, decoded, raw, raw, g, tol);
end

function rec = make_record(searchX, decodedX, raw, merit, g, tol)
    violation = max(0,g);
    rec.searchX = searchX;
    rec.decodedX = decodedX;
    rec.raw = raw;
    rec.merit = merit;
    rec.g = g;
    rec.margins = -g;
    rec.vsum = sum(violation);
    rec.vmax = max(violation);
    rec.feasible = rec.vmax <= tol;
end
