function problem = rolling_element_bearing_problem()
%BEARING_PROBLEM Mixed-integer rolling-element-bearing optimization.
%
% Decoded variables:
% [Dm,Db,Z,fi,fo,KDmin,KDmax,epsilon,e,zeta]
%
% The original objective is the dynamic load capacity and is maximized.
% ARHO internally minimizes merit=-capacity. Z is an integer.

    problem.name = 'Rolling Element Bearing Design';
    problem.sense = 'maximize';
    problem.dim = 10;

    D=160;
    d=90;

    problem.lb = [ ...
        0.5*(D+d), ...
        0.15*(D-d), ...
        4, ...
        0.515,0.515, ...
        0.4,0.6, ...
        0.3,0.02,0.6];

    problem.ub = [ ...
        0.6*(D+d), ...
        0.45*(D-d), ...
        50, ...
        0.6,0.6, ...
        0.5,0.7, ...
        0.4,0.1,0.85];

    problem.integerIndices = 3;
    problem.decodedVariableNames = { ...
        'Dm','Db','Z','fi','fo','KDmin','KDmax', ...
        'epsilon','e','zeta'};

    problem.constraintNames = { ...
        'g1_assembly','g2_width','g3_Db_min','g4_Db_max', ...
        'g5_pitch_upper','g6_pitch_lower','g7_ring_strength', ...
        'g8_fo_lower','g9_fi_lower'};

    problem.formulation = ['Mixed-integer: Z is integer; ', ...
        'dynamic load capacity is maximized. D=160 mm, d=90 mm, ', ...
        'bearing width Bw=30 mm, and contact angle alpha=0.'];

    problem.evaluate = @evaluate_candidate;
    problem.verify = @(x,tol,verbose) ...
        verify_rolling_element_bearing(x,tol,verbose);
end

function rec = evaluate_candidate(x,tol)
    D=160;
    d=90;
    Bw=30;
    alpha=0;

    lb=[125,10.5,4,0.515,0.515,0.4,0.6,0.3,0.02,0.6];
    ub=[150,31.5,50,0.6,0.6,0.5,0.7,0.4,0.1,0.85];

    x=ARHO_BoundaryControl(x,lb,ub,3);

    Dm=x(1);Db=x(2);Z=x(3);fi=x(4);fo=x(5);
    KDmin=x(6);KDmax=x(7);epsilon=x(8);e=x(9);zeta=x(10);

    gamma=Db*cos(alpha)/Dm;

    ratioTerm=(fi*(2*fo-1))/(fo*(2*fi-1));
    fc=37.91 ...
      *(1+(1.04*((1-gamma)/(1+gamma))^1.72 ...
      *ratioTerm^0.41)^(10/3))^(-0.3) ...
      *(gamma^0.3*(1-gamma)^1.39/(1+gamma)^(1/3)) ...
      *(2*fi/(2*fi-1))^0.41;

    if Db<=25.4
        capacity=fc*Z^(2/3)*Db^1.8;
    else
        capacity=3.647*fc*Z^(2/3)*Db^1.4;
    end

    T=D-d-2*Db;
    A=(D-d)/2-3*T/4;
    B=D/2-T/4-Db;
    C=d/2+T/4;
    acosArgument=(A^2+B^2-C^2)/(2*A*B);
    acosArgument=min(1,max(-1,acosArgument));
    phi0=2*pi-2*acos(acosArgument);

    g=[ ...
        Z-phi0/(2*asin(Db/Dm))-1, ...
        Db-zeta*Bw, ...
        KDmin*(D-d)-2*Db, ...
        2*Db-KDmax*(D-d), ...
        Dm-(0.5+e)*(D+d), ...
        0.5*(D+d)-Dm, ...
        epsilon*Db-0.5*(D-Dm-Db), ...
        0.515-fo, ...
        0.515-fi];

    v=max(0,g);
    rec.searchX=x;
    rec.decodedX=x;
    rec.raw=capacity;
    rec.merit=-capacity;
    rec.g=g;
    rec.margins=-g;
    rec.vsum=sum(v);
    rec.vmax=max(v);
    rec.feasible=rec.vmax<=tol;
    rec.details=struct('fc',fc,'gamma',gamma,'phi0',phi0);
end
