function problem = multi_plate_clutch_brake_problem()
%MULTI_PLATE_CLUTCH_PROBLEM Multiple-disc clutch-brake mass minimization.
%
% Search variables:
%   y = [ri, ro, tIndex, F, Z]
%
% Decoded engineering variables:
%   ri : inner radius (mm), integer
%   ro : outer radius (mm), integer
%   t  : disc thickness selected from [1,1.5,2,2.5,3] mm
%   F  : actuating force (N), integer
%   Z  : number of friction surfaces, integer
%
% The benchmark variant used here adopts mu = 0.6 and the eight standard
% nonlinear constraints. All constraints are returned in g <= 0 form.

    problem.name = 'Multi-Plate Disc Clutch Brake';
    problem.sense = 'minimize';
    problem.dim = 5;

    % y(3) is an index into the discrete thickness set.
    problem.lb = [60, 90, 1, 0, 2];
    problem.ub = [80, 110, 5, 1000, 9];
    problem.integerIndices = 1:5;

    problem.decodedVariableNames = {'ri','ro','t','F','Z'};
    problem.constraintNames = { ...
        'g1_radial_width', ...
        'g2_axial_length', ...
        'g3_pressure', ...
        'g4_pressure_velocity', ...
        'g5_sliding_velocity', ...
        'g6_stopping_time', ...
        'g7_torque_capacity', ...
        'g8_nonnegative_time'};

    problem.formulation = [ ...
        'Discrete benchmark formulation: ri, ro, F, and Z are integers; ', ...
        't is selected from {1,1.5,2,2.5,3} mm; mu=0.6.'];

    problem.evaluate = @evaluate_candidate;
    problem.verify = @(x,tol,verbose) ...
        verify_multi_plate_clutch_brake(x,tol,verbose);
end

function rec = evaluate_candidate(y, tol)

    lb = [60, 90, 1, 0, 2];
    ub = [80, 110, 5, 1000, 9];

    y = ARHO_BoundaryControl(y, lb, ub, 1:5);

    thicknessSet = [1, 1.5, 2, 2.5, 3];

    ri = y(1);
    ro = y(2);
    t  = thicknessSet(y(3));
    F  = y(4);
    Z  = y(5);

    decoded = [ri, ro, t, F, Z];

    [raw, g, details] = clutch_equations(decoded);

    v = max(0, g);

    rec.searchX = y;
    rec.decodedX = decoded;
    rec.raw = raw;
    rec.merit = raw;
    rec.g = g;
    rec.margins = -g;
    rec.vsum = sum(v);
    rec.vmax = max(v);
    rec.feasible = rec.vmax <= tol;
    rec.details = details;
end

function [raw, g, details] = clutch_equations(x)

    ri = x(1);
    ro = x(2);
    t  = x(3);
    F  = x(4);
    Z  = x(5);

    % Benchmark constants.
    deltaR = 20;          % mm
    Lmax = 30;            % mm
    mu = 0.6;
    pmax = 1;             % N/mm^2
    rho = 7.8e-6;         % kg/mm^3
    vsrMax = 10;          % m/s
    safety = 1.5;
    Tmax = 15;            % s
    n = 250;              % rpm
    Ms = 40;              % N.m
    Mf = 3;               % N.m
    Iz = 55;              % kg.m^2
    delta = 0.5;          % mm

    annulus = ro^2 - ri^2;

    if annulus <= 0
        raw = realmax('double')/100;
        g = realmax('double')/100 * ones(1,8);
        details = struct();
        return;
    end

    % Original raw mass objective.
    raw = pi * annulus * t * (Z + 1) * rho;

    area = pi * annulus;
    pressure = F / area;

    effectiveRadius = (2/3) * (ro^3 - ri^3) / annulus;  % mm
    slidingVelocity = pi * effectiveRadius * n / 30 / 1000; % m/s

    torqueNmm = (2/3) * mu * F * Z ...
              * (ro^3 - ri^3) / annulus;
    torqueNm = torqueNmm / 1000;

    omega = pi * n / 30;
    stoppingTime = Iz * omega / max(torqueNm + Mf, eps);

    % All constraints are feasible when g <= 0.
    g = [ ...
        deltaR - (ro - ri), ...
        (Z + 1) * (t + delta) - Lmax, ...
        pressure - pmax, ...
        pressure * slidingVelocity - pmax * vsrMax, ...
        slidingVelocity - vsrMax, ...
        stoppingTime - Tmax, ...
        safety * Ms - torqueNm, ...
        -stoppingTime];

    details = struct( ...
        'area', area, ...
        'pressure', pressure, ...
        'effectiveRadius', effectiveRadius, ...
        'slidingVelocity', slidingVelocity, ...
        'torqueNm', torqueNm, ...
        'stoppingTime', stoppingTime);
end
