function problem = cantilever_beam_problem()
%CANTILEVER_PROBLEM Standard five-segment cantilever design.
%
% Objective: 0.0624*sum(x)
% Constraint: 61/x1^3 + 37/x2^3 + 19/x3^3 + 7/x4^3
%             + 1/x5^3 - 1 <= 0.

    problem.name = 'Cantilever Beam Design';
    problem.sense = 'minimize';
    problem.dim = 5;
    problem.lb = 0.01*ones(1,5);
    problem.ub = 100*ones(1,5);
    problem.integerIndices = [];
    problem.decodedVariableNames = {'x1','x2','x3','x4','x5'};
    problem.constraintNames = {'g1_displacement'};
    problem.formulation = 'Continuous standard cantilever formulation.';
    problem.evaluate = @evaluate_candidate;
    problem.verify = @(x,tol,verbose) ...
        verify_cantilever_beam(x,tol,verbose);
end

function rec = evaluate_candidate(x,tol)
    x=ARHO_BoundaryControl(x,0.01*ones(1,5), ...
                              100*ones(1,5),[]);
    raw=0.0624*sum(x);
    g=61/x(1)^3+37/x(2)^3+19/x(3)^3 ...
     +7/x(4)^3+1/x(5)^3-1;

    v=max(0,g);
    rec.searchX=x;
    rec.decodedX=x;
    rec.raw=raw;
    rec.merit=raw;
    rec.g=g;
    rec.margins=-g;
    rec.vsum=sum(v);
    rec.vmax=max(v);
    rec.feasible=rec.vmax<=tol;
end
