function problem = tension_compression_spring_problem()
%SPRING_PROBLEM Standard continuous tension/compression spring problem.
%
% Variables: [d,D,N]. This benchmark formulation treats N as continuous.
% This modeling choice is stated explicitly for reproducibility.

    problem.name = 'Tension-Compression Spring Design';
    problem.sense = 'minimize';
    problem.dim = 3;
    problem.lb = [0.05,0.25,2];
    problem.ub = [2.0,1.30,15];
    problem.integerIndices = [];
    problem.decodedVariableNames = {'d','D','N'};
    problem.constraintNames = {'g1_shear','g2_surge', ...
        'g3_deflection','g4_diameter'};
    problem.formulation = ['Continuous benchmark relaxation: ', ...
                           'd, D, and N are continuous.'];
    problem.evaluate = @evaluate_candidate;
    problem.verify = @(x,tol,verbose) ...
        verify_tension_compression_spring(x,tol,verbose);
end

function rec = evaluate_candidate(x,tol)
    x=ARHO_BoundaryControl(x,[0.05,0.25,2], ...
                              [2,1.3,15],[]);
    d=x(1); D=x(2); N=x(3);

    raw=(N+2)*D*d^2;

    denominator=12566*(D*d^3-d^4);
    if abs(denominator)<eps
        denominator=sign(denominator+eps)*eps;
    end

    g=[ ...
        1-D^3*N/(71785*d^4), ...
        (4*D^2-d*D)/denominator+1/(5108*d^2)-1, ...
        1-140.45*d/(D^2*N), ...
        (d+D)/1.5-1];

    v=max(0,g);
    rec.searchX=x;
    rec.decodedX=x;
    rec.raw=raw;
    rec.merit=raw;
    rec.g=g;
    rec.margins=-g;
    rec.vsum=sum(v);
    rec.vmax=max(v);
    rec.feasible=rec.vmax<=tol;
end
