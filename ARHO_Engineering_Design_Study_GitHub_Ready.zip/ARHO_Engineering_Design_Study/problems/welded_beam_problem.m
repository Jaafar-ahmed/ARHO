function problem = welded_beam_problem()
%WELDED_BEAM_PROBLEM Welded-beam cost minimization.
%
% Variables: [h,l,t,b]
% Constraints used here are the five structural constraints:
% shear stress, normal stress, buckling load, deflection, and h<=b.

    problem.name = 'Welded Beam Design';
    problem.sense = 'minimize';
    problem.dim = 4;
    problem.lb = [0.1, 0.1, 0.1, 0.1];
    problem.ub = [2.0, 10.0, 10.0, 2.0];
    problem.integerIndices = [];
    problem.decodedVariableNames = {'h','l','t','b'};
    problem.constraintNames = {'g1_shear','g2_normal', ...
        'g3_buckling','g4_deflection','g5_geometry'};
    problem.formulation = ['Continuous five-constraint welded-beam ', ...
                           'formulation.'];
    problem.evaluate = @evaluate_candidate;
    problem.verify = @(x,tol,verbose) ...
        verify_welded_beam(x,tol,verbose);
end

function rec = evaluate_candidate(x, tol)
    x = ARHO_BoundaryControl(x, ...
        [0.1,0.1,0.1,0.1], [2,10,10,2], []);

    [raw,g,details] = welded_equations(x);

    v = max(0,g);
    rec.searchX = x;
    rec.decodedX = x;
    rec.raw = raw;
    rec.merit = raw;
    rec.g = g;
    rec.margins = -g;
    rec.vsum = sum(v);
    rec.vmax = max(v);
    rec.feasible = rec.vmax <= tol;
    rec.details = details;
end

function [raw,g,d] = welded_equations(x)
    h=x(1); l=x(2); t=x(3); b=x(4);

    P=6000;
    L=14;
    E=30e6;
    G=12e6;
    tauMax=13600;
    sigmaMax=30000;
    deltaMax=0.25;

    raw = 1.10471*h^2*l + 0.04811*t*b*(14+l);

    tau1 = P/(sqrt(2)*h*l);
    M = P*(L+l/2);
    R = sqrt(l^2/4 + ((h+t)/2)^2);
    J = 2*sqrt(2)*h*l*(l^2/12 + ((h+t)/2)^2);
    tau2 = M*R/J;
    tau = sqrt(tau1^2 + 2*tau1*tau2*l/(2*R) + tau2^2);

    sigma = 6*P*L/(b*t^2);
    delta = 4*P*L^3/(E*t^3*b);

    Pc = (4.013*E/(L^2)) ...
       * sqrt(t^2*b^6/36) ...
       * (1 - t/(2*L)*sqrt(E/(4*G)));

    g = [ ...
        tau - tauMax, ...
        sigma - sigmaMax, ...
        P - Pc, ...
        delta - deltaMax, ...
        h - b];

    d.tau=tau;
    d.sigma=sigma;
    d.Pc=Pc;
    d.delta=delta;
end
