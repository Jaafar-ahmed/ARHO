function problem = step_cone_pulley_problem()
%STEP_CONE_PULLEY_PROBLEM Four-step cone-pulley weight minimization.
%
% Variables:
%   x = [d1,d2,d3,d4,w] in mm.
%
% The model uses:
%   input speed N = 350 rpm,
%   output speeds [750,450,250,150] rpm,
%   density 7200 kg/m^3,
%   center distance 3 m,
%   belt coefficient of friction 0.35,
%   allowable stress 1.75 MPa,
%   belt thickness 8 mm,
%   minimum transmitted power 0.75 hp.
%
% Three belt-length equalities are represented by
%   abs(C1-Ci) <= 1 mm,
% matching the equality tolerance commonly used with the benchmark results.

    problem.name = 'Step-Cone Pulley Design';
    problem.sense = 'minimize';
    problem.dim = 5;

    % Standard benchmark bounds used by the literature solutions.
    problem.lb = [40,40,40,40,10];
    problem.ub = [100,100,100,100,100];
    problem.integerIndices = [];

    problem.decodedVariableNames = {'d1','d2','d3','d4','w'};
    problem.constraintNames = { ...
        'g1_tension_ratio_1', ...
        'g2_tension_ratio_2', ...
        'g3_tension_ratio_3', ...
        'g4_tension_ratio_4', ...
        'g5_power_1', ...
        'g6_power_2', ...
        'g7_power_3', ...
        'g8_power_4', ...
        'g9_belt_length_12', ...
        'g10_belt_length_13', ...
        'g11_belt_length_14'};

    problem.formulation = [ ...
        'Continuous five-variable formulation. Three equality constraints ', ...
        'are verified with a 1 mm absolute belt-length tolerance.'];

    problem.evaluate = @evaluate_candidate;
    problem.verify = @(x,tol,verbose) ...
        verify_step_cone_pulley(x,tol,verbose);
end

function rec = evaluate_candidate(x,tol)

    lb=[40,40,40,40,10];
    ub=[100,100,100,100,100];

    x=ARHO_BoundaryControl(x,lb,ub,[]);

    [raw,g,details]=pulley_equations(x);

    v=max(0,g);

    rec.searchX=x;
    rec.decodedX=x;
    rec.raw=raw;
    rec.merit=raw;
    rec.g=g;
    rec.margins=-g;
    rec.vsum=sum(v);
    rec.vmax=max(v);
    rec.feasible=rec.vmax<=tol;
    rec.details=details;
end

function [raw,g,details]=pulley_equations(x)

    d=x(1:4);
    w=x(5);

    rho=7200;                    % kg/m^3
    N=350;                       % input rpm
    Ni=[750,450,250,150];        % output rpm
    a=3000;                      % mm (3 m)
    mu=0.35;
    stress=1.75;                 % N/mm^2
    beltThickness=8;             % mm
    requiredPower=0.75*745.6998; % W
    equalityTolerance=1.0;       % mm

    ratio=Ni/N;

    % Raw mass in kg; pi/4 is required by the circular cross section.
    raw=rho*(w/1000)*(pi/4)*sum( ...
        (d/1000).^2 .* (1+ratio.^2));

    beltLength=(pi*d/2).*(1+ratio) ...
        + ((ratio-1).^2 .* d.^2)/(4*a) ...
        + 2*a;

    asinArgument=(ratio-1).*d/(2*a);
    asinArgument=min(1,max(-1,asinArgument));

    theta=pi-2*asin(asinArgument);
    tensionRatio=exp(mu*theta);

    tightSideTension=stress*beltThickness*w; % N
    transmittedPower=tightSideTension ...
        .* (1-exp(-mu*theta)) ...
        .* pi .* d .* Ni / (60*1000); % W

    g=[ ...
        2-tensionRatio(1), ...
        2-tensionRatio(2), ...
        2-tensionRatio(3), ...
        2-tensionRatio(4), ...
        requiredPower-transmittedPower(1), ...
        requiredPower-transmittedPower(2), ...
        requiredPower-transmittedPower(3), ...
        requiredPower-transmittedPower(4), ...
        abs(beltLength(1)-beltLength(2))-equalityTolerance, ...
        abs(beltLength(1)-beltLength(3))-equalityTolerance, ...
        abs(beltLength(1)-beltLength(4))-equalityTolerance];

    details=struct( ...
        'beltLength',beltLength, ...
        'theta',theta, ...
        'tensionRatio',tensionRatio, ...
        'transmittedPower',transmittedPower, ...
        'requiredPower',requiredPower, ...
        'equalityTolerance',equalityTolerance);
end
