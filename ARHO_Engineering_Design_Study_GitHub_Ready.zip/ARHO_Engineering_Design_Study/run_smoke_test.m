clc;
clear;
close all;

projectRoot=setup_project();

config=default_engineering_config();
config.numberOfRuns=2;
config.seeds=(1:2)';
config.maximumFunctionEvaluations=1000;
config.options.maxFEs=config.maximumFunctionEvaluations;
config.outputRoot=fullfile(projectRoot,'results','smoke_test');

keys={'pressure_vessel','welded_beam'};

for i=1:numel(keys)
    output=run_engineering_problem(keys{i},config);
    disp(output.summary);
    disp(output.validation);
end
