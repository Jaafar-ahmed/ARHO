function projectRoot = setup_project()
%SETUP_PROJECT Activate the clean engineering-design repository.

    projectRoot=fileparts(mfilename('fullpath'));
    cd(projectRoot);

    restoredefaultpath;
    addpath(projectRoot,'-begin');
    addpath(fullfile(projectRoot,'algorithms'),'-begin');
    addpath(fullfile(projectRoot,'problems'),'-begin');
    addpath(fullfile(projectRoot,'verification'),'-begin');
    addpath(fullfile(projectRoot,'experiments'),'-begin');

    rehash toolboxcache;
    rehash path;

    fprintf('ARHO Engineering Design Study activated:\n%s\n',projectRoot);
end
