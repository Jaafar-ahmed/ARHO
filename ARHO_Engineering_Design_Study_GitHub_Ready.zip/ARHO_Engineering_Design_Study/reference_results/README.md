# Verified reference results

These files contain the full-precision best feasible solutions and
30-run summary statistics used when preparing the engineering-design
section of the ARHO study.

Protocol:

- population size: 30;
- independent runs: 30;
- random seeds: 1–30;
- maximum objective-function evaluations: 30,000;
- feasibility tolerance: \(10^{-6}\);
- independent recomputation of the raw objective and all constraints.

`VerifiedSummaryStatistics.csv` consolidates the eight studies.
`VerifiedBestSolutions.csv` consolidates the best verified designs.
Each problem subfolder retains its original full-precision CSV files.

Runtime values are machine-dependent and should not be treated as
hardware-independent performance measures.
