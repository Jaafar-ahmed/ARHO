function report=verify_speed_reducer(x,tol,verbose)
%VERIFY_SPEED_REDUCER Independent speed-reducer verification.

    if nargin<2 || isempty(tol),tol=1e-6;end
    if nargin<3,verbose=true;end

    x=reshape(x,1,[]);
    if numel(x)~=7
        error('Expected [b,m,z,L1,L2,D1,D2].');
    end

    b=x(1);m=x(2);z=x(3);L1=x(4);L2=x(5);D1=x(6);D2=x(7);

    raw=0.7854*b*m^2*(3.3333*z^2+14.9334*z-43.0934) ...
       -1.508*b*(D1^2+D2^2) ...
       +7.4777*(D1^3+D2^3) ...
       +0.7854*(L1*D1^2+L2*D2^2);

    shaftStress1=sqrt((745*L1/(m*z))^2+16.9e6);
    shaftStress2=sqrt((745*L2/(m*z))^2+157.5e6);

    g=[ ...
        27/(b*m^2*z)-1, ...
        397.5/(b*m^2*z^2)-1, ...
        1.93*L1^3/(m*z*D1^4)-1, ...
        1.93*L2^3/(m*z*D2^4)-1, ...
        shaftStress1/(110*D1^3)-1, ...
        shaftStress2/(85*D2^3)-1, ...
        m*z/40-1, ...
        5*m/b-1, ...
        b/(12*m)-1, ...
        (1.5*D1+1.9)/L1-1, ...
        (1.1*D2+1.9)/L2-1];

    v=max(0,g);

    report.decodedX=x;
    report.raw=raw;
    report.merit=raw;
    report.g=g;
    report.margins=-g;
    report.vsum=sum(v);
    report.vmax=max(v);
    report.feasible=report.vmax<=tol;
    report.integerChecks=abs(z-round(z))<=tol;
    report.details=struct( ...
        'shaftStressNumerator1',shaftStress1, ...
        'shaftStressNumerator2',shaftStress2);

    if verbose
        print_report('Speed Reducer',report, ...
            {'b','m','z','L1','L2','D1','D2'});
        fprintf('z is integer = %d\n',report.integerChecks);
    end
end

function print_report(name,r,names)
    fprintf('=============================================\n');
    fprintf('%s Independent Verification\n',name);
    fprintf('=============================================\n');
    for i=1:numel(names)
        fprintf('%s = %.12f\n',names{i},r.decodedX(i));
    end
    fprintf('Raw objective = %.12f\n',r.raw);
    for i=1:numel(r.g)
        fprintf('g%d = %.12e, margin = %.12e\n', ...
            i,r.g(i),r.margins(i));
    end
    fprintf('Total violation = %.12e\n',r.vsum);
    fprintf('Maximum violation = %.12e\n',r.vmax);
    fprintf('Feasible = %d\n',r.feasible);
end
