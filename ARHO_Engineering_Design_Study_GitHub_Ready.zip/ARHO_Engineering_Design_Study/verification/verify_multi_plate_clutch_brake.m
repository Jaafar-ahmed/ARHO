function report = verify_multi_plate_clutch_brake(x, tol, verbose)
%VERIFY_MULTI_PLATE_CLUTCH Independent clutch-brake verification.
%
% x must contain decoded variables [ri,ro,t,F,Z].

    if nargin < 2 || isempty(tol), tol = 1e-6; end
    if nargin < 3, verbose = true; end

    x = reshape(x,1,[]);
    if numel(x) ~= 5
        error('Expected decoded variables [ri,ro,t,F,Z].');
    end

    ri=x(1); ro=x(2); t=x(3); F=x(4); Z=x(5);

    deltaR=20;
    Lmax=30;
    mu=0.6;
    pmax=1;
    rho=7.8e-6;
    vsrMax=10;
    safety=1.5;
    Tmax=15;
    n=250;
    Ms=40;
    Mf=3;
    Iz=55;
    delta=0.5;

    annulus=ro^2-ri^2;
    raw=pi*annulus*t*(Z+1)*rho;

    area=pi*annulus;
    pressure=F/area;
    effectiveRadius=(2/3)*(ro^3-ri^3)/annulus;
    slidingVelocity=pi*effectiveRadius*n/30/1000;
    torqueNm=((2/3)*mu*F*Z*(ro^3-ri^3)/annulus)/1000;
    omega=pi*n/30;
    stoppingTime=Iz*omega/max(torqueNm+Mf,eps);

    g=[ ...
        deltaR-(ro-ri), ...
        (Z+1)*(t+delta)-Lmax, ...
        pressure-pmax, ...
        pressure*slidingVelocity-pmax*vsrMax, ...
        slidingVelocity-vsrMax, ...
        stoppingTime-Tmax, ...
        safety*Ms-torqueNm, ...
        -stoppingTime];

    v=max(0,g);

    allowedT=[1,1.5,2,2.5,3];

    report.decodedX=x;
    report.raw=raw;
    report.merit=raw;
    report.g=g;
    report.margins=-g;
    report.vsum=sum(v);
    report.vmax=max(v);
    report.feasible=report.vmax<=tol;
    report.discreteChecks=[ ...
        abs(ri-round(ri))<=tol, ...
        abs(ro-round(ro))<=tol, ...
        min(abs(t-allowedT))<=tol, ...
        abs(F-round(F))<=tol, ...
        abs(Z-round(Z))<=tol];

    report.details=struct( ...
        'area',area, ...
        'pressure',pressure, ...
        'effectiveRadius',effectiveRadius, ...
        'slidingVelocity',slidingVelocity, ...
        'torqueNm',torqueNm, ...
        'stoppingTime',stoppingTime);

    if verbose
        print_report('Multi-Plate Disc Clutch Brake', ...
            report, {'ri','ro','t','F','Z'});
        fprintf('Pressure = %.12f N/mm^2\n',pressure);
        fprintf('Sliding velocity = %.12f m/s\n',slidingVelocity);
        fprintf('Torque capacity = %.12f N.m\n',torqueNm);
        fprintf('Stopping time = %.12f s\n',stoppingTime);
        fprintf('All discrete-variable checks passed = %d\n', ...
            all(report.discreteChecks));
    end
end

function print_report(name,r,names)
    fprintf('=============================================\n');
    fprintf('%s Independent Verification\n',name);
    fprintf('=============================================\n');
    for i=1:numel(names)
        fprintf('%s = %.12f\n',names{i},r.decodedX(i));
    end
    fprintf('Raw objective = %.12f\n',r.raw);
    for i=1:numel(r.g)
        fprintf('g%d = %.12e, margin = %.12e\n', ...
            i,r.g(i),r.margins(i));
    end
    fprintf('Total violation = %.12e\n',r.vsum);
    fprintf('Maximum violation = %.12e\n',r.vmax);
    fprintf('Feasible = %d\n',r.feasible);
end
