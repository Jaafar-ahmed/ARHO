function report = verify_step_cone_pulley(x,tol,verbose)
%VERIFY_STEP_CONE_PULLEY Independent step-cone pulley verification.

    if nargin<2 || isempty(tol),tol=1e-6;end
    if nargin<3,verbose=true;end

    x=reshape(x,1,[]);
    if numel(x)~=5
        error('Expected [d1,d2,d3,d4,w].');
    end

    d=x(1:4);
    w=x(5);

    rho=7200;
    N=350;
    Ni=[750,450,250,150];
    a=3000;
    mu=0.35;
    stress=1.75;
    beltThickness=8;
    requiredPower=0.75*745.6998;
    equalityTolerance=1.0;

    ratio=Ni/N;

    raw=rho*(w/1000)*(pi/4)*sum( ...
        (d/1000).^2.*(1+ratio.^2));

    beltLength=(pi*d/2).*(1+ratio) ...
        +((ratio-1).^2.*d.^2)/(4*a)+2*a;

    asinArgument=(ratio-1).*d/(2*a);
    asinArgument=min(1,max(-1,asinArgument));

    theta=pi-2*asin(asinArgument);
    tensionRatio=exp(mu*theta);

    tightSideTension=stress*beltThickness*w;
    transmittedPower=tightSideTension ...
        .*(1-exp(-mu*theta)) ...
        .*pi.*d.*Ni/(60*1000);

    equalityResiduals=[ ...
        beltLength(1)-beltLength(2), ...
        beltLength(1)-beltLength(3), ...
        beltLength(1)-beltLength(4)];

    g=[ ...
        2-tensionRatio, ...
        requiredPower-transmittedPower, ...
        abs(equalityResiduals)-equalityTolerance];

    v=max(0,g);

    report.decodedX=x;
    report.raw=raw;
    report.merit=raw;
    report.g=g;
    report.margins=-g;
    report.vsum=sum(v);
    report.vmax=max(v);
    report.feasible=report.vmax<=tol;
    report.details=struct( ...
        'beltLength',beltLength, ...
        'equalityResiduals',equalityResiduals, ...
        'theta',theta, ...
        'tensionRatio',tensionRatio, ...
        'transmittedPower',transmittedPower, ...
        'requiredPower',requiredPower, ...
        'equalityTolerance',equalityTolerance);

    if verbose
        print_report('Step-Cone Pulley',report, ...
            {'d1','d2','d3','d4','w'});
        fprintf('Belt lengths (mm):\n');
        fprintf('C1=%.12f, C2=%.12f, C3=%.12f, C4=%.12f\n', ...
            beltLength(1),beltLength(2),beltLength(3),beltLength(4));
        fprintf('Equality residuals (mm):\n');
        fprintf('C1-C2=%.12e, C1-C3=%.12e, C1-C4=%.12e\n', ...
            equalityResiduals(1),equalityResiduals(2),equalityResiduals(3));
        fprintf('Transmitted powers (W):\n');
        fprintf('P1=%.12f, P2=%.12f, P3=%.12f, P4=%.12f\n', ...
            transmittedPower(1),transmittedPower(2), ...
            transmittedPower(3),transmittedPower(4));
    end
end

function print_report(name,r,names)
    fprintf('=============================================\n');
    fprintf('%s Independent Verification\n',name);
    fprintf('=============================================\n');
    for i=1:numel(names)
        fprintf('%s = %.12f\n',names{i},r.decodedX(i));
    end
    fprintf('Raw objective = %.12f\n',r.raw);
    for i=1:numel(r.g)
        fprintf('g%d = %.12e, margin = %.12e\n', ...
            i,r.g(i),r.margins(i));
    end
    fprintf('Total violation = %.12e\n',r.vsum);
    fprintf('Maximum violation = %.12e\n',r.vmax);
    fprintf('Feasible = %d\n',r.feasible);
end
