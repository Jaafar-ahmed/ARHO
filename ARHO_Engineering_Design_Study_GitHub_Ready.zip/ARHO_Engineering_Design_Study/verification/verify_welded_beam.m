function report = verify_welded_beam(x, tol, verbose)
%VERIFY_WELDED_BEAM Independent welded-beam verification.

    if nargin < 2 || isempty(tol), tol=1e-6; end
    if nargin < 3, verbose=true; end

    x=reshape(x,1,[]);
    if numel(x)~=4
        error('Expected [h,l,t,b].');
    end

    h=x(1); l=x(2); t=x(3); b=x(4);
    P=6000; L=14; E=30e6; G=12e6;
    tauMax=13600; sigmaMax=30000; deltaMax=0.25;

    raw=1.10471*h^2*l+0.04811*t*b*(14+l);

    tau1=P/(sqrt(2)*h*l);
    M=P*(L+l/2);
    R=sqrt(l^2/4+((h+t)/2)^2);
    J=2*sqrt(2)*h*l*(l^2/12+((h+t)/2)^2);
    tau2=M*R/J;
    tau=sqrt(tau1^2+2*tau1*tau2*l/(2*R)+tau2^2);

    sigma=6*P*L/(b*t^2);
    delta=4*P*L^3/(E*t^3*b);
    Pc=(4.013*E/L^2)*sqrt(t^2*b^6/36) ...
      *(1-t/(2*L)*sqrt(E/(4*G)));

    g=[tau-tauMax, sigma-sigmaMax, P-Pc, ...
       delta-deltaMax, h-b];
    v=max(0,g);

    report.decodedX=x;
    report.raw=raw;
    report.merit=raw;
    report.g=g;
    report.margins=-g;
    report.vsum=sum(v);
    report.vmax=max(v);
    report.feasible=report.vmax<=tol;
    report.details=struct('tau',tau,'sigma',sigma, ...
                          'Pc',Pc,'delta',delta);

    if verbose
        print_report('Welded Beam',report,{'h','l','t','b'});
        fprintf('tau = %.12f\n',tau);
        fprintf('sigma = %.12f\n',sigma);
        fprintf('Pc = %.12f\n',Pc);
        fprintf('delta = %.12f\n',delta);
    end
end

function print_report(name,r,names)
    fprintf('=============================================\n');
    fprintf('%s Independent Verification\n',name);
    fprintf('=============================================\n');
    for i=1:numel(names)
        fprintf('%s = %.12f\n',names{i},r.decodedX(i));
    end
    fprintf('Raw objective = %.12f\n',r.raw);
    for i=1:numel(r.g)
        fprintf('g%d = %.12e, margin = %.12e\n', ...
            i,r.g(i),r.margins(i));
    end
    fprintf('Total violation = %.12e\n',r.vsum);
    fprintf('Maximum violation = %.12e\n',r.vmax);
    fprintf('Feasible = %d\n',r.feasible);
end
