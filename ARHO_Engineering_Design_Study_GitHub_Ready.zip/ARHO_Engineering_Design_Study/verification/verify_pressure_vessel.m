function report = verify_pressure_vessel(x, tol, verbose)
%VERIFY_PRESSURE_VESSEL Independent pressure-vessel verification.
%
% x must contain decoded variables [Ts,Th,R,L].

    if nargin < 2 || isempty(tol), tol = 1e-6; end
    if nargin < 3, verbose = true; end

    x = reshape(x,1,[]);
    if numel(x) ~= 4
        error('Expected decoded variables [Ts,Th,R,L].');
    end

    Ts=x(1); Th=x(2); R=x(3); L=x(4);

    raw = 0.6224*Ts*R*L ...
        + 1.7781*Th*R^2 ...
        + 3.1661*Ts^2*L ...
        + 19.84*Ts^2*R;

    g = [ ...
        0.0193*R - Ts, ...
        0.00954*R - Th, ...
        1296000 - pi*R^2*L - (4/3)*pi*R^3, ...
        L - 240];

    v = max(0,g);

    report.decodedX = x;
    report.raw = raw;
    report.merit = raw;
    report.g = g;
    report.margins = -g;
    report.vsum = sum(v);
    report.vmax = max(v);
    report.feasible = report.vmax <= tol;
    report.discreteChecks = [ ...
        abs(Ts/0.0625-round(Ts/0.0625)) <= tol, ...
        abs(Th/0.0625-round(Th/0.0625)) <= tol];

    if verbose
        print_report('Pressure Vessel', report, {'Ts','Th','R','L'});
        fprintf('Ts multiple of 0.0625: %d\n', report.discreteChecks(1));
        fprintf('Th multiple of 0.0625: %d\n', report.discreteChecks(2));
    end
end

function print_report(name, r, names)
    fprintf('=============================================\n');
    fprintf('%s Independent Verification\n', name);
    fprintf('=============================================\n');
    for i=1:numel(names)
        fprintf('%s = %.12f\n', names{i}, r.decodedX(i));
    end
    fprintf('Raw objective = %.12f\n', r.raw);
    for i=1:numel(r.g)
        fprintf('g%d = %.12e, margin = %.12e\n', ...
            i, r.g(i), r.margins(i));
    end
    fprintf('Total violation = %.12e\n', r.vsum);
    fprintf('Maximum violation = %.12e\n', r.vmax);
    fprintf('Feasible = %d\n', r.feasible);
end
