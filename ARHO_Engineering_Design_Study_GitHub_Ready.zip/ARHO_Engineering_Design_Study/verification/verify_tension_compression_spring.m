function report = verify_tension_compression_spring(x,tol,verbose)
%VERIFY_SPRING Independent spring-design verification.

    if nargin<2 || isempty(tol),tol=1e-6;end
    if nargin<3,verbose=true;end

    x=reshape(x,1,[]);
    if numel(x)~=3,error('Expected [d,D,N].');end

    d=x(1);D=x(2);N=x(3);
    raw=(N+2)*D*d^2;

    denominator=12566*(D*d^3-d^4);
    if abs(denominator)<eps
        denominator=sign(denominator+eps)*eps;
    end

    g=[ ...
        1-D^3*N/(71785*d^4), ...
        (4*D^2-d*D)/denominator+1/(5108*d^2)-1, ...
        1-140.45*d/(D^2*N), ...
        (d+D)/1.5-1];

    v=max(0,g);
    report.decodedX=x;
    report.raw=raw;
    report.merit=raw;
    report.g=g;
    report.margins=-g;
    report.vsum=sum(v);
    report.vmax=max(v);
    report.feasible=report.vmax<=tol;

    if verbose
        print_report('Tension-Compression Spring',report, ...
            {'d','D','N'});
    end
end

function print_report(name,r,names)
    fprintf('=============================================\n');
    fprintf('%s Independent Verification\n',name);
    fprintf('=============================================\n');
    for i=1:numel(names)
        fprintf('%s = %.12f\n',names{i},r.decodedX(i));
    end
    fprintf('Raw objective = %.12f\n',r.raw);
    for i=1:numel(r.g)
        fprintf('g%d = %.12e, margin = %.12e\n', ...
            i,r.g(i),r.margins(i));
    end
    fprintf('Total violation = %.12e\n',r.vsum);
    fprintf('Maximum violation = %.12e\n',r.vmax);
    fprintf('Feasible = %d\n',r.feasible);
end
