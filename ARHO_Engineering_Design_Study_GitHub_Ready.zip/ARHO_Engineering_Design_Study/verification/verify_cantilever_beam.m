function report = verify_cantilever_beam(x,tol,verbose)
%VERIFY_CANTILEVER Independent cantilever verification.

    if nargin<2 || isempty(tol),tol=1e-6;end
    if nargin<3,verbose=true;end

    x=reshape(x,1,[]);
    if numel(x)~=5,error('Expected [x1,x2,x3,x4,x5].');end

    raw=0.0624*sum(x);
    g=61/x(1)^3+37/x(2)^3+19/x(3)^3 ...
     +7/x(4)^3+1/x(5)^3-1;
    v=max(0,g);

    report.decodedX=x;
    report.raw=raw;
    report.merit=raw;
    report.g=g;
    report.margins=-g;
    report.vsum=sum(v);
    report.vmax=max(v);
    report.feasible=report.vmax<=tol;

    if verbose
        print_report('Cantilever Beam',report, ...
            {'x1','x2','x3','x4','x5'});
    end
end

function print_report(name,r,names)
    fprintf('=============================================\n');
    fprintf('%s Independent Verification\n',name);
    fprintf('=============================================\n');
    for i=1:numel(names)
        fprintf('%s = %.12f\n',names{i},r.decodedX(i));
    end
    fprintf('Raw objective = %.12f\n',r.raw);
    fprintf('g1 = %.12e, margin = %.12e\n',r.g,r.margins);
    fprintf('Maximum violation = %.12e\n',r.vmax);
    fprintf('Feasible = %d\n',r.feasible);
end
