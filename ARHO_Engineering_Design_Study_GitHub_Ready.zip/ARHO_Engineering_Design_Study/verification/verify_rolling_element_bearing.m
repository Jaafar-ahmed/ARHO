function report = verify_rolling_element_bearing(x,tol,verbose)
%VERIFY_BEARING Independent rolling-element-bearing verification.

    if nargin<2 || isempty(tol),tol=1e-6;end
    if nargin<3,verbose=true;end

    x=reshape(x,1,[]);
    if numel(x)~=10
        error(['Expected [Dm,Db,Z,fi,fo,KDmin,KDmax,', ...
               'epsilon,e,zeta].']);
    end

    D=160;d=90;Bw=30;alpha=0;

    Dm=x(1);Db=x(2);Z=x(3);fi=x(4);fo=x(5);
    KDmin=x(6);KDmax=x(7);epsilon=x(8);e=x(9);zeta=x(10);

    gamma=Db*cos(alpha)/Dm;
    ratioTerm=(fi*(2*fo-1))/(fo*(2*fi-1));

    fc=37.91 ...
      *(1+(1.04*((1-gamma)/(1+gamma))^1.72 ...
      *ratioTerm^0.41)^(10/3))^(-0.3) ...
      *(gamma^0.3*(1-gamma)^1.39/(1+gamma)^(1/3)) ...
      *(2*fi/(2*fi-1))^0.41;

    if Db<=25.4
        capacity=fc*Z^(2/3)*Db^1.8;
    else
        capacity=3.647*fc*Z^(2/3)*Db^1.4;
    end

    T=D-d-2*Db;
    A=(D-d)/2-3*T/4;
    B=D/2-T/4-Db;
    C=d/2+T/4;
    acosArgument=(A^2+B^2-C^2)/(2*A*B);
    acosArgument=min(1,max(-1,acosArgument));
    phi0=2*pi-2*acos(acosArgument);

    g=[ ...
        Z-phi0/(2*asin(Db/Dm))-1, ...
        Db-zeta*Bw, ...
        KDmin*(D-d)-2*Db, ...
        2*Db-KDmax*(D-d), ...
        Dm-(0.5+e)*(D+d), ...
        0.5*(D+d)-Dm, ...
        epsilon*Db-0.5*(D-Dm-Db), ...
        0.515-fo, ...
        0.515-fi];

    v=max(0,g);
    report.decodedX=x;
    report.raw=capacity;
    report.merit=-capacity;
    report.g=g;
    report.margins=-g;
    report.vsum=sum(v);
    report.vmax=max(v);
    report.feasible=report.vmax<=tol;
    report.integerChecks=abs(Z-round(Z))<=tol;
    report.details=struct('fc',fc,'gamma',gamma,'phi0',phi0);

    if verbose
        print_report('Rolling Element Bearing',report, ...
            {'Dm','Db','Z','fi','fo','KDmin','KDmax', ...
             'epsilon','e','zeta'});
        fprintf('Z is integer: %d\n',report.integerChecks);
        fprintf('fc = %.12f\n',fc);
        fprintf('phi0 = %.12f\n',phi0);
    end
end

function print_report(name,r,names)
    fprintf('=============================================\n');
    fprintf('%s Independent Verification\n',name);
    fprintf('=============================================\n');
    for i=1:numel(names)
        fprintf('%s = %.12f\n',names{i},r.decodedX(i));
    end
    fprintf('Raw objective/capacity = %.12f\n',r.raw);
    for i=1:numel(r.g)
        fprintf('g%d = %.12e, margin = %.12e\n', ...
            i,r.g(i),r.margins(i));
    end
    fprintf('Total violation = %.12e\n',r.vsum);
    fprintf('Maximum violation = %.12e\n',r.vmax);
    fprintf('Feasible = %d\n',r.feasible);
end
