function export_engineering_results(problem,config,folder, ...
    results,summary,bestRow,constraintTable,validation, ...
    allBest,allHistory,allOutput)
%EXPORT_ENGINEERING_RESULTS Export reproducibility files and figures.

    write_full_precision_table(results, ...
        fullfile(folder,'AllRuns_FullPrecision.csv'));

    write_full_precision_table(summary, ...
        fullfile(folder,'SummaryStatistics.csv'));

    if ~isempty(bestRow)
        write_full_precision_table(bestRow, ...
            fullfile(folder,'BestFeasibleSolution.csv'));
    end

    write_full_precision_table(constraintTable, ...
        fullfile(folder,'ConstraintValuesAndMargins.csv'));

    writetable(validation,fullfile(folder,'ValidationChecks.csv'));
    writematrix(config.seeds(:),fullfile(folder,'RandomSeeds.txt'));

    write_configuration(problem,config, ...
        fullfile(folder,'ExperimentConfiguration.txt'));

    save(fullfile(folder,'CompleteExperiment.mat'), ...
        'problem','config','results','summary','bestRow', ...
        'constraintTable','validation','allBest','allHistory','allOutput');

    if isempty(bestRow)
        return;
    end

    bestSeed=bestRow.Seed;
    bestIndex=find(config.seeds==bestSeed,1,'first');
    history=allHistory{bestIndex};

    fig=figure('Visible','off');
    plot(history.functionEvaluations,history.bestRaw,'LineWidth',1.8);
    grid on;
    xlabel('Function evaluations');
    ylabel('Best raw objective');
    title([problem.name ': best verified run']);
    exportgraphics(fig,fullfile(folder,'BestRun_RawObjective.png'), ...
        'Resolution',300);
    close(fig);

    fig=figure('Visible','off');
    semilogy(history.functionEvaluations, ...
        max(history.bestVmax,realmin),'LineWidth',1.8);
    grid on;
    xlabel('Function evaluations');
    ylabel('Maximum constraint violation');
    title([problem.name ': feasibility history']);
    exportgraphics(fig,fullfile(folder,'BestRun_MaxViolation.png'), ...
        'Resolution',300);
    close(fig);
end

function write_configuration(problem,config,filename)
    fid=fopen(filename,'w');
    if fid<0
        error('Cannot open %s.',filename);
    end
    cleanup=onCleanup(@()fclose(fid));

    fprintf(fid,'Problem: %s\n',problem.name);
    fprintf(fid,'Direction: %s\n',problem.sense);
    fprintf(fid,'Formulation: %s\n',problem.formulation);
    fprintf(fid,'Population size: %d\n',config.populationSize);
    fprintf(fid,'Maximum iterations: %d\n',config.maximumIterations);
    fprintf(fid,'Maximum function evaluations: %d\n', ...
        config.maximumFunctionEvaluations);
    fprintf(fid,'Independent runs: %d\n',config.numberOfRuns);
    fprintf(fid,'Seeds: %s\n\n',mat2str(config.seeds'));

    fprintf(fid,'Decoded variables:\n%s\n\n', ...
        strjoin(problem.decodedVariableNames,', '));

    fprintf(fid,'Constraints, feasible when g <= 0:\n%s\n\n', ...
        strjoin(problem.constraintNames,', '));

    fprintf(fid,'ARHO options:\n');
    names=fieldnames(config.options);
    for i=1:numel(names)
        value=config.options.(names{i});

        if islogical(value)
            fprintf(fid,'%s = %d\n',names{i},value);
        elseif isnumeric(value) && isscalar(value)
            fprintf(fid,'%s = %.16g\n',names{i},value);
        else
            fprintf(fid,'%s = %s\n',names{i},string(value));
        end
    end
end

function write_full_precision_table(tableData,filename)
    fid=fopen(filename,'w');
    if fid<0
        error('Cannot open %s.',filename);
    end
    cleanup=onCleanup(@()fclose(fid));

    names=tableData.Properties.VariableNames;
    fprintf(fid,'%s',names{1});

    for column=2:numel(names)
        fprintf(fid,',%s',names{column});
    end
    fprintf(fid,'\n');

    for row=1:height(tableData)
        for column=1:width(tableData)
            value=tableData{row,column};

            if islogical(value)
                fprintf(fid,'%d',value);
            elseif isnumeric(value)
                fprintf(fid,'%.16g',value);
            else
                fprintf(fid,'"%s"',string(value));
            end

            if column<width(tableData)
                fprintf(fid,',');
            else
                fprintf(fid,'\n');
            end
        end
    end
end
