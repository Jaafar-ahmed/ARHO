function config = default_engineering_config()
%DEFAULT_ENGINEERING_CONFIG Reproducible ARHO engineering protocol.

    projectRoot=fileparts(fileparts(mfilename('fullpath')));

    config.populationSize=30;
    config.maximumIterations=500;
    config.maximumFunctionEvaluations=30000;
    config.numberOfRuns=30;
    config.seeds=(1:30)';
    config.outputRoot=fullfile(projectRoot,'results');
    config.resume=true;
    config.saveEveryRun=true;

    config.options=ARHO_DefaultOptions(config.populationSize);
    config.options.maxFEs=config.maximumFunctionEvaluations;
    config.options.scheduleByFEs=true;
    config.options.verbose=false;
end
