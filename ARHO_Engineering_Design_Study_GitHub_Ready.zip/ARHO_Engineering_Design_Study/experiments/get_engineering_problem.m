function problem = get_engineering_problem(problemKey)
%GET_ENGINEERING_PROBLEM Return one of the eight engineering problems.

    key=lower(strrep(strrep(string(problemKey),'-','_'),' ','_'));

    switch key
        case {"pressure_vessel","pressurevessel"}
            problem=pressure_vessel_problem();

        case {"welded_beam","weldedbeam"}
            problem=welded_beam_problem();

        case {"cantilever_beam","cantilever"}
            problem=cantilever_beam_problem();

        case {"spring","tension_compression_spring", ...
              "tensioncompression_spring"}
            problem=tension_compression_spring_problem();

        case {"rolling_element_bearing","bearing"}
            problem=rolling_element_bearing_problem();

        case {"multi_plate_clutch_brake","multi_plate_clutch", ...
              "clutch_brake"}
            problem=multi_plate_clutch_brake_problem();

        case {"step_cone_pulley","pulley"}
            problem=step_cone_pulley_problem();

        case {"speed_reducer","reducer"}
            problem=speed_reducer_problem();

        otherwise
            error('Unknown engineering problem key: %s',problemKey);
    end
end
