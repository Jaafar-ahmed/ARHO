function output = run_engineering_problem(problemKey,config)
%RUN_ENGINEERING_PROBLEM Run one constrained design problem.
%
% Every run is independently verified from the full-precision decoded
% variables. Completed run files can be reused when config.resume is true.

    if nargin<2 || isempty(config)
        config=default_engineering_config();
    end

    problem=get_engineering_problem(problemKey);
    validate_config(config);

    safeName=regexprep(lower(problem.name),'[^a-z0-9]+','_');
    safeName=regexprep(safeName,'(^_|_$)','');
    outputFolder=fullfile(config.outputRoot,safeName);

    if ~exist(outputFolder,'dir')
        mkdir(outputFolder);
    end

    nRuns=config.numberOfRuns;
    nVar=numel(problem.decodedVariableNames);
    nCon=numel(problem.constraintNames);

    decoded=nan(nRuns,nVar);
    raw=nan(nRuns,1);
    merit=nan(nRuns,1);
    constraints=nan(nRuns,nCon);
    margins=nan(nRuns,nCon);
    totalViolation=nan(nRuns,1);
    maxViolation=nan(nRuns,1);
    feasible=false(nRuns,1);
    functionEvaluations=nan(nRuns,1);
    iterations=nan(nRuns,1);
    runtime=nan(nRuns,1);
    status=strings(nRuns,1);

    allBest=cell(nRuns,1);
    allHistory=cell(nRuns,1);
    allOutput=cell(nRuns,1);

    for run=1:nRuns
        seed=config.seeds(run);
        runFile=fullfile(outputFolder, ...
            sprintf('Run_%02d_seed_%d.mat',run,seed));

        if config.resume && exist(runFile,'file')
            saved=load(runFile,'best','history','algorithmOutput', ...
                'check','seed','elapsed','runStatus');

            required={'best','history','algorithmOutput','check','elapsed'};
            valid=all(isfield(saved,required));

            if valid
                best=saved.best;
                history=saved.history;
                algorithmOutput=saved.algorithmOutput;
                check=saved.check;
                elapsed=saved.elapsed;

                if isfield(saved,'runStatus')
                    runStatus=string(saved.runStatus);
                else
                    runStatus="LOADED";
                end

                fprintf('%s | run %02d/%02d | seed=%d | loaded\n', ...
                    problem.name,run,nRuns,seed);
            else
                delete(runFile);
                [best,history,algorithmOutput,check,elapsed,runStatus]= ...
                    execute_run(problem,config,seed);
            end
        else
            [best,history,algorithmOutput,check,elapsed,runStatus]= ...
                execute_run(problem,config,seed);
        end

        if config.saveEveryRun && ~exist(runFile,'file')
            save(runFile,'best','history','algorithmOutput', ...
                'check','seed','elapsed','runStatus');
        end

        decoded(run,:)=check.decodedX;
        raw(run)=check.raw;
        merit(run)=check.merit;
        constraints(run,:)=check.g;
        margins(run,:)=check.margins;
        totalViolation(run)=check.vsum;
        maxViolation(run)=check.vmax;
        feasible(run)=check.feasible;
        functionEvaluations(run)=algorithmOutput.functionEvaluations;
        iterations(run)=algorithmOutput.iterationsCompleted;
        runtime(run)=elapsed;
        status(run)=runStatus;

        allBest{run}=best;
        allHistory{run}=history;
        allOutput{run}=algorithmOutput;
    end

    variableNames=[{'Seed'},problem.decodedVariableNames, ...
        {'RawObjective','SearchMerit'},problem.constraintNames, ...
        strcat('Margin_',problem.constraintNames), ...
        {'TotalViolation','MaxViolation','Feasible', ...
         'FunctionEvaluations','Iterations','RuntimeSeconds','Status'}];

    numericPart=[config.seeds(:),decoded,raw,merit,constraints,margins, ...
        totalViolation,maxViolation,double(feasible), ...
        functionEvaluations,iterations,runtime];

    results=array2table(numericPart,'VariableNames',variableNames(1:end-1));
    results.Feasible=logical(results.Feasible);
    results.Status=status;

    [summary,bestRow,constraintTable]= ...
        generate_engineering_summary(results,problem);

    validation=validate_engineering_results( ...
        results,problem,config.maximumFunctionEvaluations);

    export_engineering_results(problem,config,outputFolder, ...
        results,summary,bestRow,constraintTable,validation, ...
        allBest,allHistory,allOutput);

    output.problem=problem;
    output.results=results;
    output.summary=summary;
    output.bestRow=bestRow;
    output.constraintTable=constraintTable;
    output.validation=validation;
    output.outputFolder=outputFolder;

    fprintf('\nCompleted: %s\n',problem.name);
    fprintf('Feasible runs: %d/%d\n',sum(results.Feasible),height(results));
    fprintf('Output folder: %s\n\n',outputFolder);
end

function [best,history,algorithmOutput,check,elapsed,runStatus]= ...
    execute_run(problem,config,seed)

    fprintf('%s | seed=%d | maxFEs=%d\n', ...
        problem.name,seed,config.maximumFunctionEvaluations);

    rng(seed,'twister');
    timer=tic;

    [best,history,algorithmOutput]=ARHO( ...
        problem,config.populationSize, ...
        config.maximumIterations,config.options);

    elapsed=toc(timer);
    runStatus="OK";

    check=problem.verify(best.decodedX, ...
        config.options.feasibilityTol,false);

    objectiveTolerance=1e-9*max(1,abs(check.raw));
    constraintTolerance=1e-8;

    assert(abs(best.raw-check.raw)<=objectiveTolerance, ...
        'Independent objective verification failed for seed %d.',seed);

    assert(max(abs(best.g-check.g))<=constraintTolerance, ...
        'Independent constraint verification failed for seed %d.',seed);

    assert(algorithmOutput.functionEvaluations== ...
        config.maximumFunctionEvaluations, ...
        'The run did not consume the requested FE budget.');
end

function validate_config(config)
    required={ ...
        'populationSize','maximumIterations', ...
        'maximumFunctionEvaluations','numberOfRuns', ...
        'seeds','outputRoot','resume','saveEveryRun','options'};

    for i=1:numel(required)
        assert(isfield(config,required{i}), ...
            'Missing configuration field: %s',required{i});
    end

    assert(numel(config.seeds)==config.numberOfRuns, ...
        'The number of seeds must equal numberOfRuns.');
end
