clc;
clear;
close all;

setup_project();

config=default_engineering_config();
output=run_engineering_problem('speed_reducer',config);

disp(output.summary);
disp(output.bestRow);
disp(output.validation);
